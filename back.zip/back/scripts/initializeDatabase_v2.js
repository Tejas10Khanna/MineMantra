/**
 * CCL Smart Governance Platform
 * MongoDB Database Initializer v2
 *
 * Purpose:
 * - Source-of-truth schema for autonomous generation of:
 *   1) Compliance Report     - Monthly / Quarterly / Annual
 *   2) Production Report     - Daily
 *   3) Safety Report         - Monthly
 *   4) Sustainability Report - Annual
 *
 * Design principle:
 * - Store atomic operational observations and regulatory/compliance evidence.
 * - Derive report values with deterministic aggregation/calculation logic.
 * - Keep LLM-generated narrative separate from authoritative calculations.
 * - Do NOT seed fabricated legal clauses, thresholds, EC conditions, mine names,
 *   production targets, environmental limits, or safety statistics.
 *
 * Run:
 *   npm install mongodb dotenv
 *   export MONGODB_URI="mongodb+srv://..."
 *   node initializeDatabase_v2.js
 */

require("dotenv").config();
const { MongoClient } = require("mongodb");

const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = process.env.MONGODB_DB || "ccl_smart_governance";

if (!MONGODB_URI) {
  console.error("Missing MONGODB_URI environment variable.");
  process.exit(1);
}

const COLLECTIONS = [
  // Organisation / reference
  "users", "roles", "departments", "contractors",
  "coalfields", "areas", "mines", "mine_zones", "mine_boundaries",

  // Regulatory / compliance
  "regulatory_authorities", "regulations", "regulation_versions",
  "compliance_requirements", "mine_compliance_conditions",
  "compliance_occurrences", "compliance_measurements",
  "compliance_violations", "audit_findings",
  "regulatory_deadlines", "regulatory_notices", "legal_cases",
  "regulatory_reports", "report_submissions",

  // Approvals / permissions
  "mining_leases", "mining_plans", "mine_closure_plans",
  "mine_closure_progress", "mine_closure_escrow",
  "environmental_clearances", "forest_clearances",
  "wildlife_clearances", "water_permissions",
  "pollution_consents", "explosives_licences", "electrical_approvals",

  // Workforce
  "workers", "worker_training", "worker_certifications",
  "medical_fitness", "ppe_records", "attendance", "shifts",
  "statutory_manpower_snapshots", "statutory_manpower_requirements",

  // Safety / governance
  "compliance_records", "inspections", "inspection_templates",
  "inspection_checklists", "reports", "safety_observations",
  "near_misses", "incidents", "accidents", "hazards",
  "corrective_actions", "safety_exposure_records",
  "safety_program_activities", "rescue_readiness_records",
  "safety_alerts",

  // Production / operations
  "production_target_records", "production_records",
  "dispatch_records", "washeries", "washery_operations",
  "stockpile_records", "equipment", "equipment_maintenance",
  "equipment_inspections", "equipment_faults",
  "equipment_telemetry", "equipment_daily_performance",
  "mine_capacity_records", "downtime_records",
  "blasting_records", "drilling_records",
  "wagon_loading_records", "eauction_records",
  "coal_quality_records",

  // Environment / sustainability
  "air_quality", "water_quality", "groundwater",
  "noise_monitoring", "soil_monitoring", "weather",
  "environmental_samples", "water_resource_records",
  "energy_records", "fuel_consumption_records",
  "emissions_records", "waste_records",
  "land_use", "forest_monitoring", "vegetation_monitoring",
  "plantation_records", "reclamation_records",
  "biodiversity_records", "satellite_observations",
  "renewable_energy_projects", "sustainability_projects",
  "eco_parks",

  // Community / social sustainability
  "csr_projects", "csr_expenditure", "social_metrics",

  // IoT / CV
  "sensors", "sensor_readings", "cameras", "cctv_events",

  // Documents / evidence / audit
  "documents", "evidence", "audit_log", "blockchain_records",

  // Reporting / reproducibility
  "report_definitions", "report_metric_contracts",
  "report_instances", "report_artifacts",
  "metric_snapshots", "data_quality_checks",
  "data_quality_issues",

  // Alerts
  "alerts", "reminders", "escalations",

  // AI / analytics
  "ai_models", "analytics_results",

  // Field reporting
  "grievances"
];

// Core validators are intentionally permissive on fields not universally present
// across all CCL units. "moderate" validation allows the schema to evolve.
const VALIDATORS = {
  users: {
    $jsonSchema: {
      bsonType: "object",
      required: ["employee_id", "name", "role"],
      properties: {
        employee_id: { bsonType: "string" },
        name: { bsonType: "string" },
        role: { bsonType: "string" }
      }
    }
  },

  mines: {
    $jsonSchema: {
      bsonType: "object",
      required: ["name", "type"],
      properties: {
        name: { bsonType: "string" },
        type: { enum: ["UG", "OC"] }
      }
    }
  },

  compliance_requirements: {
    $jsonSchema: {
      bsonType: "object",
      required: ["requirement_code", "category", "requirement_text"],
      properties: {
        requirement_code: { bsonType: "string" },
        category: { bsonType: "string" },
        requirement_text: { bsonType: "string" },
        frequency: { bsonType: "string" },
        responsible_role: { bsonType: "string" },
        evidence_types: { bsonType: "array" }
      }
    }
  },

  compliance_occurrences: {
    $jsonSchema: {
      bsonType: "object",
      required: [
        "requirement_id", "mine_id", "reporting_period_start",
        "reporting_period_end", "due_date", "status"
      ],
      properties: {
        status: {
          enum: [
            "not_started", "in_progress", "compliant",
            "partially_compliant", "non_compliant",
            "overdue", "not_applicable", "verified"
          ]
        }
      }
    }
  },

  compliance_measurements: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "measurement_date", "requirement_id"],
      properties: {
        observed_value: {},
        unit: { bsonType: "string" },
        pass_fail: { enum: ["pass", "fail", "not_applicable", "unknown"] }
      }
    }
  },

  production_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "production_date", "mine_type"],
      properties: {
        mine_type: { enum: ["UG", "OC"] },
        production_date: { bsonType: "date" },
        coal_tonnes: { bsonType: ["double", "int", "long", "decimal"] },
        coal_target_tonnes: { bsonType: ["double", "int", "long", "decimal", "null"] },
        ob_removed_m3: { bsonType: ["double", "int", "long", "decimal", "null"] },
        man_shifts: { bsonType: ["double", "int", "long", "decimal", "null"] }
      }
    }
  },

  production_target_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["scope_type", "scope_id", "period_start", "period_end", "target_type", "target_value"],
      properties: {
        scope_type: { enum: ["company", "coalfield", "area", "mine", "washery"] },
        target_type: { bsonType: "string" },
        target_value: { bsonType: ["double", "int", "long", "decimal"] },
        unit: { bsonType: "string" }
      }
    }
  },

  dispatch_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["dispatch_date", "mode", "sector", "product_type", "tonnes"],
      properties: {
        mode: { enum: ["rail", "road", "feed_to_washery", "conveyor", "MGR", "other"] },
        sector: { bsonType: "string" },
        product_type: { bsonType: "string" }
      }
    }
  },

  washery_operations: {
    $jsonSchema: {
      bsonType: "object",
      required: ["washery_id", "operation_date"],
      properties: {
        raw_coal_received_tonnes: { bsonType: ["double", "int", "long", "decimal", "null"] },
        raw_coal_consumed_tonnes: { bsonType: ["double", "int", "long", "decimal", "null"] },
        washed_coal_produced_tonnes: { bsonType: ["double", "int", "long", "decimal", "null"] },
        washed_coal_dispatched_tonnes: { bsonType: ["double", "int", "long", "decimal", "null"] }
      }
    }
  },

  equipment_daily_performance: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "as_of_date", "equipment_type"],
      properties: {
        equipment_type: { bsonType: "string" },
        population_total: { bsonType: ["int", "long", "double", "null"] },
        not_surveyed_off_count: { bsonType: ["int", "long", "double", "null"] },
        provisionally_surveyed_off_count: { bsonType: ["int", "long", "double", "null"] },
        availability_norm_pct: { bsonType: ["double", "int", "decimal", "null"] },
        availability_pct: { bsonType: ["double", "int", "decimal", "null"] },
        utilization_norm_pct: { bsonType: ["double", "int", "decimal", "null"] },
        utilization_pct: { bsonType: ["double", "int", "decimal", "null"] }
      }
    }
  },

  safety_exposure_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "period_start", "period_end"],
      properties: {
        man_shifts: { bsonType: ["double", "int", "long", "decimal", "null"] },
        man_hours: { bsonType: ["double", "int", "long", "decimal", "null"] },
        employee_man_shifts: { bsonType: ["double", "int", "long", "decimal", "null"] },
        contractor_man_shifts: { bsonType: ["double", "int", "long", "decimal", "null"] },
        coal_ob_volume_basis: { bsonType: ["double", "int", "long", "decimal", "null"] }
      }
    }
  },

  accidents: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "event_datetime", "event_class"],
      properties: {
        event_class: {
          enum: [
            "fatal_accident", "serious_accident",
            "reportable_accident", "minor_accident",
            "dangerous_occurrence", "other"
          ]
        },
        fatalities: { bsonType: ["int", "long", "double", "null"] },
        serious_injuries: { bsonType: ["int", "long", "double", "null"] },
        lost_days: { bsonType: ["int", "long", "double", "null"] },
        root_cause_method: { bsonType: ["string", "null"] }
      }
    }
  },

  safety_program_activities: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "activity_date", "activity_type"],
      properties: {
        activity_type: { bsonType: "string" },
        participants_count: { bsonType: ["int", "long", "double", "null"] },
        findings_count: { bsonType: ["int", "long", "double", "null"] },
        actions_raised: { bsonType: ["int", "long", "double", "null"] },
        actions_closed: { bsonType: ["int", "long", "double", "null"] }
      }
    }
  },

  rescue_readiness_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["site_id", "as_of_date"],
      properties: {
        readiness_status: { bsonType: "string" },
        trained_personnel_count: { bsonType: ["int", "long", "double", "null"] },
        apparatus_ready_count: { bsonType: ["int", "long", "double", "null"] },
        apparatus_total_count: { bsonType: ["int", "long", "double", "null"] }
      }
    }
  },

  energy_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "period_start", "period_end", "energy_type"],
      properties: {
        energy_type: { bsonType: "string" },
        quantity: { bsonType: ["double", "int", "long", "decimal"] },
        unit: { bsonType: "string" },
        source: { bsonType: ["string", "null"] }
      }
    }
  },

  water_resource_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "period_start", "period_end"],
      properties: {
        withdrawal_kl: { bsonType: ["double", "int", "long", "decimal", "null"] },
        consumption_kl: { bsonType: ["double", "int", "long", "decimal", "null"] },
        discharge_kl: { bsonType: ["double", "int", "long", "decimal", "null"] },
        surplus_mine_water_supplied_kl: { bsonType: ["double", "int", "long", "decimal", "null"] }
      }
    }
  },

  plantation_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "activity_date"],
      properties: {
        target_area_ha: { bsonType: ["double", "int", "decimal", "null"] },
        achieved_area_ha: { bsonType: ["double", "int", "decimal", "null"] },
        saplings_planted: { bsonType: ["int", "long", "double", "null"] },
        survival_rate_pct: { bsonType: ["double", "int", "decimal", "null"] }
      }
    }
  },

  reclamation_records: {
    $jsonSchema: {
      bsonType: "object",
      required: ["mine_id", "assessment_date"],
      properties: {
        disturbed_area_ha: { bsonType: ["double", "int", "decimal", "null"] },
        technically_reclaimed_area_ha: { bsonType: ["double", "int", "decimal", "null"] },
        biologically_reclaimed_area_ha: { bsonType: ["double", "int", "decimal", "null"] },
        reclamation_status: { bsonType: ["string", "null"] }
      }
    }
  },

  csr_expenditure: {
    $jsonSchema: {
      bsonType: "object",
      required: ["period_start", "period_end", "amount_crore"],
      properties: {
        sector: { bsonType: ["string", "null"] },
        amount_crore: { bsonType: ["double", "int", "decimal"] },
        beneficiaries_count: { bsonType: ["int", "long", "double", "null"] }
      }
    }
  },
  grievances: {
    $jsonSchema: {
      bsonType: "object",
      required: ["text", "status", "created_at"],
      properties: {
        text: { bsonType: "string" },
        mine_id: { bsonType: "string" },
        worker_id: { bsonType: ["string", "null"] },
        geo: { bsonType: ["array", "null"] },
        status: { bsonType: "string" }
      }
    }
  },
  report_instances: {
    $jsonSchema: {
      bsonType: "object",
      required: ["report_code", "reporting_period_start", "reporting_period_end", "status"],
      properties: {
        report_code: { bsonType: "string" },
        status: { enum: ["draft", "validated", "review", "approved", "submitted", "rejected"] },
        input_snapshot_hash: { bsonType: ["string", "null"] },
        model_version: { bsonType: ["string", "null"] }
      }
    }
  }
};

const INDEXES = {
  users: [
    { key: { employee_id: 1 }, options: { unique: true, name: "uq_employee_id" } },
    { key: { mine_id: 1, role: 1 }, options: { name: "ix_mine_role" } }
  ],
  areas: [{ key: { coalfield_id: 1, name: 1 }, options: { name: "ix_area_coalfield_name" } }],
  mines: [
    { key: { area_id: 1, name: 1 }, options: { name: "ix_mine_area_name" } },
    { key: { coalfield_name: 1, type: 1 }, options: { name: "ix_mine_coalfield_type" } }
  ],

  compliance_requirements: [
    { key: { requirement_code: 1 }, options: { unique: true, name: "uq_requirement_code" } },
    { key: { category: 1, frequency: 1 }, options: { name: "ix_req_category_frequency" } }
  ],
  mine_compliance_conditions: [
    { key: { mine_id: 1, compliance_requirement_id: 1 }, options: { name: "ix_mine_condition_req" } },
    { key: { mine_id: 1, status: 1 }, options: { name: "ix_mine_condition_status" } }
  ],
  compliance_occurrences: [
    { key: { mine_id: 1, reporting_period_start: 1, reporting_period_end: 1 }, options: { name: "ix_occurrence_period" } },
    { key: { due_date: 1, status: 1 }, options: { name: "ix_occurrence_due_status" } },
    { key: { requirement_id: 1, status: 1 }, options: { name: "ix_occurrence_requirement_status" } }
  ],
  compliance_measurements: [
    { key: { mine_id: 1, measurement_date: 1 }, options: { name: "ix_measurement_mine_date" } },
    { key: { requirement_id: 1, measurement_date: 1 }, options: { name: "ix_measurement_req_date" } }
  ],
  compliance_violations: [
    { key: { mine_id: 1, detected_at: -1 }, options: { name: "ix_violation_mine_date" } },
    { key: { severity: 1, status: 1 }, options: { name: "ix_violation_severity_status" } }
  ],
  audit_findings: [
    { key: { mine_id: 1, audit_date: -1 }, options: { name: "ix_audit_mine_date" } },
    { key: { status: 1, severity: 1 }, options: { name: "ix_audit_status_severity" } }
  ],
  regulatory_deadlines: [
    { key: { mine_id: 1, due_date: 1 }, options: { name: "ix_reg_deadline_mine_due" } },
    { key: { authority_id: 1, due_date: 1 }, options: { name: "ix_reg_deadline_authority_due" } }
  ],
  regulatory_notices: [
    { key: { mine_id: 1, status: 1 }, options: { name: "ix_notice_mine_status" } }
  ],

  production_records: [
    { key: { mine_id: 1, production_date: 1 }, options: { name: "ix_production_mine_date" } },
    { key: { area_id: 1, production_date: 1 }, options: { name: "ix_production_area_date" } },
    { key: { coalfield_id: 1, production_date: 1 }, options: { name: "ix_production_coalfield_date" } },
    { key: { production_date: 1, shift_id: 1 }, options: { name: "ix_production_date_shift" } }
  ],
  production_target_records: [
    { key: { scope_type: 1, scope_id: 1, period_start: 1, period_end: 1 }, options: { name: "ix_target_scope_period" } },
    { key: { target_type: 1, period_start: 1, period_end: 1 }, options: { name: "ix_target_type_period" } }
  ],
  dispatch_records: [
    { key: { dispatch_date: 1, mine_id: 1 }, options: { name: "ix_dispatch_date_mine" } },
    { key: { dispatch_date: 1, mode: 1, sector: 1, product_type: 1 }, options: { name: "ix_dispatch_dimensions" } }
  ],
  washery_operations: [
    { key: { washery_id: 1, operation_date: 1 }, options: { name: "ix_washery_date" } }
  ],
  stockpile_records: [
    { key: { mine_id: 1, stock_date: -1 }, options: { name: "ix_stock_mine_date" } }
  ],
  equipment_daily_performance: [
    { key: { mine_id: 1, as_of_date: -1, equipment_type: 1 }, options: { name: "ix_equipment_perf" } }
  ],
  mine_capacity_records: [
    { key: { mine_id: 1, period_start: 1, period_end: 1 }, options: { name: "ix_capacity_period" } }
  ],
  wagon_loading_records: [
    { key: { railway_field: 1, loading_date: 1 }, options: { name: "ix_wagon_field_date" } }
  ],
  coal_quality_records: [
    { key: { mine_id: 1, sample_date: 1 }, options: { name: "ix_quality_mine_date" } },
    { key: { conformity_status: 1, sample_date: 1 }, options: { name: "ix_quality_status_date" } }
  ],

  accidents: [
    { key: { mine_id: 1, event_datetime: -1 }, options: { name: "ix_accident_mine_datetime" } },
    { key: { event_class: 1, event_datetime: -1 }, options: { name: "ix_accident_class_datetime" } }
  ],
  incidents: [
    { key: { mine_id: 1, event_datetime: -1 }, options: { name: "ix_incident_mine_datetime" } }
  ],
  near_misses: [
    { key: { mine_id: 1, event_datetime: -1 }, options: { name: "ix_nearmiss_mine_datetime" } }
  ],
  safety_observations: [
    { key: { mine_id: 1, observed_at: -1 }, options: { name: "ix_safety_obs_mine_time" } },
    { key: { severity: 1, status: 1 }, options: { name: "ix_safety_obs_severity_status" } }
  ],
  safety_exposure_records: [
    { key: { mine_id: 1, period_start: 1, period_end: 1 }, options: { name: "ix_exposure_period" } }
  ],
  safety_program_activities: [
    { key: { mine_id: 1, activity_date: -1, activity_type: 1 }, options: { name: "ix_safety_activity" } }
  ],
  rescue_readiness_records: [
    { key: { site_id: 1, as_of_date: -1 }, options: { name: "ix_rescue_readiness" } }
  ],
  statutory_manpower_snapshots: [
    { key: { mine_id: 1, as_of_date: -1 }, options: { name: "ix_statutory_manpower_date" } }
  ],

  air_quality: [
    { key: { mine_id: 1, measured_at: -1 }, options: { name: "ix_air_mine_time" } }
  ],
  water_quality: [
    { key: { mine_id: 1, measured_at: -1 }, options: { name: "ix_water_quality_mine_time" } }
  ],
  groundwater: [
    { key: { mine_id: 1, measured_at: -1 }, options: { name: "ix_groundwater_mine_time" } }
  ],
  noise_monitoring: [
    { key: { mine_id: 1, measured_at: -1 }, options: { name: "ix_noise_mine_time" } }
  ],
  environmental_samples: [
    { key: { mine_id: 1, sampled_at: -1 }, options: { name: "ix_env_sample_mine_time" } }
  ],
  water_resource_records: [
    { key: { mine_id: 1, period_start: 1, period_end: 1 }, options: { name: "ix_water_resource_period" } }
  ],
  energy_records: [
    { key: { mine_id: 1, period_start: 1, energy_type: 1 }, options: { name: "ix_energy_period" } }
  ],
  fuel_consumption_records: [
    { key: { mine_id: 1, period_start: 1, fuel_type: 1 }, options: { name: "ix_fuel_period" } }
  ],
  emissions_records: [
    { key: { mine_id: 1, period_start: 1, emission_type: 1 }, options: { name: "ix_emissions_period" } }
  ],
  waste_records: [
    { key: { mine_id: 1, period_start: 1, waste_type: 1 }, options: { name: "ix_waste_period" } }
  ],
  plantation_records: [
    { key: { mine_id: 1, activity_date: -1 }, options: { name: "ix_plantation_mine_date" } }
  ],
  reclamation_records: [
    { key: { mine_id: 1, assessment_date: -1 }, options: { name: "ix_reclamation_mine_date" } }
  ],
  forest_monitoring: [
    { key: { project_id: 1, event_date: -1 }, options: { name: "ix_forest_project_date" } }
  ],
  renewable_energy_projects: [
    { key: { project_name: 1 }, options: { name: "ix_renewable_project_name" } }
  ],
  sustainability_projects: [
    { key: { project_type: 1, project_status: 1 }, options: { name: "ix_sustainability_project_status" } }
  ],
  csr_expenditure: [
    { key: { period_start: 1, sector: 1 }, options: { name: "ix_csr_period_sector" } }
  ],
  social_metrics: [
    { key: { metric_date: 1, metric_type: 1 }, options: { name: "ix_social_metric_date_type" } }
  ],

  sensor_readings: [
    { key: { sensor_id: 1, recorded_at: -1 }, options: { name: "ix_sensor_time" } }
  ],
  cctv_events: [
    { key: { mine_id: 1, detected_at: -1, event_type: 1 }, options: { name: "ix_cctv_event" } }
  ],

  documents: [
    { key: { linked_collection: 1, linked_record_id: 1 }, options: { name: "ix_document_link" } }
  ],
  evidence: [
    { key: { linked_collection: 1, linked_record_id: 1 }, options: { name: "ix_evidence_link" } }
  ],
  audit_log: [
    { key: { record_type: 1, record_id: 1, timestamp: -1 }, options: { name: "ix_audit_record_time" } },
    { key: { actor_id: 1, timestamp: -1 }, options: { name: "ix_audit_actor_time" } }
  ],
  blockchain_records: [
    { key: { record_type: 1, record_id: 1 }, options: { name: "ix_blockchain_record" } }
  ],

  report_definitions: [
    { key: { report_code: 1 }, options: { unique: true, name: "uq_report_code" } }
  ],
  report_metric_contracts: [
    { key: { report_code: 1, metric_code: 1 }, options: { unique: true, name: "uq_report_metric" } },
    { key: { report_code: 1, section_code: 1 }, options: { name: "ix_report_section" } }
  ],
  report_instances: [
    { key: { report_code: 1, reporting_period_start: 1, reporting_period_end: 1 }, options: { name: "ix_report_instance_period" } },
    { key: { status: 1, generated_at: -1 }, options: { name: "ix_report_instance_status" } }
  ],
  report_artifacts: [
    { key: { report_instance_id: 1, artifact_type: 1 }, options: { name: "ix_report_artifact" } }
  ],
  metric_snapshots: [
    { key: { report_instance_id: 1, metric_code: 1 }, options: { name: "ix_metric_snapshot" } }
  ],
  data_quality_checks: [
    { key: { report_code: 1, run_at: -1 }, options: { name: "ix_dq_report_run" } }
  ],
  data_quality_issues: [
    { key: { report_code: 1, severity: 1, status: 1 }, options: { name: "ix_dq_issue" } }
  ],

  alerts: [
    { key: { recipient_id: 1, acknowledged_at: 1 }, options: { name: "ix_alert_recipient_ack" } }
  ],
  reminders: [
    { key: { recipient_id: 1, due_date: 1, status: 1 }, options: { name: "ix_reminder_due" } }
  ],
  escalations: [
    { key: { source_collection: 1, source_record_id: 1, timestamp: -1 }, options: { name: "ix_escalation_source_time" } }
  ],
  grievances: [
    { key: { mine_id: 1, status: 1 }, options: { name: "ix_grievance_mine_status" } },
    { key: { status: 1, created_at: -1 }, options: { name: "ix_grievance_status_created" } }
  ],
  analytics_results: [
    { key: { record_id: 1, model_type: 1, generated_at: -1 }, options: { name: "ix_analytics_record_model_time" } },
    { key: { mine_id: 1, model_type: 1, generated_at: -1 }, options: { name: "ix_analytics_mine_model_time" } }
  ]
};

// These are report families, not legal rules. They are safe to seed because
// they describe the application/reporting architecture rather than law.
const REPORT_DEFINITIONS = [
  {
    report_code: "COMPLIANCE",
    name: "Compliance Report",
    frequencies: ["monthly", "quarterly", "annual"],
    authority_scope: "mine_company_regulatory",
    deterministic_metrics_required: true,
    human_approval_required: true
  },
  {
    report_code: "PRODUCTION_DAILY",
    name: "Daily Production & Operations Report",
    frequencies: ["daily"],
    authority_scope: "mine_area_company",
    deterministic_metrics_required: true,
    human_approval_required: true
  },
  {
    report_code: "SAFETY_MONTHLY",
    name: "Monthly Safety Report",
    frequencies: ["monthly"],
    authority_scope: "mine_area_company",
    deterministic_metrics_required: true,
    human_approval_required: true
  },
  {
    report_code: "SUSTAINABILITY_ANNUAL",
    name: "Annual Sustainability Report",
    frequencies: ["annual"],
    authority_scope: "company",
    deterministic_metrics_required: true,
    human_approval_required: true
  }
];

async function ensureCollection(db, name, validator = null) {
  const existing = await db.listCollections({ name }).toArray();

  if (!existing.length) {
    const options = {
      validator: validator || { $jsonSchema: { bsonType: "object" } },
      validationLevel: "moderate",
      validationAction: "error"
    };
    await db.createCollection(name, options);
    console.log(`Created collection: ${name}`);
    return;
  }

  // Update validator without dropping existing documents.
  try {
    await db.command({
      collMod: name,
      validator: validator || { $jsonSchema: { bsonType: "object" } },
      validationLevel: "moderate",
      validationAction: "error"
    });
  } catch (err) {
    console.warn(`Validator update skipped for ${name}: ${err.message}`);
  }
}

async function ensureIndexes(db, collectionName, definitions = []) {
  if (!definitions.length) return;
  const collection = db.collection(collectionName);

  for (const index of definitions) {
    try {
      await collection.createIndex(index.key, index.options);
    } catch (err) {
      console.warn(
        `Index skipped ${collectionName}/${index.options?.name || JSON.stringify(index.key)}: ${err.message}`
      );
    }
  }
}

async function seedReportArchitecture(db) {
  const reports = db.collection("report_definitions");
  const contracts = db.collection("report_metric_contracts");

  for (const report of REPORT_DEFINITIONS) {
    await reports.updateOne(
      { report_code: report.report_code },
      { $set: report, $setOnInsert: { created_at: new Date() } },
      { upsert: true }
    );
  }

  // Full metric definitions live in report_data_contracts.json.
  // Keeping this collection initialized allows the later report generator
  // to ingest the JSON directly without changing the DB architecture.
  console.log("Seeded report family definitions.");
  console.log("Load report_data_contracts.json into report_metric_contracts when deploying the report engine.");
}

async function main() {
  const client = new MongoClient(MONGODB_URI);

  try {
    await client.connect();
    const db = client.db(DB_NAME);

    console.log(`Connected. Initializing database: ${DB_NAME}`);

    for (const name of COLLECTIONS) {
      await ensureCollection(db, name, VALIDATORS[name] || null);
    }

    for (const [collectionName, definitions] of Object.entries(INDEXES)) {
      await ensureIndexes(db, collectionName, definitions);
    }

    await seedReportArchitecture(db);

    console.log(`Initialization complete.`);
    console.log(`Collections configured: ${COLLECTIONS.length}`);
    console.log(`Important: do not use the LLM as the source of numeric/legal truth.`);
  } finally {
    await client.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
