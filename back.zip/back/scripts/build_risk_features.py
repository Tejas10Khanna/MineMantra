
"""
Build the LIVE risk-model feature vector from MongoDB.

This is the critical bridge between the governance DB and the XGBoost model.

The model-facing fields exactly match the uploaded narrator/model interface:
  violation_count_30d
  violation_count_90d
  overdue_capa_count
  avg_capa_age_days
  accident_count_365d
  fatality_count_365d
  inspection_count_90d
  days_since_last_inspection
  production_deviation_pct
  star_rating
  mine_type_UG
  strata_alert_count_30d
  hemm_proximity_alert_count_30d
  gas_dust_breach_count_30d
  electrical_fault_count_30d

Important:
- This script only assembles features.
- The trained model calculates the prediction.
- Missing values are explicit errors by default; silently inventing defaults
  would make the model output non-defensible.
"""

from datetime import datetime, timedelta, timezone


RISK_FEATURES = [
    "violation_count_30d",
    "violation_count_90d",
    "overdue_capa_count",
    "avg_capa_age_days",
    "accident_count_365d",
    "fatality_count_365d",
    "inspection_count_90d",
    "days_since_last_inspection",
    "production_deviation_pct",
    "star_rating",
    "mine_type_UG",
    "strata_alert_count_30d",
    "hemm_proximity_alert_count_30d",
    "gas_dust_breach_count_30d",
    "electrical_fault_count_30d",
]


def _count(coll, query):
    return coll.count_documents(query)


def build_features(db, mine_id, as_of=None):
    as_of = as_of or datetime.now(timezone.utc)
    d30 = as_of - timedelta(days=30)
    d90 = as_of - timedelta(days=90)
    d365 = as_of - timedelta(days=365)

    violations_30 = _count(db.compliance_violations,
                            {"mine_id": mine_id, "detected_at": {"$gte": d30, "$lte": as_of}})
    violations_90 = _count(db.compliance_violations,
                            {"mine_id": mine_id, "detected_at": {"$gte": d90, "$lte": as_of}})

    overdue_capa = _count(
        db.corrective_actions,
        {"mine_id": mine_id, "due_date": {"$lt": as_of},
         "status": {"$nin": ["closed", "verified"]}}
    )

    capa_docs = list(db.corrective_actions.find(
        {"mine_id": mine_id, "created_at": {"$gte": d90, "$lte": as_of}},
        {"created_at": 1, "closed_at": 1}
    ))
    ages = []
    for x in capa_docs:
        created = x.get("created_at")
        closed = x.get("closed_at") or as_of
        if created:
            ages.append(max(0.0, (closed - created).total_seconds() / 86400))
    avg_capa_age = sum(ages) / len(ages) if ages else 0.0

    accident_count = _count(db.accidents,
                             {"mine_id": mine_id, "event_datetime": {"$gte": d365, "$lte": as_of}})
    fatality_count = db.accidents.count_documents(
        {"mine_id": mine_id, "event_datetime": {"$gte": d365, "$lte": as_of},
         "event_class": "fatal_accident"}
    )

    inspection_count = _count(db.inspections,
                               {"mine_id": mine_id, "timestamp": {"$gte": d90, "$lte": as_of}})
    last_insp = db.inspections.find_one(
        {"mine_id": mine_id, "timestamp": {"$lte": as_of}},
        sort=[("timestamp", -1)]
    )
    days_since_last_inspection = (
        (as_of - last_insp["timestamp"]).total_seconds() / 86400
        if last_insp else None
    )

    # Production deviation: use model/report target records when available.
    # We deliberately return None rather than manufacturing a target.
    production_deviation = None

    mine = db.mines.find_one({"_id": mine_id})
    if mine is None:
        mine = db.mines.find_one({"mine_id": mine_id})
    mine_type_ug = 1 if mine and mine.get("type") == "UG" else 0

    # These are explicit integration points for CV/IoT/safety model outputs.
    strata_alerts = _count(db.alerts, {"mine_id": mine_id, "type": "strata_alert",
                                       "sent_at": {"$gte": d30, "$lte": as_of}})
    proximity_alerts = _count(db.alerts, {"mine_id": mine_id, "type": "hemm_proximity_alert",
                                          "sent_at": {"$gte": d30, "$lte": as_of}})
    gas_dust_breaches = _count(db.alerts, {"mine_id": mine_id, "type": "gas_dust_breach",
                                           "sent_at": {"$gte": d30, "$lte": as_of}})
    electrical_faults = _count(db.equipment_faults, {"mine_id": mine_id,
                                                      "detected_at": {"$gte": d30, "$lte": as_of},
                                                      "category": "electrical"})

    # These two fields need authoritative master data / a specific model input.
    # Fail closed instead of guessing.
    star_rating = None

    features = {
        "violation_count_30d": violations_30,
        "violation_count_90d": violations_90,
        "overdue_capa_count": overdue_capa,
        "avg_capa_age_days": round(avg_capa_age, 2),
        "accident_count_365d": accident_count,
        "fatality_count_365d": fatality_count,
        "inspection_count_90d": inspection_count,
        "days_since_last_inspection": days_since_last_inspection,
        "production_deviation_pct": production_deviation,
        "star_rating": star_rating,
        "mine_type_UG": mine_type_ug,
        "strata_alert_count_30d": strata_alerts,
        "hemm_proximity_alert_count_30d": proximity_alerts,
        "gas_dust_breach_count_30d": gas_dust_breaches,
        "electrical_fault_count_30d": electrical_faults,
    }

    missing = [k for k in RISK_FEATURES if features.get(k) is None]
    if missing:
        raise ValueError(
            "Cannot build a defensible risk feature vector; missing: "
            + ", ".join(missing)
            + ". Populate these from authoritative DB sources or revise the model contract."
        )

    return features
