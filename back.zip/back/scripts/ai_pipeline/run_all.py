"""
Runs every AI pipeline + the escalation worker in sequence.
This is the single cron entry point for the whole AI layer.

Suggested schedule (crontab -e):
    */15 * * * *  cd /path/to/back/scripts/ai_pipeline && python3 escalation_worker.py
    0 * * * *     cd /path/to/back/scripts/ai_pipeline && python3 run_all.py
    0 6 * * *     cd /path/to/back/scripts/ai_pipeline && python3 run_maintenance_reminders.py

(escalation_worker runs more often than the model pipelines since SLA
breaches need checking frequently, not just once an hour)
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEPS = [
    "run_risk_scoring.py",
    "run_anomaly_detection.py",
    "run_grievance_triage.py",
    "run_maintenance_reminders.py",
    "escalation_worker.py",
]

if __name__ == "__main__":
    for step in STEPS:
        print(f"\n{'='*60}\n{step}\n{'='*60}")
        result = subprocess.run([sys.executable, str(HERE / step)])
        if result.returncode != 0:
            print(f"FAILED: {step} (continuing with remaining steps)")
    print("\nAll pipeline steps attempted.")
