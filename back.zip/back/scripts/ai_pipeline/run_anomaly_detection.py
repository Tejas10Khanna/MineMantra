"""
Production Anomaly Pipeline (live)
=====================================
Reads `production_model_inputs` (already schema-matched by
initialize_model_compat_v3.js), runs the same Isolation Forest logic as
the anomaly_detection model, writes flagged anomalies to
`analytics_results`, and raises ANOMALY_DETECTED alerts for the most
recent day's flags.

Prophet is intentionally skipped here (optional dependency, same
graceful-degradation pattern as the standalone anomaly_model.py) -- add it
back the same way if you want seasonal-residual detection in production
too.

Run:
    python3 run_anomaly_detection.py               # last 120 days, all mines
    python3 run_anomaly_detection.py --days 30
"""
import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
from db import get_db  # noqa: E402
from alert_service import create_alert  # noqa: E402

FEATURES = [
    "production_tonnes_dev_from_roll7",
    "dispatch_tonnes_dev_from_roll7",
    "equipment_downtime_hours_dev_from_roll7",
    "dispatch_to_production_ratio",
    "downtime_per_active_equip",
]


def load_recent(db, days):
    since = datetime.now(timezone.utc) - timedelta(days=days)
    cursor = db.production_model_inputs.find({"date": {"$gte": since}})
    df = pd.DataFrame(list(cursor))
    if df.empty:
        return df
    df = df.sort_values(["mine_id", "date"]).reset_index(drop=True)
    return df


def engineer_features(df):
    df = df.copy()
    g = df.groupby("mine_id")
    for col in ["production_tonnes", "dispatch_tonnes", "equipment_downtime_hours"]:
        roll_mean = g[col].transform(lambda s: s.rolling(7, min_periods=3).mean())
        df[f"{col}_dev_from_roll7"] = (df[col] - roll_mean) / roll_mean.replace(0, np.nan)
    df["dispatch_to_production_ratio"] = df["dispatch_tonnes"] / df["production_tonnes"].replace(0, np.nan)
    df["downtime_per_active_equip"] = df["equipment_downtime_hours"] / df["active_equipment_count"].replace(0, np.nan)
    return df.fillna(0)


def run_isolation_forest(df, contamination=0.03):
    df = df.copy()
    df["if_anomaly"] = False
    df["if_score"] = 0.0
    for mine_id, sub in df.groupby("mine_id"):
        if len(sub) < 15:
            continue  # not enough history for a meaningful per-mine model yet
        X = StandardScaler().fit_transform(sub[FEATURES].values)
        model = IsolationForest(n_estimators=200, contamination=contamination, random_state=42)
        preds = model.fit_predict(X)
        scores = -model.score_samples(X)
        df.loc[sub.index, "if_anomaly"] = preds == -1
        df.loc[sub.index, "if_score"] = scores
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=120)
    args = ap.parse_args()

    db = get_db()
    df = load_recent(db, args.days)
    if df.empty:
        print("No rows in production_model_inputs for the requested window -- "
              "nothing to analyze. Run scripts/ingest_prototype_data.py first, "
              "or wait for live ERP/SCADA data to populate this collection.")
        return

    df = engineer_features(df)
    df = run_isolation_forest(df)

    flagged = df[df["if_anomaly"]]
    now = datetime.now(timezone.utc)
    most_recent_date = df["date"].max()

    for _, row in flagged.iterrows():
        db.analytics_results.insert_one({
            "model_type": "production_anomaly",
            "model_version": "isolation_forest_v1",
            "mine_id": row["mine_id"],
            "record_id": f"{row['mine_id']}_{row['date'].date()}",
            "score_or_label": round(float(row["if_score"]), 3),
            "anomaly_date": row["date"],
            "details": {
                "production_tonnes": row["production_tonnes"],
                "dispatch_tonnes": row["dispatch_tonnes"],
                "equipment_downtime_hours": row["equipment_downtime_hours"],
                "dispatch_to_production_ratio": round(float(row["dispatch_to_production_ratio"]), 3),
            },
            "generated_at": now,
        })

        # Only alert on anomalies from the most recent day in the window,
        # to avoid re-alerting on the same historical anomaly every run.
        if row["date"] == most_recent_date:
            create_alert(
                db,
                alert_type="ANOMALY_DETECTED",
                severity="high" if row["if_score"] > 0.65 else "medium",
                mine_id=row["mine_id"],
                title=f"Unusual production pattern at {row.get('mine_name', row['mine_id'])}",
                message=(f"On {row['date'].date()}: production={row['production_tonnes']}t, "
                         f"dispatch={row['dispatch_tonnes']}t, "
                         f"downtime={row['equipment_downtime_hours']}h. "
                         f"Dispatch/production ratio {row['dispatch_to_production_ratio']:.2f} "
                         f"deviates from this mine's recent baseline."),
                recommended_action="Verify shift logs and weighbridge records; confirm no unreported incident.",
                department="operations",
                responsible_role="project_manager",
                source_collection="production_model_inputs",
                source_record_id=str(row.get("_id")),
                model_version="isolation_forest_v1",
            )

    print(f"Analyzed {len(df)} mine-days across {df['mine_id'].nunique()} mines. "
          f"Flagged {len(flagged)} anomalies total, "
          f"{len(flagged[flagged['date'] == most_recent_date])} on the most recent date "
          f"({most_recent_date.date()}) -- alerts raised for those only.")


if __name__ == "__main__":
    main()
