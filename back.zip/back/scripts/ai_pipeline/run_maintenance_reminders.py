"""
Maintenance Reminder Job
==========================
Scans `equipment_maintenance` for upcoming/overdue scheduled maintenance
and creates personalized reminders for technical staff -- separate from
the alert system because these are routine scheduled tasks, not incidents:
lower urgency, no escalation chain by default (though overdue ones do get
escalated the same way alerts do, see escalation_worker.py).

Assumes `equipment_maintenance` documents have (at minimum): mine_id,
equipment_id, next_due_date. If your documents use different field names,
adjust FIELD_MAP below -- see README "Suggested DB additions" for the
recommended shape if this collection is still empty.

Run daily via cron:
    python3 run_maintenance_reminders.py --lookahead-days 7
"""
import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from db import get_db  # noqa: E402
from alert_service import create_reminder  # noqa: E402

FIELD_MAP = {
    "mine_id": "mine_id",
    "equipment_id": "equipment_id",
    "next_due_date": "next_due_date",
    "responsible_role": "responsible_role",  # optional; defaults below if absent
}
DEFAULT_TECHNICAL_ROLE = "technical_staff"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lookahead-days", type=int, default=7,
                     help="Remind this many days before the due date, in addition to overdue items")
    args = ap.parse_args()

    db = get_db()
    now = datetime.now(timezone.utc)
    horizon = now + timedelta(days=args.lookahead_days)

    due_soon = list(db.equipment_maintenance.find({
        FIELD_MAP["next_due_date"]: {"$lte": horizon}
    }))

    if not due_soon:
        print("No equipment_maintenance records due within the lookahead window. "
              "(Empty result also means: check that equipment_maintenance has been "
              "populated with next_due_date fields -- see README.)")
        return

    created = 0
    for record in due_soon:
        due_date = record.get(FIELD_MAP["next_due_date"])
        mine_id = record.get(FIELD_MAP["mine_id"])
        equipment_id = record.get(FIELD_MAP["equipment_id"])
        role = record.get(FIELD_MAP["responsible_role"]) or DEFAULT_TECHNICAL_ROLE

        # idempotency: don't create a duplicate reminder for the same
        # equipment+due_date if one already exists and is still pending
        existing = db.reminders.find_one({
            "equipment_id": equipment_id, "due_date": due_date,
            "reminder_type": "maintenance", "status": {"$in": ["pending", "overdue"]},
        })
        if existing:
            continue

        is_overdue = due_date < now
        create_reminder(
            db,
            reminder_type="maintenance",
            mine_id=mine_id,
            equipment_id=equipment_id,
            due_date=due_date,
            responsible_role=role,
            title=f"{'OVERDUE: ' if is_overdue else ''}Maintenance due for {equipment_id}",
            message=(f"Scheduled maintenance for equipment {equipment_id} at mine {mine_id} "
                     f"{'is overdue since' if is_overdue else 'is due on'} {due_date.date()}."),
            source_collection="equipment_maintenance",
            source_record_id=record["_id"],
        )
        created += 1

    print(f"Created {created} maintenance reminder(s) "
          f"({len(due_soon)} equipment records checked).")


if __name__ == "__main__":
    main()
