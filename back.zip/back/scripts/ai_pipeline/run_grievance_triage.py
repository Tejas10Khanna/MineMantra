"""
Grievance / Incident Text Triage Pipeline (live)
===================================================
Processes new free-text submissions (worker grievances, incident reports
from the mobile app) sitting in the `grievances` collection with
status="new": classifies category+intent (baseline TF-IDF+LogReg models
from grievance_nlp), routes to the right department/role via
grievance_common/routing.py + configs/taxonomy.yaml, writes the
classification back onto the grievance document, and raises a
personalized alert to the resolved department/role.

IMPORTANT: `grievances` is NOT one of the collections created by
scripts/initializeDatabase_v2.js -- it needs to be added. See
ai_pipeline/README.md "Suggested DB additions" for the exact document
shape the mobile app should write.

Also runs the recurring-pattern check (same category repeating at the
same mine within a rolling window) and raises RECURRING_VIOLATION alerts.

Run:
    python3 run_grievance_triage.py                 # process all status="new"
    python3 run_grievance_triage.py --recurring-only  # skip triage, just re-check patterns
"""
import argparse
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

import joblib

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent / "grievance_common" / ".."))
from db import get_db  # noqa: E402
from alert_service import create_alert  # noqa: E402
from grievance_common.taxonomy import Taxonomy  # noqa: E402
from grievance_common.triage import triage_one  # noqa: E402

MODELS_DIR = Path(__file__).resolve().parent / "models"
RECURRING_WINDOW_DAYS = 30
RECURRING_THRESHOLD = 3


def load_models():
    category_model = joblib.load(MODELS_DIR / "category_id_classifier.joblib")
    intent_model = joblib.load(MODELS_DIR / "intent_classifier.joblib")
    taxonomy = Taxonomy()
    return category_model, intent_model, taxonomy


def triage_new_submissions(db, category_model, intent_model, taxonomy):
    new_docs = list(db.grievances.find({"status": "new"}))
    if not new_docs:
        print("No new grievances to triage.")
        return

    for g in new_docs:
        record = triage_one(
            g["text"], taxonomy, category_model, intent_model,
            mine_id=g.get("mine_id"), geo=g.get("geo"), worker_id=g.get("worker_id"),
        )

        db.grievances.update_one(
            {"_id": g["_id"]},
            {"$set": {
                "status": "triaged" if not record["needs_human_review"] else "needs_review",
                "category_id": record["category_id"],
                "category_label": record["category_label"],
                "category_confidence": record["category_confidence"],
                "domain": record["domain"],
                "department": record["department"],
                "responsible_role": record["responsible_role"],
                "intent": record["intent"],
                "priority": record["priority"],
                "sla_deadline": record["sla_deadline"],
                "triaged_at": datetime.now(timezone.utc),
                "model_version": record["model_version"],
            }}
        )

        create_alert(
            db,
            alert_type="GRIEVANCE_SUBMITTED",
            severity=record["priority"],
            mine_id=g.get("mine_id"),
            title=f"New {record['category_label']} report",
            message=g["text"][:280],
            recommended_action=f"Route to {record['department']} for review"
                                + (" -- LOW CONFIDENCE, verify category before acting" if record["needs_human_review"] else ""),
            department=record["department"],
            responsible_role=record["responsible_role"],
            source_collection="grievances",
            source_record_id=g["_id"],
            sla_hours=record["sla_hours"],
            model_version=record["model_version"],
        )
    print(f"Triaged {len(new_docs)} new grievance(s).")


def check_recurring_patterns(db):
    """Counts (mine_id, category_id) occurrences among recently triaged
    grievances and raises a RECURRING_VIOLATION alert for patterns crossing
    the threshold -- language-agnostic since it counts on category_id,
    which the classifier already resolves regardless of source language."""
    since = datetime.now(timezone.utc) - timedelta(days=RECURRING_WINDOW_DAYS)
    docs = list(db.grievances.find({
        "triaged_at": {"$gte": since}, "category_id": {"$exists": True},
    }))

    buckets = defaultdict(list)
    for d in docs:
        buckets[(d.get("mine_id"), d["category_id"])].append(d)

    raised = 0
    for (mine_id, category_id), items in buckets.items():
        if len(items) < RECURRING_THRESHOLD:
            continue
        # avoid re-raising every run: check if we already alerted this
        # exact (mine, category) combo within the window
        existing = db.alerts.find_one({
            "alert_type": "RECURRING_VIOLATION", "mine_id": mine_id,
            "created_at": {"$gte": since},
            "message": {"$regex": items[0]["category_label"]},
        })
        if existing:
            continue

        create_alert(
            db,
            alert_type="RECURRING_VIOLATION",
            severity="critical" if len(items) >= RECURRING_THRESHOLD * 2 else "high",
            mine_id=mine_id,
            title=f"Recurring issue: {items[0]['category_label']}",
            message=(f"{len(items)} reports of '{items[0]['category_label']}' at this mine "
                     f"in the last {RECURRING_WINDOW_DAYS} days."),
            recommended_action="Root-cause review recommended -- treat as systemic, not one-off.",
            department=items[0].get("department"),
            responsible_role="area_general_manager",  # recurring issues escalate above single-mine manager
            source_collection="grievances",
            source_record_id=None,
        )
        raised += 1
    print(f"Recurring-pattern check: {raised} new alert(s) raised.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--recurring-only", action="store_true")
    args = ap.parse_args()

    db = get_db()
    if not args.recurring_only:
        category_model, intent_model, taxonomy = load_models()
        triage_new_submissions(db, category_model, intent_model, taxonomy)
    check_recurring_patterns(db)


if __name__ == "__main__":
    main()
