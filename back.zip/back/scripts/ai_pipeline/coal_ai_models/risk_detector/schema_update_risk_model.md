# Schema update — Compliance/Safety Risk model integration

## Why a change is needed

Your existing collections (`compliance_records`, `inspections`, `reports`, `mines`) store
**events**, not **features**. The XGBoost model needs rolling windows
(violations in the last 90 days, days since last inspection, etc.), computed
fresh every time you want a real-time score. Recomputing these from raw events
on every dashboard load is expensive at scale — so add one new collection that
stores the *computed feature snapshot* per mine, refreshed on a schedule or on
trigger (new incident), matching your retrain-trigger spec exactly.

## New collection: `risk_features`

```
risk_features
  _id, mine_id (ref), mine_name,               // denormalized, same pattern as your other collections
  period_start, period_end, computed_at,

  // --- exact feature vector the model consumes, in this order ---
  violation_count_30d,        // int  — count of compliance_records.checklist_items with status:"violation", last 30d
  violation_count_90d,        // int  — same, last 90d
  overdue_capa_count,         // int  — inspections.observations.corrective_action where status:"open" AND due_date < now
  avg_capa_age_days,          // float — mean(now - corrective_action.assigned_at) over open CAPAs
  accident_count_365d,        // int  — reports where category:"safety" AND severity:"accident", last 365d
  fatality_count_365d,        // int  — subset of above with severity:"fatality"
  inspection_count_90d,       // int  — count(inspections) for this mine, last 90d
  days_since_last_inspection, // int  — now - max(inspections.timestamp)
  production_deviation_pct,   // float — from production reporting module (Module 6), % vs target
  star_rating,                // int 1-7 — from Ministry of Coal Star Rating portal (real, per mine)
  mine_type_UG,               // 0|1 — derived from mines.type ("UG"|"OC")

  model_version,              // e.g. "risk-xgb-v1"
  risk_score,                 // float 0-100 — model output
  risk_band,                  // "low"|"medium"|"high"|"critical"
```

This is the collection your real-time inference job reads from and writes to.
It also becomes the natural source for `analytics_results` — write a row there
too (`model_type: "risk"`, `score_or_label: risk_score`) so your existing
read-only analytics pattern stays intact and the app doesn't need to know
`risk_features` exists at all if it only ever reads `analytics_results`.

## Minor additions to existing collections (to make feature computation possible)

**`mines`** — add:
```
type: "UG" | "OC"          // you already have this per the diagram, just confirming it's required, not optional
star_rating: int (1-7)     // add this field; seed from Star Rating of Coal Mines portal at onboarding, refresh yearly
production_target: number  // needed to compute production_deviation_pct
```

**`inspections.observations.corrective_action`** — you already have `status` and
`due_date`; add:
```
assigned_at: timestamp     // needed to compute avg_capa_age_days (you currently only track due_date, not start)
```

**`reports`** — your `category` enum is `"safety"|"machine"|"grievance"|"general"`.
Add a `severity` sub-field so accident/fatality counts can be derived without
NLP guessing:
```
severity: "minor" | "accident" | "fatality" | null   // required when category:"safety"
```

## Real-time data entry — what the app actually needs to collect

The model was trained on the feature list above, so your mobile/web forms
don't need to collect anything new beyond what's already in your `inspections`
and `reports` schema — the feature computation is a backend job, not a new
form. The only two *new manual entry points* are:

1. **`mines.star_rating`** — one-time/yearly entry by an authority user (pulled
   from the public Star Rating portal — not computed from your own data).
2. **`mines.production_target`** — set per mine by corporate/authority, so
   `production_deviation_pct` has a baseline to compare actual production against.

Everything else (violation counts, CAPA age, accident counts, inspection
recency) is derived automatically from data your supervisors are already
entering through `inspections` and `reports`.

## Real-time inference flow

```
new inspection/report saved
        │
        ▼
trigger: recompute risk_features for that mine_id
        │  (aggregation query over compliance_records/inspections/reports,
        │   windowed to 30d/90d/365d as above)
        ▼
call score_mine(feature_dict)  -> {score, band}
        │
        ▼
write risk_features.risk_score + risk_band
write analytics_results { model_type: "risk", score_or_label: risk_score, mine_id }
        │
        ▼
alerts collection: if band jumps to "critical" or crosses threshold,
create alert(type:"risk_escalation", recipient_role:"authority")
```

Retrain trigger (monthly, or on new incident) means: re-run `train_risk_model.py`
against the accumulated real `risk_features` history once you have enough real
rows (recommend 500+ mine-months before trusting real data over the synthetic
baseline) — swap `generate_synthetic_dataset()` for a query against your own
`risk_features` collection at that point.

## v2 addition — sensor-derived features (roof-fall, HEMM, gas/dust, electrical)

Four new features were added to `risk_features`, each mapping directly to
DGMS's own ranked causes of coal mine accidents rather than being an arbitrary
addition:

```
risk_features   (add to the existing field list)
  strata_alert_count_30d           // extensometer/tiltmeter triggers, UG mines
                                    // -> DGMS cause #1: roof/side falls
  hemm_proximity_alert_count_30d   // GPS/radar proximity alerts, OC mines
                                    // -> DGMS cause #2: surface transport
  gas_dust_breach_count_30d        // methane/dust threshold sensor breaches
                                    // -> DGMS cause #5: dust/gas/combustible material
  electrical_fault_count_30d       // trailing cable / switchgear fault alerts
                                    // -> DGMS cause #4: electricity
```

These are populated from sensor/IoT feeds (extensometers, radar units, gas
monitors, cable-fault detectors), not from manual form entry — same pattern
as `mine_type_UG`: derived, not typed in by a user. If your hackathon build
doesn't have real sensor hardware, simulate these as event streams in the
same shape so the model and the dashboard code don't need to change later.

Retrained model: R² improved from 0.88 -> 0.93 with these features added;
`strata_alert_count_30d` alone became the #2 overall driver of predicted
risk, right behind raw accident history — which matches the real-world DGMS
ranking (roof falls are consistently the leading cause of coal mine
fatalities in India).

## Audit narrative — `analytics_results.narrative`

Add one field to `analytics_results`:

```
analytics_results
  ... (existing fields unchanged) ...
  narrative: string   // human-readable explanation, generated per score
```

Do **not** put this in `audit_log` — that collection is explicitly
append-only and mechanical ("no PUT/PATCH/DELETE, ever targets this
collection" per your own schema note). The narrative is a richer read layer
on `analytics_results`, generated alongside the score, not a replacement for
the mechanical audit trail.

Generation logic (`generate_audit_narrative.py`): the LLM is given *only* the
structured output of `score_and_explain_features()` — the score, band, and
ranked contributing factors with their DGMS cause labels — and is instructed
to state no cause or number beyond what's in that input. This keeps every
sentence in the narrative traceable to a real feature value, which matters
if this narrative ever needs to be defended in an actual compliance audit.
