"""
Coal Guard — Audit Narrative Generator
========================================
Turns a risk-model output (score + top contributing factors) into a plain-
English audit log entry that an authority official can actually act on,
instead of a bare "risk_score: 53.9".

IMPORTANT — this is a narrator, not a second predictor:
The LLM is given ONLY the numeric contributions already computed by
XGBoost (see train_risk_model_v2.score_and_explain_features). It is
explicitly instructed not to invent causes, numbers, or recommendations
beyond what's in that structured input. This keeps the audit log
defensible -- every sentence traces back to a real feature value, not an
LLM guess. This is why it's a "digital twin" narrator over tabular data,
not a free-form chatbot.

Where this plugs into your schema:
  analytics_results._id, record_id, model_type:"risk", score_or_label,
  generated_at, mine_id
  -> add a field: narrative (string), populated by this script.
  The audit_log collection itself stays purely mechanical (who/what/when
  changed a record) per your existing "append-only, system-generated"
  design -- this narrative is a richer READ layer on top of analytics_results,
  not a replacement for the mechanical audit_log.

Run:
  export ANTHROPIC_API_KEY=sk-ant-...
  python3 generate_audit_narrative.py
"""

import os
import json
from datetime import datetime, timezone

MODEL = "claude-sonnet-5"

SYSTEM_PROMPT = """You write short audit-log narratives for an Indian coal mine \
compliance dashboard, read by mine officials, corporate management, and DGMS-style \
regulatory authorities.

Rules:
- Use ONLY the factors, values, and cause_rank labels given in the input JSON. \
Never invent a cause, statistic, or recommendation not implied by the given data.
- If a factor has a cause_rank (e.g. "DGMS cause #1: roof and side falls"), state \
that connection plainly -- this is what makes the log useful to a safety officer, \
not generic risk-speak.
- Write 3-5 sentences. Lead with the risk band and score, then the top 1-2 factors \
driving it, then one concrete, role-appropriate next action (e.g. "Overman and \
Safety Officer should inspect the cited panel within 24 hours" for a strata alert; \
"E&M engineer should verify isolation" for an electrical fault).
- Do not use the word "AI" or describe your own reasoning. Write as a factual \
incident/status note, not a chatbot response.
- Plain English, no bullet points, no markdown, no percentages beyond the score itself.
"""


def build_user_prompt(mine_name: str, result: dict) -> str:
    payload = {
        "mine_name": mine_name,
        "risk_score": result["score"],
        "risk_band": result["band"],
        "top_factors": result["top_factors"],
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    return (
        "Write the audit log narrative for this risk assessment. "
        "Input data:\n" + json.dumps(payload, indent=2)
    )


def generate_narrative(mine_name: str, result: dict) -> str:
    """
    result: output of train_risk_model_v2.score_and_explain_features()
            i.e. {"score": float, "band": str, "top_factors": [...]}
    """
    if not result["top_factors"]:
        return (
            f"{mine_name}: risk score {result['score']} ({result['band']}). "
            "No single factor is dominant -- risk is broadly distributed across "
            "routine compliance indicators. No immediate escalation required."
        )

    import anthropic  # deferred: only needed when an API key is actually set
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    response = client.messages.create(
        model=MODEL,
        max_tokens=300,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": build_user_prompt(mine_name, result)}],
    )
    return response.content[0].text.strip()


def fallback_template_narrative(mine_name: str, result: dict) -> str:
    """
    Deterministic, no-API-key fallback. Same information content as the LLM
    version, less fluent -- useful for offline demo / no-internet judging rooms.
    """
    lines = [f"{mine_name}: risk score {result['score']} ({result['band']})."]
    for f in result["top_factors"][:2]:
        cause = f" This corresponds to {f['cause_rank']}." if f["cause_rank"] else ""
        lines.append(f"Primary driver: {f['label']} (observed value: {f['value']}).{cause}")
    lines.append("Recommend site-level review by the relevant safety officer before next shift.")
    return " ".join(lines)


if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from train_risk_model_v2 import train, score_and_explain_features

    model = train()
    example = {
        "violation_count_30d": 3, "violation_count_90d": 9, "overdue_capa_count": 2,
        "avg_capa_age_days": 18.0, "accident_count_365d": 1, "fatality_count_365d": 0,
        "inspection_count_90d": 2, "days_since_last_inspection": 40,
        "production_deviation_pct": -8.0, "star_rating": 4, "mine_type_UG": 1,
        "strata_alert_count_30d": 6, "hemm_proximity_alert_count_30d": 0,
        "gas_dust_breach_count_30d": 3, "electrical_fault_count_30d": 1,
    }
    result = score_and_explain_features(model, example)
    print("Structured result:", json.dumps(result, indent=2, default=str))

    if os.environ.get("ANTHROPIC_API_KEY"):
        narrative = generate_narrative("Jharia Colliery, Block-4", result)
        print("\n--- LLM audit narrative ---")
    else:
        narrative = fallback_template_narrative("Jharia Colliery, Block-4", result)
        print("\n--- Fallback template narrative (no API key set) ---")
    print(narrative)
