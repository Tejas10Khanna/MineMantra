"""
Coal Guard — Compliance/Safety Risk model v2
==============================================
Adds four sensor-derived features mapped directly to DGMS's own ranked
causes of coal mine accidents (roof/side falls #1, transport #2,
dust/gas/combustible material #5, electricity #4). These are NOT synthetic
guesses about what matters -- they are the real official accident-cause
ranking, which is why they belong in the risk model rather than being a
separate "extra" module.

New features (on top of v1's violation/CAPA/accident/inspection set):
  strata_alert_count_30d     <- extensometer/tiltmeter triggers, UG mines
                                 (cause #1: roof/side falls)
  hemm_proximity_alert_count_30d <- GPS/radar proximity alerts, OC mines
                                 (cause #2: surface transport/collision)
  gas_dust_breach_count_30d  <- methane/respirable-dust threshold breaches
                                 (cause #5: dust/gas/combustible material)
  electrical_fault_count_30d <- trailing cable/switchgear fault alerts
                                 (cause #4: electricity)

Retrain trigger: unchanged (monthly, or on new incident).
"""

from pathlib import Path

import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

RNG_SEED = 42
N_MINES = 400
N_PERIODS = 12

FEATURE_COLUMNS = [
    "violation_count_30d",
    "violation_count_90d",
    "overdue_capa_count",
    "avg_capa_age_days",
    "accident_count_365d",
    "fatality_count_365d",
    "inspection_count_90d",
    "days_since_last_inspection",
    "production_deviation_pct",
    "star_rating",
    "mine_type_UG",
    # --- new sensor-derived features ---
    "strata_alert_count_30d",
    "hemm_proximity_alert_count_30d",
    "gas_dust_breach_count_30d",
    "electrical_fault_count_30d",
]

# Human-readable labels + the DGMS cause rank each feature maps to.
# Used later by the audit narrator, not by the model itself.
FEATURE_META = {
    "violation_count_30d":            {"label": "Statutory violations (30d)", "cause_rank": None},
    "violation_count_90d":            {"label": "Statutory violations (90d)", "cause_rank": None},
    "overdue_capa_count":             {"label": "Overdue corrective actions", "cause_rank": None},
    "avg_capa_age_days":              {"label": "Average age of open corrective actions", "cause_rank": None},
    "accident_count_365d":            {"label": "Accidents (past year)", "cause_rank": None},
    "fatality_count_365d":            {"label": "Fatalities (past year)", "cause_rank": None},
    "inspection_count_90d":           {"label": "Inspections carried out (90d)", "cause_rank": None},
    "days_since_last_inspection":     {"label": "Days since last inspection", "cause_rank": None},
    "production_deviation_pct":       {"label": "Production deviation from target", "cause_rank": None},
    "star_rating":                    {"label": "Ministry of Coal star rating", "cause_rank": None},
    "mine_type_UG":                   {"label": "Underground mine", "cause_rank": None},
    "strata_alert_count_30d":         {"label": "Strata/roof-fall early-warning alerts (extensometer/tiltmeter)", "cause_rank": "DGMS cause #1: roof and side falls"},
    "hemm_proximity_alert_count_30d": {"label": "HEMM proximity/collision alerts (GPS/radar)", "cause_rank": "DGMS cause #2: surface transport/machinery"},
    "gas_dust_breach_count_30d":      {"label": "Gas/dust threshold breaches (methane, respirable dust)", "cause_rank": "DGMS cause #5: dust/gas/combustible material"},
    "electrical_fault_count_30d":     {"label": "Electrical fault/isolation alerts (cables, switchgear)", "cause_rank": "DGMS cause #4: electricity"},
}

TARGET_COLUMN = "risk_score"


def generate_synthetic_dataset(n_mines=N_MINES, n_periods=N_PERIODS, seed=RNG_SEED):
    rng = np.random.default_rng(seed)
    rows = []

    for mine_id in range(n_mines):
        mine_type_ug = rng.binomial(1, 0.35)
        base_propensity = rng.beta(2, 5)
        star_rating = int(np.clip(round(rng.normal(5 - base_propensity * 4, 1.0)), 1, 7))

        for period in range(n_periods):
            lam90 = 2 + base_propensity * 10 + mine_type_ug * 1.5
            violation_90d = rng.poisson(lam90)
            violation_30d = rng.poisson(lam90 / 3)

            capa_open = rng.poisson(1 + violation_90d * 0.4)
            overdue_capa = rng.binomial(capa_open, min(0.15 + base_propensity * 0.5, 0.9))
            avg_capa_age = rng.gamma(2 + base_propensity * 4, 8)

            accident_365d = rng.poisson(0.3 + base_propensity * 2.5 + mine_type_ug * 0.4)
            fatality_365d = rng.binomial(1, min(0.02 + base_propensity * 0.08, 0.5)) if accident_365d > 0 else 0

            inspection_90d = rng.poisson(1.5 + base_propensity * 2)
            days_since_inspection = max(1, int(rng.exponential(45 - base_propensity * 20)))

            production_dev = rng.normal(0, 5 + base_propensity * 15)

            # sensor features: UG-specific (strata) vs OC-specific (HEMM), gas/dust and
            # electrical apply to both but weighted by propensity + mine type
            strata_alerts = rng.poisson((1 + base_propensity * 6) * mine_type_ug)
            hemm_alerts = rng.poisson((1 + base_propensity * 5) * (1 - mine_type_ug) * 1.2)
            gas_dust_breaches = rng.poisson(0.5 + base_propensity * 4 + mine_type_ug * 1.0)
            electrical_faults = rng.poisson(0.4 + base_propensity * 3)

            raw = (
                0.9 * violation_90d
                + 1.8 * overdue_capa
                + 0.02 * avg_capa_age
                + 6.0 * accident_365d
                + 20.0 * fatality_365d
                + 0.05 * abs(production_dev)
                - 1.2 * inspection_90d
                + 0.03 * days_since_inspection
                + 3.0 * mine_type_ug
                + (7 - star_rating) * 2.5
                # DGMS cause-weighted sensor terms -- roof falls carry the heaviest
                # real-world weight since they're DGMS's #1 cause, electricity/gas
                # next, transport slightly lower
                + 3.5 * strata_alerts
                + 2.0 * hemm_alerts
                + 2.2 * gas_dust_breaches
                + 1.8 * electrical_faults
            )
            noise = rng.normal(0, 4)
            risk_score = np.clip(raw + noise, 0, 100)

            rows.append({
                "mine_id": mine_id, "period": period,
                "violation_count_30d": violation_30d,
                "violation_count_90d": violation_90d,
                "overdue_capa_count": overdue_capa,
                "avg_capa_age_days": round(avg_capa_age, 1),
                "accident_count_365d": accident_365d,
                "fatality_count_365d": fatality_365d,
                "inspection_count_90d": inspection_90d,
                "days_since_last_inspection": days_since_inspection,
                "production_deviation_pct": round(production_dev, 2),
                "star_rating": star_rating,
                "mine_type_UG": mine_type_ug,
                "strata_alert_count_30d": strata_alerts,
                "hemm_proximity_alert_count_30d": hemm_alerts,
                "gas_dust_breach_count_30d": gas_dust_breaches,
                "electrical_fault_count_30d": electrical_faults,
                "risk_score": round(risk_score, 2),
            })

    return pd.DataFrame(rows)


def train():
    df = generate_synthetic_dataset()
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = XGBRegressor(
        n_estimators=300, max_depth=4, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, reg_lambda=1.0, random_state=42,
    )
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    print(f"Test MAE: {mean_absolute_error(y_test, pred):.2f}")
    print(f"Test R^2: {r2_score(y_test, pred):.3f}\n")
    print("Feature importances:")
    for feat, imp in sorted(zip(FEATURE_COLUMNS, model.feature_importances_), key=lambda x: -x[1]):
        print(f"  {feat:35s} {imp:.3f}")

    out_dir = Path(__file__).resolve().parent
    model.save_model(out_dir / "risk_model_v2.json")
    df.to_csv(out_dir / "synthetic_training_data.csv", index=False)
    return model


def score_and_explain_features(model, feature_dict: dict, top_n=4):
    """
    Returns score/band plus the top-N contributing features by
    (model importance x observed value's deviation from a "normal" baseline),
    each tagged with its DGMS cause-rank where applicable.
    This is the grounded input the LLM narrator consumes -- no hallucinated causes.
    """
    row = pd.DataFrame([{c: feature_dict[c] for c in FEATURE_COLUMNS}])
    score = float(np.clip(model.predict(row)[0], 0, 100))
    band = "low" if score < 25 else "medium" if score < 50 else "high" if score < 75 else "critical"

    importances = model.feature_importances_
    # simple, defensible "contribution" proxy: importance * normalized feature value
    baselines = {  # rough population medians from the training generator, for normalization
        "violation_count_30d": 2, "violation_count_90d": 6, "overdue_capa_count": 1,
        "avg_capa_age_days": 15, "accident_count_365d": 1, "fatality_count_365d": 0,
        "inspection_count_90d": 2, "days_since_last_inspection": 35,
        "production_deviation_pct": 0, "star_rating": 5, "mine_type_UG": 0,
        "strata_alert_count_30d": 1, "hemm_proximity_alert_count_30d": 1,
        "gas_dust_breach_count_30d": 1, "electrical_fault_count_30d": 1,
    }
    contributions = []
    for feat, imp in zip(FEATURE_COLUMNS, importances):
        val = feature_dict[feat]
        base = baselines[feat] or 1
        deviation = (val - base) / (abs(base) + 1)
        contributions.append({
            "feature": feat,
            "label": FEATURE_META[feat]["label"],
            "cause_rank": FEATURE_META[feat]["cause_rank"],
            "value": val,
            "contribution_score": round(imp * max(deviation, 0), 4),
        })

    top_factors = sorted(contributions, key=lambda x: -x["contribution_score"])[:top_n]
    top_factors = [f for f in top_factors if f["contribution_score"] > 0]

    return {"score": round(score, 1), "band": band, "top_factors": top_factors}


if __name__ == "__main__":
    m = train()
    example = {
        "violation_count_30d": 3, "violation_count_90d": 9, "overdue_capa_count": 2,
        "avg_capa_age_days": 18.0, "accident_count_365d": 1, "fatality_count_365d": 0,
        "inspection_count_90d": 2, "days_since_last_inspection": 40,
        "production_deviation_pct": -8.0, "star_rating": 4, "mine_type_UG": 1,
        "strata_alert_count_30d": 6, "hemm_proximity_alert_count_30d": 0,
        "gas_dust_breach_count_30d": 3, "electrical_fault_count_30d": 1,
    }
    result = score_and_explain_features(m, example)
    print("\nExample:", result)
