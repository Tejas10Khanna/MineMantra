# How to run

## 1. Install dependencies

```bash
pip install xgboost scikit-learn pandas numpy anthropic
```

## 2. Train the model (v2, with sensor features)

```bash
python3 train_risk_model_v2.py
```

This trains on synthetic data and saves `risk_model_v2.json`. Takes a few
seconds. Prints test MAE/R² and feature importances so you can confirm it
trained correctly (expect R² around 0.90-0.94).

## 3. Generate an audit narrative

**With an LLM (recommended, this is the "digital twin" narrator):**

```bash
export ANTHROPIC_API_KEY=sk-ant-your-key-here
python3 generate_audit_narrative.py
```

Get a key from https://console.anthropic.com if you don't have one — free
credits are available for new accounts, which is enough for a hackathon demo.

**Without an API key (offline fallback for demo rooms with no internet):**

Just run the same command without setting `ANTHROPIC_API_KEY` —
`generate_audit_narrative.py` automatically falls back to a deterministic
template narrative that carries the same information, just less fluent
prose. No code changes needed to switch between the two.

## 4. Wire it into your own pipeline (once you have real data)

Replace the `example` dict in `generate_audit_narrative.py`'s `__main__`
block with a real query:

```python
feature_dict = db.risk_features.find_one(
    {"mine_id": mine_id}, sort=[("computed_at", -1)]
)
result = score_and_explain_features(model, feature_dict)
narrative = generate_narrative(feature_dict["mine_name"], result)

db.analytics_results.update_one(
    {"_id": result_id},
    {"$set": {"narrative": narrative}}
)
```

## 5. Cost note

Each narrative call is one short Claude API request (~300 output tokens) —
trivial cost, and cheap enough to call on every new risk score computed,
not just periodically.
