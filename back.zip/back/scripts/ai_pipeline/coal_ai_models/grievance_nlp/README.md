# Grievance / Compliance NLP — Multilingual Triage Model

Row from the model plan this implements:

| Model | Training Data | Data Source | Approach | Retrain Cadence |
|---|---|---|---|---|
| NLP (grievance/compliance text) | Free-text reports and grievances | Bootstrap on public grievance-classification datasets (CPGRAMS-style categories); active-learn on real submissions; needs Hindi/regional support | Fine-tuned small transformer (IndicBERT/DistilBERT) → category/priority/intent | Continuous active learning |

Automates the manual triage step: worker submits free text -> system decides category
(-> department), intent, priority, and routes it with an SLA — the exact flow in the use
case (Hindi helmet grievance -> Safety Equipment category -> Mine Safety Officer -> High
priority -> 24h SLA).

## Status — read this before demoing

- **Pipeline: complete and tested end-to-end today**, on the baseline model (see "what
  actually ran" below).
- **Baseline model (live now): TF-IDF char n-gram + LogisticRegression.** Multilingual by
  construction (character n-grams work across Devanagari and Latin script without a
  language-specific tokenizer), trained on synthetic bootstrap data, running in this
  sandbox right now.
- **Transformer upgrade (IndicBERT/DistilBERT fine-tune): written, not yet run.** Needs
  internet (to pull pretrained weights from Hugging Face — confirmed blocked in this
  sandbox, huggingface.co returned 403) and a GPU. `scripts/03_train_transformer.py` is
  ready to run on a laptop or a free Colab GPU notebook; it fails with a clear message
  here rather than a stack trace.
- **Training/bootstrap data: synthetic**, same honesty constraint as the rest of the
  project — no public row-level dataset of real Indian coal-mine grievances exists.
  CPGRAMS's CATEGORY TAXONOMY is public and real (`configs/taxonomy.yaml` is modeled on
  it, extended with mine-specific departments); the actual grievance TEXT used to bootstrap
  training is synthetic, template-generated, and tagged `"synthetic": true` throughout.
- **Language ID: heuristic, not a trained model** (script-ratio + common-word check —
  see `common/lang_id.py` for exactly what it can and can't do). Works for Hindi/English/
  code-mixed, which covers most real traffic; doesn't distinguish other Devanagari-script
  languages or catch non-Hindi regional languages. Documented upgrade: `fasttext`'s
  `lid.176` model, needs a download this sandbox can't do.
- **Cross-language recurring-issue detection: real, tested, not a placeholder.** Because
  the category classifier resolves Hindi and English reports to the *same* category_id,
  counting repeat categories per mine already catches cross-language recurrence with no
  extra model — verified below with a live PPE-shortage example spanning Hindi and English.

## Pipeline

```
scripts/01_generate_synthetic_dataset.py  # multilingual bootstrap training data (synthetic, tagged)
scripts/02_train_baseline.py              # TF-IDF + LogisticRegression: category + intent
scripts/03_train_transformer.py           # IndicBERT/DistilBERT fine-tune (needs internet+GPU)
scripts/04_infer.py                       # SHORT single-issue reports: lang ID -> category -> intent -> routing -> SLA
scripts/05_cluster_recurring_issues.py    # cross-mine, cross-language recurring-pattern detection
scripts/06_active_learning.py             # review queue + confirmed-label accumulation + retrain trigger
scripts/07_triage_full_report.py          # LONG multi-issue reports: segments first, routes each issue separately
common/taxonomy.py, lang_id.py, routing.py, segment.py, triage.py   # shared logic
configs/taxonomy.yaml                     # the actual department/category/SLA table — edit this first
```

## What actually ran (verified in this sandbox)

```bash
python 01_generate_synthetic_dataset.py --n-per-category 60
# -> 960 synthetic examples across 16 categories

python 02_train_baseline.py
# -> category_id: 98% accuracy, intent: 100% accuracy (held-out SYNTHETIC data —
#    expect a real-world drop; that's exactly why active learning exists)

python 04_infer.py --text "आज हेलमेट नहीं मिला, बिना हेलमेट काम करना पड़ रहा है।" \
    --mine-id SECL-GEVRA-03 --lat 22.4109 --lon 82.6839
# -> language: hi | category: Safety Equipment / PPE Availability | department: Safety
#    Department | responsible_role: Mine Safety Officer | intent: complaint | priority: high
#    | sla_hours: 24
# This exactly reproduces the use-case narrative end-to-end.

python 05_cluster_recurring_issues.py --records batch_of_6_reports.jsonl --repeat-threshold 3
# -> flagged SECL-GEVRA-03 / PPE Availability as a recurring compliance failure,
#    5 occurrences, languages=['en', 'hi'] — cross-language recurrence detection confirmed live.
```

## Does it handle long, multi-issue reports?

Yes, via `07_triage_full_report.py` — but read `docs/full_reports.md` before demoing this.
It's tested against a real multi-issue example (verified: correctly split out a PPE issue
and a payment-delay issue into separate departmental cases), and also honestly documents
where it still falls short (one issue got merged into the wrong category; two filler
sentences slipped through as spurious low-confidence "issues" that a human has to dismiss).
`04_infer.py` alone is NOT suitable for long reports — it silently drops every issue but one.

## Department taxonomy

See `configs/taxonomy.yaml` for the full table. Departments covered (edit this file first if
your mine's actual org chart differs): Safety, Environment, Production/Mining Operations,
Mechanical & Electrical Engineering, Civil Engineering, Chemical & Explosives, Labour
Welfare, Contracts & Finance, Medical & Health, Vigilance/General Administration. Each
category maps to exactly one department, one responsible role, a default priority, and an
SLA — plus a rule-based safety-keyword override that bumps priority and tightens the SLA
regardless of ML confidence (kept auditable rather than left to the model alone).

## Quickstart

```bash
pip install -r requirements.txt   # sklearn/pandas only for the baseline; transformer deps commented out

python scripts/01_generate_synthetic_dataset.py
python scripts/02_train_baseline.py
python scripts/04_infer.py --text "your report here" --mine-id XYZ
python scripts/05_cluster_recurring_issues.py --records path/to/accumulated_reports.jsonl
python scripts/06_active_learning.py status
```
