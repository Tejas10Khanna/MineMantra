"""
Turns (category, intent, text) into a routing decision: department, responsible officer
role, priority, SLA deadline, and escalation chain. Kept rule-based on top of the ML
category prediction — safety-critical priority bumps should be auditable, not a black box.
"""
from datetime import datetime, timedelta, timezone

PRIORITY_ORDER = ["low", "medium", "high", "critical"]


def bump_priority(priority: str) -> str:
    idx = PRIORITY_ORDER.index(priority)
    return PRIORITY_ORDER[min(idx + 1, len(PRIORITY_ORDER) - 1)]


def route(category_id: str, text: str, taxonomy, submitted_at: datetime = None) -> dict:
    submitted_at = submitted_at or datetime.now(timezone.utc)

    dept = taxonomy.department_for(category_id)
    domain = taxonomy.domain_for(category_id)
    priority = taxonomy.default_priority(category_id)
    sla_hours = taxonomy.sla_hours(category_id)

    escalated_on_keyword = taxonomy.has_escalation_keyword(text)
    if escalated_on_keyword:
        priority = bump_priority(priority)
        sla_hours = max(4, sla_hours // 4)  # safety-critical keyword -> much tighter SLA

    deadline = submitted_at + timedelta(hours=sla_hours)

    return {
        "category_id": category_id,
        "category_label": taxonomy.categories[category_id]["label"],
        "domain": domain,
        "department": dept["label"],
        "responsible_role": dept["responsible_role"],
        "priority": priority,
        "priority_escalated_by_keyword": escalated_on_keyword,
        "sla_hours": sla_hours,
        "sla_deadline": deadline.isoformat(),
        "escalation_chain": taxonomy.sla_levels,
    }
