"""
Splits a long free-text report into sentence/clause-level segments, so each distinct issue
inside a multi-paragraph report can be triaged separately instead of the whole report being
forced into one category.

Splits on:
  - Hindi sentence-ending punctuation (danda ।) and standard punctuation (. ! ?)
  - a short list of topic-shift connector phrases common in spoken-style field reports
    ("iske alawa" / "इसके अलावा" = "besides this", "uske baad" / "उसके बाद" = "after that"),
    which often introduce a new issue within what's otherwise one run-on sentence
  - semicolons

Then drops segments too short to carry a real issue (greetings, "Sir,", trailing "thank you").
"""
import re

SENTENCE_SPLIT_PATTERN = re.compile(r"[।.!?;]+")

TOPIC_SHIFT_PHRASES = [
    "iske alawa", "इसके अलावा", "uske baad", "उसके बाद", "iske baad", "इसके बाद",
    "isके अलावा", "along with this", "in addition", "also,", "besides this",
]

MIN_SEGMENT_WORDS = 4  # shorter than this is almost never a standalone issue (e.g. "Sir,")


def segment_report(text: str) -> list[str]:
    # first split on punctuation
    rough_segments = [s.strip() for s in SENTENCE_SPLIT_PATTERN.split(text) if s.strip()]

    # then further split any segment that still contains a topic-shift phrase
    segments = []
    for seg in rough_segments:
        low = seg.lower()
        split_point = None
        for phrase in TOPIC_SHIFT_PHRASES:
            idx = low.find(phrase.lower())
            if idx > 0:
                split_point = idx
                break
        if split_point:
            segments.append(seg[:split_point].strip())
            segments.append(seg[split_point:].strip())
        else:
            segments.append(seg)

    return [s for s in segments if len(s.split()) >= MIN_SEGMENT_WORDS]
