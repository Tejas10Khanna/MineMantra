"""Shared per-text triage logic — used by both 04_infer.py (single short report) and
07_triage_full_report.py (long multi-issue reports, segmented first)."""
from datetime import datetime, timezone

from .lang_id import detect_language
from .routing import route

CONFIDENCE_REVIEW_THRESHOLD = 0.45  # below this, flag for human review instead of auto-routing


def triage_one(text, taxonomy, category_model, intent_model, mine_id, geo, worker_id=None):
    lang_info = detect_language(text)

    cat_probs = category_model.predict_proba([text])[0]
    cat_classes = category_model.classes_
    cat_idx = cat_probs.argmax()
    category_id, category_conf = cat_classes[cat_idx], float(cat_probs[cat_idx])

    intent_probs = intent_model.predict_proba([text])[0]
    intent_classes = intent_model.classes_
    intent_idx = intent_probs.argmax()
    intent, intent_conf = intent_classes[intent_idx], float(intent_probs[intent_idx])

    routing = route(category_id, text, taxonomy)
    needs_human_review = category_conf < CONFIDENCE_REVIEW_THRESHOLD

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "mine_id": mine_id,
        "worker_id": worker_id,
        "geo": geo,
        "text": text,
        "language": lang_info["language"],
        "category_id": routing["category_id"],
        "category_label": routing["category_label"],
        "category_confidence": round(category_conf, 3),
        "domain": routing["domain"],
        "department": routing["department"],
        "responsible_role": routing["responsible_role"],
        "intent": str(intent),
        "intent_confidence": round(intent_conf, 3),
        "priority": routing["priority"],
        "priority_escalated_by_keyword": routing["priority_escalated_by_keyword"],
        "sla_hours": routing["sla_hours"],
        "sla_deadline": routing["sla_deadline"],
        "escalation_chain": routing["escalation_chain"],
        "needs_human_review": needs_human_review,
        "model_version": "baseline_tfidf_v1",
    }
