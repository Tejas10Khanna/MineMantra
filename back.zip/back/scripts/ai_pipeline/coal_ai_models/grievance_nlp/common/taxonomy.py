"""Loads configs/taxonomy.yaml and exposes it as convenient lookup structures."""
from pathlib import Path

import yaml

TAXONOMY_PATH = Path(__file__).resolve().parent.parent / "configs" / "taxonomy.yaml"


class Taxonomy:
    def __init__(self, path=TAXONOMY_PATH):
        raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
        self.domains = raw["domains"]
        self.departments = raw["departments"]
        self.categories = {c["id"]: c for c in raw["categories"]}
        self.intents = raw["intents"]
        self.escalation_kw_en = [w.lower() for w in raw["priority_escalation_keywords_en"]]
        self.escalation_kw_hi = raw["priority_escalation_keywords_hi"]
        self.sla_levels = raw["sla_escalation"]["levels"]

    def category_ids(self):
        return list(self.categories.keys())

    def department_for(self, category_id):
        cat = self.categories[category_id]
        return self.departments[cat["department"]]

    def domain_for(self, category_id):
        return self.categories[category_id]["domain"]

    def default_priority(self, category_id):
        return self.categories[category_id]["default_priority"]

    def sla_hours(self, category_id):
        return self.categories[category_id]["sla_hours"]

    def keywords(self, category_id):
        cat = self.categories[category_id]
        return cat.get("keywords_en", []), cat.get("keywords_hi", [])

    def has_escalation_keyword(self, text: str) -> bool:
        low = text.lower()
        if any(kw in low for kw in self.escalation_kw_en):
            return True
        return any(kw in text for kw in self.escalation_kw_hi)  # Hindi: no case-folding needed
