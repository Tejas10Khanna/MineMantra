"""
Dependency-free language identification for Hindi / English / code-mixed grievance text.

This is a script-ratio + common-word heuristic, not a trained language-ID model — it works
today with zero downloads, which matters because this sandbox has no internet access to
pull a real language-ID model. It correctly separates Hindi (Devanagari script) from English
(Latin script) and flags code-mixing, which covers the great majority of real field reports.

Known limitation (be upfront about this in the demo): it CANNOT distinguish Hindi from other
Devanagari-script languages (Marathi, Nepali, Bhojpuri written in Devanagari), and it cannot
identify other Indian languages written in Latin script (romanized Hindi/Bhojpuri, or languages
like Bengali/Odia/Telugu in their own scripts) at all. The documented upgrade path is
`fasttext`'s `lid.176` model or the language ID signal built into IndicBERT's tokenizer —
both need a one-time model download this sandbox can't do, but either drops in behind the
same `detect_language()` function signature.
"""
import re
import unicodedata

DEVANAGARI_RANGE = (0x0900, 0x097F)

# A short list of very common Hindi function words written in Latin script, to catch
# romanized Hindi ("aaj helmet nahi mila") — a real pattern in mobile-submitted reports.
ROMANIZED_HINDI_MARKERS = {
    "nahi", "nahin", "hai", "hain", "mila", "milta", "kar", "raha", "rahi", "kyun",
    "kyunki", "aur", "lekin", "bhi", "ke", "ki", "ka", "mein", "se", "ko", "par",
}


def _script_ratios(text: str):
    dev, latin, other = 0, 0, 0
    for ch in text:
        if ch.isspace() or unicodedata.category(ch).startswith("P"):
            continue
        cp = ord(ch)
        if DEVANAGARI_RANGE[0] <= cp <= DEVANAGARI_RANGE[1]:
            dev += 1
        elif ch.isascii() and ch.isalpha():
            latin += 1
        else:
            other += 1
    total = max(dev + latin + other, 1)
    return dev / total, latin / total, other / total


def detect_language(text: str) -> dict:
    """Returns {"language": "hi"|"en"|"hi_en_mixed"|"romanized_hi"|"other",
                "devanagari_ratio": float, "latin_ratio": float}"""
    dev_ratio, latin_ratio, other_ratio = _script_ratios(text)

    if dev_ratio > 0.6:
        lang = "hi"
    elif latin_ratio > 0.6:
        words = set(re.findall(r"[a-zA-Z]+", text.lower()))
        marker_hits = len(words & ROMANIZED_HINDI_MARKERS)
        lang = "romanized_hi" if marker_hits >= 2 else "en"
    elif dev_ratio > 0.15 and latin_ratio > 0.15:
        lang = "hi_en_mixed"
    elif other_ratio > 0.5:
        lang = "other"  # some Indian script this heuristic doesn't recognize — flag for review
    else:
        lang = "hi_en_mixed"

    return {
        "language": lang,
        "devanagari_ratio": round(dev_ratio, 3),
        "latin_ratio": round(latin_ratio, 3),
    }
