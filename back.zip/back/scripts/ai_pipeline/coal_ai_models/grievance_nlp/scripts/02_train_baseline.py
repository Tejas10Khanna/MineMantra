"""
Baseline bootstrap classifier: TF-IDF (character n-grams, word-boundary aware) +
LogisticRegression, trained separately for category and intent. Character n-grams are used
instead of word tokens specifically so the same vectorizer handles Hindi (Devanagari),
English, and code-mixed text without needing a language-specific tokenizer — this is what
makes it runnable today with zero downloads, as a bootstrap ahead of the real IndicBERT/
DistilBERT fine-tune (03_train_transformer.py), which needs pretrained weights this sandbox
can't fetch.

This is a BOOTSTRAP model per the plan ("Bootstrap on public grievance-classification
datasets... active-learn on real submissions") — expect it to be noticeably weaker than the
transformer once real submissions accumulate; that's the intended trajectory, not a flaw to
hide.

Usage:
  python 02_train_baseline.py --data ../data/synthetic_grievances.csv --out ../models/baseline
"""
import argparse
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline


def build_pipeline():
    return Pipeline([
        ("tfidf", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=20000)),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
    ])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="../data/synthetic_grievances.csv")
    ap.add_argument("--out", default="../models/baseline")
    ap.add_argument("--test-size", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_csv(args.data)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    report = {}
    for target in ["category_id", "intent"]:
        X_train, X_test, y_train, y_test = train_test_split(
            df["text"], df[target], test_size=args.test_size,
            random_state=args.seed, stratify=df[target],
        )
        pipe = build_pipeline()
        pipe.fit(X_train, y_train)
        preds = pipe.predict(X_test)

        model_path = out_dir / f"{target}_classifier.joblib"
        joblib.dump(pipe, model_path)

        cls_report = classification_report(y_test, preds, output_dict=True, zero_division=0)
        report[target] = {
            "accuracy": cls_report["accuracy"],
            "macro_f1": cls_report["macro avg"]["f1-score"],
            "n_train": len(X_train),
            "n_test": len(X_test),
        }
        print(f"\n=== {target} ===")
        print(classification_report(y_test, preds, zero_division=0))
        print(f"Saved -> {model_path}")

    (out_dir / "training_report.json").write_text(json.dumps(report, indent=2))
    print(f"\nSummary written to {out_dir / 'training_report.json'}")
    print("\nRemember: these accuracy numbers are on held-out SYNTHETIC data — they show the")
    print("pipeline works, not real-world accuracy on actual worker submissions. Re-evaluate")
    print("once active learning has accumulated real labeled examples (06_active_learning.py).")
    print("\nNext: python 04_infer.py --text \"...\"")


if __name__ == "__main__":
    main()
