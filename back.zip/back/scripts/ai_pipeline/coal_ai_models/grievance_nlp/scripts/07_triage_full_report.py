"""
Triages a LONG, possibly multi-issue free-text report (a worker writing a few paragraphs
covering several problems in one submission, as commonly happens on a mobile app where
typing a fresh report per issue is friction).

04_infer.py forces the whole text through one category prediction — fine for a single short
sentence, but tested against a real multi-issue report it: (a) only surfaces whichever issue
dominates the text, silently dropping the others, and (b) its confidence craters (0.157 in
the test below) because the signal for multiple different issues is mixed together in one
TF-IDF vector.

This script fixes that by segmenting first, then triaging each segment independently, then
merging segments that land on the same category (so three sentences about the same PPE issue
don't become three separate cases).

Usage:
  python 07_triage_full_report.py --file long_report.txt --mine-id SECL-GEVRA-03
"""
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from common.segment import segment_report  # noqa: E402
from common.taxonomy import Taxonomy  # noqa: E402
from common.triage import triage_one  # noqa: E402

PRIORITY_ORDER = ["low", "medium", "high", "critical"]


def triage_full_report(text, taxonomy, category_model, intent_model, mine_id, geo, worker_id=None):
    segments = segment_report(text)
    if not segments:
        segments = [text]  # fall back to whole text if segmentation found nothing splittable

    per_segment = [
        triage_one(seg, taxonomy, category_model, intent_model, mine_id, geo, worker_id)
        for seg in segments
    ]

    # merge segments that landed on the same category, keeping the highest-confidence one
    # as the representative record but noting how many segments supported it
    by_category = {}
    for record in per_segment:
        cat = record["category_id"]
        if cat not in by_category or record["category_confidence"] > by_category[cat]["category_confidence"]:
            by_category[cat] = record
        by_category[cat].setdefault("supporting_segments", 0)
        by_category[cat]["supporting_segments"] += 1

    issues = sorted(by_category.values(), key=lambda r: -PRIORITY_ORDER.index(r["priority"]))

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "mine_id": mine_id,
        "worker_id": worker_id,
        "geo": geo,
        "full_text": text,
        "n_segments_found": len(segments),
        "n_distinct_issues": len(issues),
        "overall_priority": issues[0]["priority"] if issues else None,
        "earliest_sla_deadline": min((i["sla_deadline"] for i in issues), default=None),
        "issues": issues,
        "model_version": "baseline_tfidf_v1_segmented",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", help="a single long report as one string")
    ap.add_argument("--file", help="path to a .txt file containing ONE long report")
    ap.add_argument("--models", default="../models/baseline")
    ap.add_argument("--mine-id", default="UNKNOWN_MINE")
    ap.add_argument("--worker-id", default=None)
    ap.add_argument("--lat", type=float, default=None)
    ap.add_argument("--lon", type=float, default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    if not args.text and not args.file:
        sys.exit("Provide --text \"...\" or --file path.txt")

    text = args.text or Path(args.file).read_text(encoding="utf-8").strip()

    taxonomy = Taxonomy()
    category_model = joblib.load(Path(args.models) / "category_id_classifier.joblib")
    intent_model = joblib.load(Path(args.models) / "intent_classifier.joblib")
    geo = [args.lat, args.lon] if args.lat is not None else None

    result = triage_full_report(text, taxonomy, category_model, intent_model,
                                 args.mine_id, geo, args.worker_id)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"\n{result['n_segments_found']} segments found -> "
          f"{result['n_distinct_issues']} distinct issue(s) routed.")

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"Wrote -> {out_path}")


if __name__ == "__main__":
    main()
