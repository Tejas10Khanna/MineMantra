"""
Fine-tunes a small multilingual transformer (IndicBERT or DistilBERT multilingual) for
joint category + intent classification, replacing the TF-IDF+LogisticRegression baseline
once real submissions justify it — this is the "Fine-tuned small transformer (IndicBERT/
DistilBERT) -> category/priority/intent" step in the model plan.

Requires internet (to pull pretrained weights from Hugging Face) and a GPU for a full
run — neither is available in this sandbox (confirmed: huggingface.co returns 403 here),
so this is written to run on your machine or a Colab/Kaggle GPU notebook.

Model choice:
  - ai4bharat/indic-bert         : purpose-built for Indian languages incl. Hindi, smaller,
                                    best accuracy/size tradeoff for code-mixed Hindi-English
  - distilbert-base-multilingual-cased : broader language coverage (100+ languages),
                                    slightly larger, good fallback if IndicBERT underperforms
                                    on a particular regional language once collected

Usage (once you have internet + GPU):
  pip install transformers torch datasets accelerate
  python 03_train_transformer.py --data ../data/synthetic_grievances.csv \
      --model ai4bharat/indic-bert --epochs 5 --out ../models/transformer
"""
import argparse
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="../data/synthetic_grievances.csv")
    ap.add_argument("--model", default="ai4bharat/indic-bert",
                     help="or 'distilbert-base-multilingual-cased'")
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--out", default="../models/transformer")
    args = ap.parse_args()

    try:
        import pandas as pd
        import torch
        from datasets import Dataset
        from sklearn.preprocessing import LabelEncoder
        from transformers import (AutoModelForSequenceClassification, AutoTokenizer,
                                   Trainer, TrainingArguments)
    except ImportError as e:
        sys.exit(
            f"Missing dependency: {e}\n\n"
            "This script needs `transformers`, `torch`, and `datasets` (see requirements.txt's "
            "commented-out transformer section) plus internet access to download pretrained "
            f"weights for '{args.model}'. Neither is available in this sandbox. Run this on "
            "your machine or a Colab/Kaggle GPU notebook instead — the rest of this script is "
            "ready to go once those are available."
        )

    df = pd.read_csv(args.data)
    label_encoder = LabelEncoder()
    df["label"] = label_encoder.fit_transform(df["category_id"])

    dataset = Dataset.from_pandas(df[["text", "label"]])
    dataset = dataset.train_test_split(test_size=0.2, seed=42)

    tokenizer = AutoTokenizer.from_pretrained(args.model)

    def tokenize(batch):
        return tokenizer(batch["text"], truncation=True, padding="max_length", max_length=128)

    dataset = dataset.map(tokenize, batched=True)

    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, num_labels=len(label_encoder.classes_)
    )

    training_args = TrainingArguments(
        output_dir=args.out,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        logging_steps=20,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset["train"],
        eval_dataset=dataset["test"],
    )

    trainer.train()
    trainer.save_model(args.out)
    tokenizer.save_pretrained(args.out)
    print(f"Saved fine-tuned {args.model} -> {args.out}")
    print("Repeat with --model distilbert-base-multilingual-cased for the fallback comparison.")
    print("\nNote: this trains a category classifier only, as a template — duplicate this "
          "script (or add a second classification head) for the intent classifier, the same "
          "way 02_train_baseline.py trains two separate sklearn pipelines.")


if __name__ == "__main__":
    main()
