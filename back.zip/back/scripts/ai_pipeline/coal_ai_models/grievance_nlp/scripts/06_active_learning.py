"""
Continuous active learning, matching the plan's "Continuous active learning" cadence
(as opposed to the PPE model's quarterly batch retrain — grievance volume and the cost of a
wrong department routing justify tighter loops here).

Two jobs:
  1. review queue: every low-confidence prediction from 04_infer.py (flagged
     needs_human_review=true) gets queued for a human (e.g. the Mine Safety Officer or a
     central triage team) to confirm/correct the category+intent.
  2. retrain trigger: once enough human-confirmed real labels accumulate, merge them into
     the training set (weighted to matter more than synthetic examples) and retrain.

Usage:
  # after 04_infer.py has been run on a batch and produced --out records:
  python 06_active_learning.py enqueue --records ../runs/batch_test.jsonl
  python 06_active_learning.py resolve --id 3 --category_id ppe_safety_equipment --intent complaint
  python 06_active_learning.py status
  python 06_active_learning.py retrain --min-confirmed 200
"""
import argparse
import json
from pathlib import Path

QUEUE_PATH = Path("../data/review_queue.jsonl")
CONFIRMED_PATH = Path("../data/confirmed_real_labels.csv")
RETRAIN_THRESHOLD_DEFAULT = 200  # real confirmed labels since last retrain


def load_jsonl(path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def enqueue(args):
    records = load_jsonl(Path(args.records))
    queue = load_jsonl(QUEUE_PATH)
    next_id = len(queue)
    added = 0
    for r in records:
        if r.get("needs_human_review"):
            queue.append({"id": next_id, "status": "pending", **r})
            next_id += 1
            added += 1
    QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(QUEUE_PATH, "w", encoding="utf-8") as f:
        for item in queue:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    print(f"Queued {added} low-confidence records for human review "
          f"({len(queue)} total pending+resolved in queue).")


def resolve(args):
    queue = load_jsonl(QUEUE_PATH)
    found = False
    for item in queue:
        if item["id"] == args.id:
            item["status"] = "resolved"
            item["confirmed_category_id"] = args.category_id
            item["confirmed_intent"] = args.intent
            found = True
            break
    if not found:
        raise SystemExit(f"No queue item with id={args.id}")

    with open(QUEUE_PATH, "w", encoding="utf-8") as f:
        for item in queue:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    # append to the confirmed real-label training set
    import csv
    write_header = not CONFIRMED_PATH.exists()
    with open(CONFIRMED_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow(["text", "category_id", "intent", "language", "synthetic"])
        item = next(i for i in queue if i["id"] == args.id)
        writer.writerow([item["text"], args.category_id, args.intent, item["language"], False])

    print(f"Resolved id={args.id}: category={args.category_id}, intent={args.intent}. "
          f"Appended to {CONFIRMED_PATH} for the next retrain.")


def status(args):
    queue = load_jsonl(QUEUE_PATH)
    pending = [i for i in queue if i["status"] == "pending"]
    confirmed_count = 0
    if CONFIRMED_PATH.exists():
        confirmed_count = sum(1 for _ in open(CONFIRMED_PATH, encoding="utf-8")) - 1  # minus header

    print(f"Review queue: {len(pending)} pending, {len(queue) - len(pending)} resolved.")
    print(f"Confirmed real labels accumulated: {max(confirmed_count, 0)} "
          f"(retrain threshold: {args.min_confirmed})")
    if confirmed_count >= args.min_confirmed:
        print(">>> THRESHOLD CROSSED — run `python 06_active_learning.py retrain` to fold "
              "these real labels into the baseline (or transformer) training set.")


def retrain(args):
    import pandas as pd

    confirmed_count = 0
    if CONFIRMED_PATH.exists():
        confirmed_count = len(pd.read_csv(CONFIRMED_PATH))
    if confirmed_count < args.min_confirmed:
        print(f"Only {confirmed_count} confirmed real labels so far "
              f"(need {args.min_confirmed}) — not retraining yet.")
        return

    synthetic_path = Path("../data/synthetic_grievances.csv")
    if not synthetic_path.exists():
        raise SystemExit("Run 01_generate_synthetic_dataset.py first to establish the base set.")

    synth_df = pd.read_csv(synthetic_path)
    real_df = pd.read_csv(CONFIRMED_PATH)
    # oversample real (human-confirmed) examples relative to synthetic ones, since they're
    # higher-value signal about actual field language even in small numbers
    combined = pd.concat([synth_df, real_df, real_df, real_df], ignore_index=True)
    merged_path = Path("../data/merged_for_retrain.csv")
    combined.to_csv(merged_path, index=False)

    print(f"Merged {len(synth_df)} synthetic + {len(real_df)} real (3x oversampled) "
          f"-> {len(combined)} rows at {merged_path}")
    print(f"Next: python 02_train_baseline.py --data {merged_path} --out ../models/baseline_v2")
    print("(or, once available: python 03_train_transformer.py --data", merged_path, ")")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_enq = sub.add_parser("enqueue")
    p_enq.add_argument("--records", required=True)
    p_enq.set_defaults(func=enqueue)

    p_res = sub.add_parser("resolve")
    p_res.add_argument("--id", type=int, required=True)
    p_res.add_argument("--category_id", required=True)
    p_res.add_argument("--intent", required=True)
    p_res.set_defaults(func=resolve)

    p_stat = sub.add_parser("status")
    p_stat.add_argument("--min-confirmed", type=int, default=RETRAIN_THRESHOLD_DEFAULT)
    p_stat.set_defaults(func=status)

    p_retrain = sub.add_parser("retrain")
    p_retrain.add_argument("--min-confirmed", type=int, default=RETRAIN_THRESHOLD_DEFAULT)
    p_retrain.set_defaults(func=retrain)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
