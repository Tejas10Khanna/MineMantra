"""
End-to-end triage for one free-text submission from the mobile app: language ID, category
(-> department) classification, intent classification, priority (with safety-keyword
escalation), SLA deadline, and responsible-officer routing — emitted as one JSON record
ready for alert_engine.py and the compliance-case/SLA-tracking system.

Usage:
  python 04_infer.py --text "आज हेलमेट नहीं मिला, बिना हेलमेट काम करना पड़ रहा है।" \
      --mine-id SECL-GEVRA-03 --lat 22.4109 --lon 82.6839

  python 04_infer.py --file ../data/incoming_reports.txt --models ../models/baseline
"""
import argparse
import json
import sys
from pathlib import Path

import joblib

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from common.taxonomy import Taxonomy  # noqa: E402
from common.triage import triage_one  # noqa: E402

# NOTE: this script is for SHORT, single-issue reports (one sentence to a short paragraph).
# For long, multi-paragraph, possibly multi-issue reports, use 07_triage_full_report.py
# instead — it segments the text first so each distinct issue gets its own routing decision.
# See docs/full_reports.md for what happens if you run a long report through this script.


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", help="single free-text report")
    ap.add_argument("--file", help="path to a text file, one report per line")
    ap.add_argument("--models", default="../models/baseline")
    ap.add_argument("--mine-id", default="UNKNOWN_MINE")
    ap.add_argument("--worker-id", default=None)
    ap.add_argument("--lat", type=float, default=None)
    ap.add_argument("--lon", type=float, default=None)
    ap.add_argument("--out", default=None, help="optional path to write JSONL output")
    args = ap.parse_args()

    if not args.text and not args.file:
        sys.exit("Provide --text \"...\" or --file path.txt")

    taxonomy = Taxonomy()
    category_model = joblib.load(Path(args.models) / "category_id_classifier.joblib")
    intent_model = joblib.load(Path(args.models) / "intent_classifier.joblib")
    geo = [args.lat, args.lon] if args.lat is not None else None

    texts = [args.text] if args.text else Path(args.file).read_text(encoding="utf-8").splitlines()
    texts = [t.strip() for t in texts if t.strip()]

    results = [
        triage_one(t, taxonomy, category_model, intent_model, args.mine_id, geo, args.worker_id)
        for t in texts
    ]

    for r in results:
        print(json.dumps(r, ensure_ascii=False, indent=2))

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            for r in results:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"\nWrote {len(results)} records -> {out_path}")


if __name__ == "__main__":
    main()
