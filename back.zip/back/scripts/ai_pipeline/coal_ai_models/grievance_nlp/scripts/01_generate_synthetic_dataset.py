"""
Generates a bootstrap training set of (text, category, intent, language) examples.

Honesty note: no public row-level dataset of real Indian coal-mine grievances exists (same
finding as the rest of this project). CPGRAMS publishes its CATEGORY TAXONOMY publicly (the
department/category structure), which `configs/taxonomy.yaml` is modeled on — but not a
downloadable corpus of real grievance text with labels. So this generates synthetic
Hindi/English/code-mixed sentences from templates + keyword slots per category, calibrated
to sound like real field reports, to bootstrap the baseline classifier until real submissions
accumulate. Every record is tagged `"synthetic": true`. Swap in real labeled submissions via
`06_active_learning.py` as they come in from the mobile app.

Usage:
  python 01_generate_synthetic_dataset.py --n-per-category 60 --out ../data/synthetic_grievances.csv
"""
import argparse
import csv
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from common.taxonomy import Taxonomy  # noqa: E402

LOCATIONS_EN = ["Gevra OCP", "Dipka mine", "Magadh colliery", "Jayant mine", "Kusmunda OCP", "Amlohri mine"]
LOCATIONS_HI = ["गेवरा खदान", "दीपका खदान", "मगध कोलियरी", "जयंत खदान", "कुसमुंडा खदान"]

# Templates per intent, with {issue} / {loc} slots filled from category keywords/locations.
TEMPLATES = {
    "en": {
        "complaint": [
            "Today {issue} at {loc}, workers are facing serious problems.",
            "There is {issue} in the {loc} area since morning, no action taken yet.",
            "We are forced to work despite {issue} at {loc}.",
            "{issue} has been reported multiple times at {loc} but nothing is done.",
        ],
        "request": [
            "Please arrange for resolution of {issue} at {loc} as soon as possible.",
            "Requesting immediate attention to {issue} near {loc}.",
            "Kindly send someone to check {issue} at {loc}.",
        ],
        "information": [
            "For your information, {issue} was observed at {loc} during the shift.",
            "Reporting {issue} at {loc} for record purposes.",
        ],
        "suggestion": [
            "Suggest installing better arrangement to avoid {issue} at {loc} in future.",
            "It would help to review the process around {issue} at {loc}.",
        ],
    },
    "hi": {
        "complaint": [
            "आज {loc} पर {issue}, मजदूरों को काफी दिक्कत हो रही है।",
            "{loc} में {issue} की समस्या सुबह से है, अभी तक कोई कार्रवाई नहीं हुई।",
            "{issue} के बावजूद हमें काम करना पड़ रहा है।",
        ],
        "request": [
            "कृपया {loc} पर {issue} की समस्या जल्द ठीक करें।",
            "{issue} के लिए तुरंत ध्यान देने का अनुरोध है।",
        ],
        "information": [
            "सूचनार्थ, {loc} पर {issue} देखा गया।",
        ],
        "suggestion": [
            "भविष्य में {issue} से बचने के लिए बेहतर व्यवस्था का सुझाव है।",
        ],
    },
}

# category_id -> a couple of representative "issue" phrases per language, drawn loosely
# from the taxonomy's keyword lists (kept separate here so phrasing reads naturally).
ISSUE_PHRASES = {
    "ppe_safety_equipment": {
        "en": ["helmet not available", "no safety vest issued", "PPE shortage at distribution point"],
        "hi": ["हेलमेट नहीं मिला", "सुरक्षा जूते उपलब्ध नहीं", "पीपीई की कमी"],
    },
    "unsafe_condition": {
        "en": ["a gas leak", "risk of roof fall", "an unsafe working area"],
        "hi": ["गैस रिसाव", "छत गिरने का खतरा", "असुरक्षित कार्यस्थल"],
    },
    "equipment_breakdown": {
        "en": ["the excavator breakdown", "conveyor belt malfunction", "dumper not working"],
        "hi": ["उत्खनन यंत्र खराब होना", "कन्वेयर बेल्ट में खराबी"],
    },
    "electrical_fault": {
        "en": ["an electrical short circuit", "power failure in the shaft", "transformer fault"],
        "hi": ["बिजली में शॉर्ट सर्किट", "ट्रांसफार्मर में खराबी"],
    },
    "production_delay": {
        "en": ["a delay in blasting schedule", "shift target not met due to machine issue"],
        "hi": ["विस्फोट कार्यक्रम में देरी", "उत्पादन लक्ष्य पूरा नहीं होना"],
    },
    "dust_air_pollution": {
        "en": ["excessive dust in the air", "poor air quality near the crusher"],
        "hi": ["हवा में अत्यधिक धूल", "क्रशर के पास खराब हवा गुणवत्ता"],
    },
    "water_effluent": {
        "en": ["contaminated water discharge", "blocked drainage near the pit"],
        "hi": ["दूषित पानी का बहाव", "गड्ढे के पास जल निकासी अवरुद्ध"],
    },
    "infrastructure_civil": {
        "en": ["a damaged haul road", "cracks in the colony building"],
        "hi": ["सड़क में गड्ढे", "कॉलोनी के मकान में दरारें"],
    },
    "explosives_chemical_handling": {
        "en": ["improper explosive storage", "unsafe handling of blasting material"],
        "hi": ["विस्फोटक का असुरक्षित भंडारण"],
    },
    "wage_payment_delay": {
        "en": ["salary not paid for two months", "overtime payment pending"],
        "hi": ["दो महीने से वेतन नहीं मिला", "ओवरटाइम भुगतान लंबित"],
    },
    "contractor_payment_dispute": {
        "en": ["contractor bill payment pending", "dispute over contract payment"],
        "hi": ["ठेकेदार का भुगतान लंबित"],
    },
    "attendance_dispute": {
        "en": ["attendance marked incorrectly", "leave request not approved"],
        "hi": ["उपस्थिति गलत दर्ज होना", "छुट्टी स्वीकृत नहीं होना"],
    },
    "worker_welfare_harassment": {
        "en": ["harassment by the supervisor", "discriminatory behavior at the site"],
        "hi": ["सुपरवाइजर द्वारा उत्पीड़न"],
    },
    "health_sanitation": {
        "en": ["poor drinking water quality", "unhygienic toilet facilities"],
        "hi": ["पीने के पानी की खराब गुणवत्ता", "अस्वच्छ शौचालय"],
    },
    "corruption_misconduct": {
        "en": ["a bribe demanded for approval", "favoritism in task allocation"],
        "hi": ["मंजूरी के लिए रिश्वत मांगी गई"],
    },
    "general_other": {
        "en": ["a general query about mine timings", "a request for information"],
        "hi": ["खदान समय के बारे में सामान्य प्रश्न"],
    },
}


def make_mixed(en_sentence, hi_sentence):
    """Crude code-mixing: splice a Hindi clause into the English sentence, or vice versa —
    approximates how real bilingual workers actually write (e.g. mixing English nouns like
    'helmet', 'PPE' into Hindi sentences), which is common in real mobile-submitted reports."""
    en_words = en_sentence.split()
    if len(en_words) > 4:
        cut = len(en_words) // 2
        return " ".join(en_words[:cut]) + " " + hi_sentence
    return hi_sentence + " " + en_sentence


def generate_for_category(cat_id, n, rng):
    rows = []
    intents = ["complaint", "request", "information", "suggestion"]
    weights = [0.55, 0.25, 0.12, 0.08]  # complaints dominate real grievance traffic
    for _ in range(n):
        intent = rng.choices(intents, weights=weights)[0]
        lang_choice = rng.choices(["en", "hi", "mixed"], weights=[0.35, 0.45, 0.20])[0]

        issue_en = rng.choice(ISSUE_PHRASES[cat_id]["en"])
        issue_hi = rng.choice(ISSUE_PHRASES[cat_id].get("hi", ISSUE_PHRASES[cat_id]["en"]))
        loc_en, loc_hi = rng.choice(LOCATIONS_EN), rng.choice(LOCATIONS_HI)

        tmpl_en = rng.choice(TEMPLATES["en"][intent])
        tmpl_hi = rng.choice(TEMPLATES["hi"].get(intent, TEMPLATES["hi"]["complaint"]))

        sent_en = tmpl_en.format(issue=issue_en, loc=loc_en)
        sent_hi = tmpl_hi.format(issue=issue_hi, loc=loc_hi)

        if lang_choice == "en":
            text, lang = sent_en, "en"
        elif lang_choice == "hi":
            text, lang = sent_hi, "hi"
        else:
            text, lang = make_mixed(sent_en, sent_hi), "hi_en_mixed"

        rows.append({
            "text": text,
            "category_id": cat_id,
            "intent": intent,
            "language": lang,
            "synthetic": True,
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-per-category", type=int, default=60)
    ap.add_argument("--out", default="../data/synthetic_grievances.csv")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rng = random.Random(args.seed)
    taxonomy = Taxonomy()

    all_rows = []
    for cat_id in taxonomy.category_ids():
        if cat_id not in ISSUE_PHRASES:
            continue
        all_rows.extend(generate_for_category(cat_id, args.n_per_category, rng))

    rng.shuffle(all_rows)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["text", "category_id", "intent", "language", "synthetic"])
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"Generated {len(all_rows)} SYNTHETIC grievance examples across "
          f"{len(set(r['category_id'] for r in all_rows))} categories -> {out_path}")
    print("Next: python 02_train_baseline.py")


if __name__ == "__main__":
    main()
