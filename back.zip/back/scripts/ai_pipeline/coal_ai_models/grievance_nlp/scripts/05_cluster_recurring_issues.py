"""
Detects recurring compliance failures from a stream of already-triaged grievance records
(the JSONL output of 04_infer.py, accumulated across many submissions/mines/time).

Two layers, matching the plan's "groups semantically related complaints... even in multiple
Indian languages... to identify recurring compliance failures such as repeated PPE
shortages, delayed contractor payments, or environmental violations":

  1. REPEAT-PATTERN COUNTING (language-agnostic, works today): since 04_infer.py already
     resolves each report to a category_id regardless of source language (Hindi/English/
     mixed all map to the same category_id via the shared TF-IDF+LogReg classifier), simply
     counting (mine_id, category_id) occurrences in a rolling window already detects
     cross-language recurrence — a Hindi PPE complaint and an English PPE complaint at the
     same mine both increment the same counter. This is the primary signal and needs no
     extra model.

  2. SUB-PATTERN CLUSTERING (within a category, text-level): KMeans over the same char
     n-gram TF-IDF features used for training, run within each category, to separate
     distinct sub-issues that share a category label (e.g. "helmet shortage" vs "boot
     shortage" both under ppe_safety_equipment). This works across languages only to the
     extent shared character n-grams overlap (limited for Hindi vs English text describing
     the same thing) — true cross-lingual sub-pattern clustering needs multilingual sentence
     embeddings (e.g. LaBSE / paraphrase-multilingual-mpnet via sentence-transformers), which
     needs a model download this sandbox can't do. Layer 1 above doesn't have this
     limitation since it clusters on the already-language-agnostic category_id.

Usage:
  python 05_cluster_recurring_issues.py --records ../runs/demo_output.jsonl \
      --window-days 30 --repeat-threshold 3
"""
import argparse
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer


def load_records(path):
    records = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            records.append(json.loads(line))
    return records


def find_repeat_patterns(records, window_days, threshold):
    """Layer 1: count (mine_id, category_id) occurrences within a rolling window."""
    now = max(datetime.fromisoformat(r["timestamp"]) for r in records)
    window_start = now - timedelta(days=window_days)

    buckets = defaultdict(list)
    for r in records:
        ts = datetime.fromisoformat(r["timestamp"])
        if ts >= window_start:
            buckets[(r["mine_id"], r["category_id"])].append(r)

    alerts = []
    for (mine_id, category_id), items in buckets.items():
        if len(items) >= threshold:
            langs = sorted(set(i["language"] for i in items))
            alerts.append({
                "type": "recurring_compliance_failure",
                "mine_id": mine_id,
                "category_id": category_id,
                "category_label": items[0]["category_label"],
                "department": items[0]["department"],
                "domain": items[0]["domain"],
                "occurrences_in_window": len(items),
                "window_days": window_days,
                "languages_involved": langs,
                "sample_texts": [i["text"] for i in items[:3]],
                "severity": "critical" if len(items) >= threshold * 2 else "high",
            })
    return sorted(alerts, key=lambda a: -a["occurrences_in_window"])


def find_sub_clusters(records, category_id, k=3):
    """Layer 2: within one category, cluster the raw text to surface sub-patterns."""
    texts = [r["text"] for r in records if r["category_id"] == category_id]
    if len(texts) < k:
        return None

    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=1)
    X = vectorizer.fit_transform(texts)
    kmeans = KMeans(n_clusters=min(k, len(texts)), random_state=42, n_init=10)
    labels = kmeans.fit_predict(X)

    clusters = defaultdict(list)
    for text, label in zip(texts, labels):
        clusters[int(label)].append(text)
    return {
        "category_id": category_id,
        "n_clusters": len(clusters),
        "clusters": {str(k): v[:3] for k, v in clusters.items()},  # sample texts per cluster
        "note": "Sub-clusters may split more by LANGUAGE than by sub-issue with char n-gram "
                "features — treat as a rough drill-down aid, not authoritative grouping, "
                "until upgraded to multilingual sentence embeddings.",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", required=True, help="JSONL output from 04_infer.py")
    ap.add_argument("--window-days", type=int, default=30)
    ap.add_argument("--repeat-threshold", type=int, default=3)
    ap.add_argument("--out", default="../runs/recurring_alerts.jsonl")
    args = ap.parse_args()

    records = load_records(args.records)
    if not records:
        raise SystemExit(f"No records found in {args.records}")

    repeat_alerts = find_repeat_patterns(records, args.window_days, args.repeat_threshold)

    print(f"Loaded {len(records)} triaged records.")
    print(f"\n=== Recurring compliance failures (>= {args.repeat_threshold} in "
          f"{args.window_days} days) ===")
    if not repeat_alerts:
        print("None crossed the threshold yet.")
    for a in repeat_alerts:
        print(f"  [{a['severity'].upper()}] {a['mine_id']} / {a['category_label']}: "
              f"{a['occurrences_in_window']} reports, languages={a['languages_involved']}")

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        for a in repeat_alerts:
            f.write(json.dumps(a, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(repeat_alerts)} recurring-pattern alerts -> {out_path}")
    print("Feed this into alert_engine.py alongside the KMeans violation-clustering model's output.")


if __name__ == "__main__":
    main()
