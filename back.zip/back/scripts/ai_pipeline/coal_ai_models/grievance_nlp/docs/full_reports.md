# Does this work on full (long, multi-issue) reports?

Short answer: **04_infer.py doesn't handle them well; 07_triage_full_report.py does much
better, but isn't perfect yet.** Both claims are backed by an actual test run below, not
just reasoning about the code.

## The problem, demonstrated

Fed a realistic ~6-sentence romanized-Hindi report covering three real issues (PPE shortage,
dust/no water-sprinkling, unpaid overtime) into **04_infer.py** (the single-shot script):

```
category: ppe_safety_equipment | confidence: 0.157 | needs_human_review: true
```

It picked one category (correctly the first-mentioned issue) and completely dropped the other
two — not flagged, not logged, just absent from the output. Confidence collapsed to 0.157
because the TF-IDF vector for the whole report mixes signal from three unrelated issues.
This is a real limitation, not a hypothetical one.

## The fix: segment first, then triage each piece

**07_triage_full_report.py** splits the report into sentence/clause-level segments
(`common/segment.py`), triages each one independently, then merges segments that land on the
same category. Run against the same report:

```
6 segments found -> 4 "issues" routed:
  1. PPE Safety Equipment      confidence 0.493   needs_human_review: false   (2 segments)
  2. Contractor Payment Dispute confidence 0.102   needs_human_review: true   (1 segment)
  3. Unsafe Working Condition   confidence 0.086   needs_human_review: true   (1 segment)
  4. Production Delay           confidence 0.119   needs_human_review: true   (1 segment)
```

What this got right:
- The PPE issue is now correctly identified with usable confidence (0.493, above the
  review threshold) instead of being diluted to 0.157.
- The overtime-payment issue was correctly split out and routed to the Contracts & Finance
  Department as its own case, with its own SLA.

What this got wrong (be upfront about both):
- **The dust/water-sprinkling segment didn't become its own issue** — it got merged into the
  PPE category instead of a separate Environment-domain category (`dust_air_pollution` or
  `water_effluent`). The baseline classifier, trained on templated synthetic sentences,
  doesn't yet generalize well to naturalistic run-on romanized-Hindi phrasing. This is
  exactly the accuracy gap active learning and the transformer upgrade exist to close.
- **Two filler sentences** (an opening "Sir, I'm writing this report..." and a closing
  "please look into all this...") passed the length filter and got assigned spurious
  low-confidence categories instead of being discarded outright. The safety net worked —
  both were correctly flagged `needs_human_review: true`, so neither would auto-route or
  start an SLA clock — but a human still has to see and dismiss two non-issues per report.

## Bottom line for the demo

Say exactly this if asked: *"the pipeline segments long reports and routes each real issue
separately with its own department and SLA — verified on a live multi-issue example — but the
baseline classifier still needs more real (or better-templated) training data before every
segment gets classified correctly, which is why the confidence-based human-review gate exists
and stays on by default."* Don't claim it perfectly extracts every issue from a paragraph
today — it doesn't yet, and the honest framing is a strength of this project, not a weakness
to paper over.

## Easy next improvements (not yet done)

- Filter out greeting/closing boilerplate segments before classification (a short stoplist
  of opening/closing phrases) instead of relying on the confidence gate to catch them.
- Add more synthetic training examples in the run-on, romanized-Hindi, multi-clause style
  actually seen in this test — the current templates are cleaner/shorter than real field
  writing tends to be.
- Once `03_train_transformer.py` runs on a GPU, IndicBERT's contextual embeddings should
  handle this kind of mixed-issue, code-switched text meaningfully better than char n-grams.
