# Wiring grievance/compliance triage into `alert_engine.py`

Each resolved report from `04_infer.py` is already a routed, prioritized, SLA-bound record —
this is a richer input than the other four models produce, since it decides an action
(who gets notified, by when) rather than just a risk score. Two feeds go into
`alert_engine.py`:

## 1. Per-report routing (immediate)

Straight from `04_infer.py`'s JSON output — one alert per report crossing a priority
threshold:

```python
def grievance_routing_alerts(records, min_priority="medium"):
    order = ["low", "medium", "high", "critical"]
    alerts = []
    for r in records:
        if order.index(r["priority"]) < order.index(min_priority):
            continue
        alerts.append({
            "type": "grievance_routed",
            "severity": r["priority"],
            "mine_id": r["mine_id"],
            "department": r["department"],
            "responsible_role": r["responsible_role"],
            "sla_deadline": r["sla_deadline"],
            "category_label": r["category_label"],
            "domain": r["domain"],
            "detail": r["text"][:200],
            "source_model": "grievance_nlp_baseline_v1",
        })
    return alerts
```

SLA breach escalation (unresolved past `sla_deadline`) should walk `escalation_chain` in
order — same escalation shape as the PPE model's repeated-violation logic, just triggered by
a missed deadline instead of a repeat count.

## 2. Recurring compliance failures (batched)

From `05_cluster_recurring_issues.py`'s output — already alert-shaped
(`type: "recurring_compliance_failure"`), just pass through.

## Human-review flag

Any record with `needs_human_review: true` should NOT auto-route to a department yet — surface
it in a triage queue instead (see `06_active_learning.py enqueue`) so a human confirms the
category before it becomes an official compliance case with an SLA clock running. Low-
confidence auto-routing is worse than a short human-review delay, especially for a system
whose whole value proposition is trustworthy triage.

## Honesty note for the demo

`model_version: "baseline_tfidf_v1"` is stamped on every record specifically so the
dashboard/demo can show which model produced a given routing decision — don't let a demo
imply the IndicBERT fine-tune is live until `03_train_transformer.py` has actually been run
and its output wired in as `model_version: "indicbert_v1"`.
