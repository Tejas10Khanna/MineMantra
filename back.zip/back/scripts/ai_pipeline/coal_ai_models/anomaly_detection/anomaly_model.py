"""
anomaly_model.py
-----------------
AI Component #2 of the Smart Coal Mining Governance Platform:
PRODUCTION ANOMALY MODEL

    Data it works on : Daily production, dispatch, equipment downtime
                        (time-series), per mine
    Source           : Internal ERP/SCADA + IoT feeds; CIL public
                        production bulletins for macro validation
    Method           : Isolation Forest (multivariate, cross-signal
                        anomalies) + Prophet residuals (per-mine
                        seasonal/trend-aware anomalies)
    What it does     : Detects unusual production patterns/anomalies
    Refresh cadence  : Weekly retrain / daily scoring

Design rationale (why two models, not one)
-------------------------------------------
- Prophet models each mine's OWN seasonality (weekly dip on Sundays,
  monsoon dip for opencast mines, long-term trend) and flags days where
  actual production falls far outside the forecast band. This catches
  "this mine is behaving oddly relative to its own history" anomalies
  and is robust to different baselines per mine.

- Isolation Forest looks across production, dispatch, downtime hours and
  equipment counts TOGETHER and flags multivariate outliers even when no
  single metric looks extreme in isolation. This catches things like
  "dispatch collapsed relative to production" (possible pilferage/logging
  gap) or "downtime is creeping up" that a single-metric time-series model
  would miss.

Combining both into an ensemble severity score gives fewer false
positives than either model alone and gives inspectors a reason code.

Usage
-----
    python3 anomaly_model.py --data data/production_data.csv --as-of 2025-12-31

Outputs (outputs/):
    anomalies_report.csv     -> full flagged anomaly list with severity & reason
    anomaly_summary.png      -> anomaly counts by mine / method
    <mine_id>_timeline.png   -> production timeline with anomalies highlighted
"""

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

DATA_COLS = [
    "production_tonnes",
    "dispatch_tonnes",
    "equipment_downtime_hours",
    "active_equipment_count",
]


# --------------------------------------------------------------------------- #
# 1. DATA LOADING
# --------------------------------------------------------------------------- #
def load_real_data(path: str) -> pd.DataFrame:
    """
    Loads the daily production feed. Expects columns:
        date, mine_id, mine_name, mine_type,
        production_tonnes, dispatch_tonnes,
        equipment_downtime_hours, active_equipment_count

    Swap this function to point at the live ERP/SCADA export or API
    when moving from the synthetic demo to production. Everything
    downstream only depends on this schema.
    """
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.sort_values(["mine_id", "date"]).reset_index(drop=True)
    return df


# --------------------------------------------------------------------------- #
# 2. FEATURE ENGINEERING (for Isolation Forest)
# --------------------------------------------------------------------------- #
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = df.sort_values(["mine_id", "date"])

    g = df.groupby("mine_id")

    # Rolling baselines (7/14-day) to express "today vs recent normal"
    for col in ["production_tonnes", "dispatch_tonnes", "equipment_downtime_hours"]:
        df[f"{col}_roll7_mean"] = g[col].transform(lambda s: s.rolling(7, min_periods=3).mean())
        df[f"{col}_roll7_std"] = g[col].transform(lambda s: s.rolling(7, min_periods=3).std()).fillna(0)
        df[f"{col}_dev_from_roll7"] = (df[col] - df[f"{col}_roll7_mean"]) / df[f"{col}_roll7_mean"].replace(0, np.nan)

    # Cross-signal ratios that a single-metric model can't see
    df["dispatch_to_production_ratio"] = df["dispatch_tonnes"] / df["production_tonnes"].replace(0, np.nan)
    df["downtime_per_active_equip"] = df["equipment_downtime_hours"] / df["active_equipment_count"].replace(0, np.nan)

    df["day_of_week"] = df["date"].dt.dayofweek
    df["month"] = df["date"].dt.month

    df = df.fillna(0)
    return df


ISO_FEATURES = [
    "production_tonnes_dev_from_roll7",
    "dispatch_tonnes_dev_from_roll7",
    "equipment_downtime_hours_dev_from_roll7",
    "dispatch_to_production_ratio",
    "downtime_per_active_equip",
]


# --------------------------------------------------------------------------- #
# 3. ISOLATION FOREST (multivariate, cross-signal anomalies)
# --------------------------------------------------------------------------- #
def run_isolation_forest(df: pd.DataFrame, contamination: float = 0.025) -> pd.DataFrame:
    """Fits one Isolation Forest per mine (mines have very different scales/behaviour)."""
    df = df.copy()
    df["if_anomaly"] = False
    df["if_score"] = 0.0

    for mine_id, sub in df.groupby("mine_id"):
        X = sub[ISO_FEATURES].values
        X = StandardScaler().fit_transform(X)

        model = IsolationForest(
            n_estimators=300,
            contamination=contamination,
            random_state=42,
        )
        preds = model.fit_predict(X)          # -1 = anomaly, 1 = normal
        scores = -model.score_samples(X)      # higher = more anomalous

        df.loc[sub.index, "if_anomaly"] = preds == -1
        df.loc[sub.index, "if_score"] = scores

    return df


# --------------------------------------------------------------------------- #
# 4. PROPHET (per-mine seasonal/trend-aware residual anomalies)
# --------------------------------------------------------------------------- #
def run_prophet_residuals(df: pd.DataFrame, interval_width: float = 0.90) -> pd.DataFrame:
    """
    For each mine, fits Prophet on production_tonnes (weekly + yearly
    seasonality), then flags days where the actual value falls outside
    the forecast's uncertainty interval -> "unusual vs this mine's own
    seasonal pattern".
    """
    df = df.copy()
    df["prophet_anomaly"] = False
    df["prophet_yhat"] = np.nan
    df["prophet_residual_pct"] = np.nan

    try:
        from prophet import Prophet  # local import: keeps module import fast when unused
    except ImportError:
        print("WARNING: `prophet` not installed (`pip install prophet`) -- skipping seasonal "
              "residual detection, Isolation Forest results only. Install prophet for the "
              "full ensemble (catches different anomaly types, see module docstring).")
        return df

    for mine_id, sub in df.groupby("mine_id"):
        sub = sub.sort_values("date")
        pdf = sub[["date", "production_tonnes"]].rename(columns={"date": "ds", "production_tonnes": "y"})

        model = Prophet(
            weekly_seasonality=True,
            yearly_seasonality=True,
            daily_seasonality=False,
            interval_width=interval_width,
            changepoint_prior_scale=0.1,
        )
        model.fit(pdf)

        forecast = model.predict(pdf[["ds"]])
        merged = sub.merge(
            forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]],
            left_on="date", right_on="ds", how="left",
        )

        is_anom = (merged["production_tonnes"] < merged["yhat_lower"]) | \
                  (merged["production_tonnes"] > merged["yhat_upper"])
        residual_pct = (merged["production_tonnes"] - merged["yhat"]) / merged["yhat"].replace(0, np.nan) * 100

        df.loc[sub.index, "prophet_anomaly"] = is_anom.values
        df.loc[sub.index, "prophet_yhat"] = merged["yhat"].values
        df.loc[sub.index, "prophet_residual_pct"] = residual_pct.values

    return df


# --------------------------------------------------------------------------- #
# 5. ENSEMBLE + REASON CODES
# --------------------------------------------------------------------------- #
def build_ensemble(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    def reason(row):
        reasons = []
        if row["prophet_anomaly"]:
            direction = "below" if row["prophet_residual_pct"] < 0 else "above"
            reasons.append(f"Production {abs(row['prophet_residual_pct']):.0f}% {direction} seasonal forecast")
        if row["if_anomaly"]:
            if abs(row["dispatch_to_production_ratio"] - 1) > 0.3:
                reasons.append("Dispatch/production ratio abnormal")
            if row["downtime_per_active_equip"] > row.get("downtime_per_active_equip", 0):
                reasons.append("Elevated downtime per active equipment")
            if not reasons:
                reasons.append("Multivariate outlier vs 7-day baseline")
        return "; ".join(reasons) if reasons else ""

    df["is_anomaly_flagged"] = df["if_anomaly"] | df["prophet_anomaly"]
    df["flagged_by"] = np.select(
        [df["if_anomaly"] & df["prophet_anomaly"], df["if_anomaly"], df["prophet_anomaly"]],
        ["Isolation Forest + Prophet", "Isolation Forest", "Prophet"],
        default="",
    )

    # Severity: both models agreeing = High; one model = Medium
    df["severity"] = np.select(
        [df["if_anomaly"] & df["prophet_anomaly"], df["is_anomaly_flagged"]],
        ["High", "Medium"],
        default="Low",
    )

    df["reason"] = df.apply(reason, axis=1)
    return df


# --------------------------------------------------------------------------- #
# 6. EVALUATION AGAINST GROUND TRUTH (only present in the synthetic demo data)
# --------------------------------------------------------------------------- #
def evaluate(df: pd.DataFrame) -> dict:
    if "is_anomaly_true" not in df.columns:
        return {}
    tp = ((df["is_anomaly_flagged"]) & (df["is_anomaly_true"])).sum()
    fp = ((df["is_anomaly_flagged"]) & (~df["is_anomaly_true"])).sum()
    fn = ((~df["is_anomaly_flagged"]) & (df["is_anomaly_true"])).sum()
    tn = ((~df["is_anomaly_flagged"]) & (~df["is_anomaly_true"])).sum()

    precision = tp / (tp + fp) if (tp + fp) else 0
    recall = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

    return {
        "true_positives": int(tp), "false_positives": int(fp),
        "false_negatives": int(fn), "true_negatives": int(tn),
        "precision": round(precision, 3), "recall": round(recall, 3), "f1": round(f1, 3),
    }


# --------------------------------------------------------------------------- #
# 7. VISUALIZATION
# --------------------------------------------------------------------------- #
def make_visuals(df: pd.DataFrame, outdir: Path):
    import matplotlib.pyplot as plt

    outdir.mkdir(parents=True, exist_ok=True)

    # Summary bar chart: anomalies per mine
    summary = df[df["is_anomaly_flagged"]].groupby("mine_name").size().sort_values(ascending=False)
    plt.figure(figsize=(8, 5))
    summary.plot(kind="barh", color="#c0392b")
    plt.xlabel("Flagged anomaly-days")
    plt.title("Flagged Production Anomalies by Mine")
    plt.tight_layout()
    plt.savefig(outdir / "anomaly_summary.png", dpi=150)
    plt.close()

    # Per-mine timeline (last 180 days) with anomalies highlighted
    for mine_id, sub in df.groupby("mine_id"):
        sub = sub.sort_values("date").tail(180)
        plt.figure(figsize=(11, 4))
        plt.plot(sub["date"], sub["production_tonnes"], label="Actual production", color="#2c3e50", linewidth=1.2)
        if sub["prophet_yhat"].notna().any():
            plt.plot(sub["date"], sub["prophet_yhat"], label="Expected (Prophet)", color="#3498db",
                      linestyle="--", linewidth=1)
        anoms = sub[sub["is_anomaly_flagged"]]
        plt.scatter(anoms["date"], anoms["production_tonnes"], color="#e74c3c", zorder=5,
                    label="Flagged anomaly", s=35)
        plt.title(f"{sub['mine_name'].iloc[0]} ({mine_id}) — Production, last 180 days")
        plt.ylabel("Tonnes/day")
        plt.legend(loc="upper right", fontsize=8)
        plt.tight_layout()
        plt.savefig(outdir / f"{mine_id}_timeline.png", dpi=150)
        plt.close()


# --------------------------------------------------------------------------- #
# 8. MAIN PIPELINE
# --------------------------------------------------------------------------- #
def run_pipeline(data_path: str, outdir: str = "outputs", as_of: str | None = None):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    df = load_real_data(data_path)
    if as_of:
        df = df[df["date"] <= pd.Timestamp(as_of)]

    print(f"Loaded {len(df):,} rows | {df['mine_id'].nunique()} mines | "
          f"{df['date'].min().date()} -> {df['date'].max().date()}")

    df = engineer_features(df)
    print("Running Isolation Forest (multivariate cross-signal detection)...")
    df = run_isolation_forest(df)

    print("Running Prophet residual detection (per-mine seasonal baseline)...")
    df = run_prophet_residuals(df)

    df = build_ensemble(df)

    report_cols = [
        "date", "mine_id", "mine_name", "production_tonnes", "dispatch_tonnes",
        "equipment_downtime_hours", "prophet_yhat", "prophet_residual_pct",
        "if_score", "severity", "flagged_by", "reason",
    ]
    report = df[df["is_anomaly_flagged"]][report_cols].sort_values(["severity", "date"], ascending=[True, False])
    report.to_csv(outdir / "anomalies_report.csv", index=False)
    print(f"Flagged {len(report):,} anomaly-days -> {outdir/'anomalies_report.csv'}")

    metrics = evaluate(df)
    if metrics:
        print("Evaluation vs injected ground truth (demo data only):")
        print(json.dumps(metrics, indent=2))
        with open(outdir / "evaluation_metrics.json", "w") as f:
            json.dump(metrics, f, indent=2)

    print("Rendering charts...")
    make_visuals(df, outdir)
    print(f"Done. See {outdir}/ for anomalies_report.csv, anomaly_summary.png, and per-mine timelines.")

    return df, report, metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Production Anomaly Detection Model")
    parser.add_argument("--data", default="data/production_data.csv")
    parser.add_argument("--outdir", default="outputs")
    parser.add_argument("--as-of", default=None, help="Score data only up to this date (YYYY-MM-DD)")
    args = parser.parse_args()

    run_pipeline(args.data, args.outdir, args.as_of)
