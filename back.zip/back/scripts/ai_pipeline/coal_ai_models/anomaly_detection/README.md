# Production Anomaly Model — AI Component #2

Part of the Smart Governance Platform for Coal Mining Operations
(Component 2 of 4 in the AI architecture: Compliance/Safety Risk,
**Production Anomaly**, PPE Computer Vision, NLP grievance routing).

| | |
|---|---|
| **Input data** | Daily production, dispatch, equipment downtime (time-series), per mine |
| **Source (production)** | Internal ERP/SCADA + IoT feeds; CIL public production bulletins for macro validation |
| **Method** | Isolation Forest (multivariate) + Prophet (per-mine seasonal residuals) |
| **Output** | Anomaly flag, severity (High/Medium/Low), reason code, per mine per day |
| **Refresh cadence** | Retrain weekly, score daily (or on each new ERP batch) |

## Why two models instead of one

- **Prophet** learns each mine's *own* seasonal rhythm — weekly dip on
  Sundays, monsoon slowdown for opencast mines June–Sept, long-term
  trend — and flags days where actual production falls outside the
  forecast confidence band. Good at catching *"this mine is behaving
  oddly relative to its own history."*
- **Isolation Forest** looks at production, dispatch, downtime, and
  active-equipment count *together* and flags multivariate outliers
  even when no single number looks extreme. Good at catching things
  like *dispatch collapsing relative to production* (possible
  logging gap / pilferage) that a single time-series model would miss.
- Combining both gives a **severity score**: flagged by both models =
  High confidence; flagged by one = Medium (needs a human look).

## Files

```
production_anomaly/
├── generate_synthetic_data.py   # demo data generator (see note below)
├── anomaly_model.py             # the actual model pipeline
├── data/production_data.csv     # generated demo dataset (5 mines, 3 years)
├── outputs/
│   ├── anomalies_report.csv     # flagged anomalies with severity + reason
│   ├── anomaly_summary.png      # anomaly counts by mine
│   ├── evaluation_metrics.json  # precision/recall vs ground truth (demo only)
│   └── <mine_id>_timeline.png   # per-mine chart: actual vs expected, anomalies marked
└── README.md
```

## ⚠️ About the data — read this first

No real ERP/SCADA export was provided, so `generate_synthetic_data.py`
creates a **realistic stand-in dataset** (5 mines, 3 years of daily
records, weekly + monsoon seasonality, and deliberately injected,
labeled anomalies: equipment breakdowns, data-entry spikes,
dispatch/production mismatches, gradual downtime creep) purely so the
model can be built and demonstrated end-to-end.

**To go live:** replace the CSV with a real export in the same schema
(`date, mine_id, mine_name, mine_type, production_tonnes,
dispatch_tonnes, equipment_downtime_hours, active_equipment_count`) and
point `load_real_data()` in `anomaly_model.py` at it — nothing else in
the pipeline needs to change. When real data is used, there will be no
`is_anomaly_true` ground-truth column, so the evaluation step is
skipped automatically.

## Running it

```bash
pip install pandas numpy scikit-learn prophet matplotlib

# 1. Generate the demo dataset
python3 generate_synthetic_data.py

# 2. Run detection
python3 anomaly_model.py --data data/production_data.csv --outdir outputs

# Optional: score only up to a given date (simulates a weekly run)
python3 anomaly_model.py --data data/production_data.csv --as-of 2025-06-30
```

## Demo results (synthetic data)

Against the injected ground-truth anomalies:

| Metric | Value |
|---|---|
| Precision | 0.67 |
| Recall | 0.85 |
| F1 | 0.75 |

Recall is prioritized over precision by design — for a compliance/safety
platform, a missed breakdown or dispatch mismatch is costlier than an
inspector spending two minutes ruling out a false alarm. The
`contamination` parameter in `run_isolation_forest()` and the
`interval_width` in `run_prophet_residuals()` are the two knobs to
tune this trade-off once real data and stakeholder feedback are available.

## Integration into the platform

- **Dashboard**: `anomalies_report.csv` is the feed for the "Production
  Anomalies" widget on the mine-official / corporate dashboards — one
  row per flagged mine-day, with severity and a human-readable reason.
- **Alerts/escalation**: rows with `severity == "High"` should trigger
  the automated alert/escalation workflow described in the platform spec.
- **Weekly retrain**: schedule `anomaly_model.py` to retrain (refit
  Prophet + Isolation Forest on the latest trailing window) weekly, and
  score new days as they land from ERP/SCADA — matching the cadence in
  the AI architecture table.
- **Macro validation**: CIL's public production bulletins can be used
  as an independent cross-check — if a mine's total diverges sharply
  from what it self-reports via ERP, that's itself a high-value
  anomaly signal worth adding as a second Prophet series in a future
  iteration.
