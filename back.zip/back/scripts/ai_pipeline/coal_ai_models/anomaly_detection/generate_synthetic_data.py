"""
generate_synthetic_data.py
---------------------------
Simulates the kind of daily time-series feed the Production Anomaly Model
would normally receive from internal ERP/SCADA systems + CIL public
production bulletins (per the architecture table):

    Model: Production Anomaly
    Data:  Daily production, dispatch, equipment downtime (time-series)
    Source: Internal ERP/SCADA + IoT feeds; CIL public production bulletins
            for macro validation

Since no real ERP/SCADA export was provided, this script creates a realistic
stand-in dataset (multiple mines, 3 years of daily records, weekly/seasonal
patterns, monsoon dip, planned maintenance, and DELIBERATELY INJECTED
anomalies with ground-truth labels) purely so the detection pipeline in
anomaly_model.py can be built, tested and demonstrated end-to-end.

To go live: point `load_real_data()` in anomaly_model.py at the actual
ERP/SCADA extract (same column schema) and drop this generator.
"""

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

MINES = [
    {"mine_id": "TAL-OC-01", "name": "Talcher Opencast",    "type": "Opencast",     "base_tph": 4200},
    {"mine_id": "KOR-UG-02", "name": "Korba Underground",   "type": "Underground",  "base_tph": 1500},
    {"mine_id": "JHR-OC-03", "name": "Jharia Opencast",     "type": "Opencast",     "base_tph": 3100},
    {"mine_id": "SEC-OC-04", "name": "Sohagpur Opencast",   "type": "Opencast",     "base_tph": 2600},
    {"mine_id": "SIN-UG-05", "name": "Singrauli Underground","type": "Underground", "base_tph": 1100},
]

START_DATE = "2023-01-01"
END_DATE = "2025-12-31"


def _seasonal_multiplier(dates: pd.DatetimeIndex, mine_type: str) -> np.ndarray:
    """Weekly dip (Sunday) + monsoon dip for opencast mines (Jun-Sep)."""
    dow_factor = np.where(dates.dayofweek == 6, 0.55, 1.0)          # Sunday low
    dow_factor = np.where(dates.dayofweek == 5, 0.85, dow_factor)   # Saturday partial

    month = dates.month
    if mine_type == "Opencast":
        monsoon_factor = np.where((month >= 6) & (month <= 9), 0.70, 1.0)
    else:
        monsoon_factor = np.ones(len(dates))  # underground less rain-sensitive

    # mild long-term growth trend (efficiency improvements)
    days_elapsed = (dates - dates[0]).days
    trend_factor = 1.0 + 0.00015 * days_elapsed

    return dow_factor * monsoon_factor * trend_factor


def _inject_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """Inject labeled anomalies: equipment breakdowns, strikes, data-entry spikes."""
    df = df.copy()
    df["is_anomaly_true"] = False
    df["anomaly_type_true"] = ""

    for mine_id in df["mine_id"].unique():
        idx = df.index[df["mine_id"] == mine_id]
        n = len(idx)

        # 1) Sudden production crashes (equipment breakdown / strike), 2-4 day events
        n_crash_events = RNG.integers(4, 7)
        for _ in range(n_crash_events):
            start = RNG.integers(30, n - 30)
            duration = RNG.integers(2, 5)
            window = idx[start:start + duration]
            df.loc[window, "production_tonnes"] *= RNG.uniform(0.05, 0.25)
            df.loc[window, "equipment_downtime_hours"] += RNG.uniform(8, 16)
            df.loc[window, "is_anomaly_true"] = True
            df.loc[window, "anomaly_type_true"] = "breakdown/stoppage"

        # 2) Unexplained spikes (possible data entry error or record dumping)
        n_spike_events = RNG.integers(3, 6)
        for _ in range(n_spike_events):
            pos = RNG.integers(0, n)
            i = idx[pos]
            df.loc[i, "production_tonnes"] *= RNG.uniform(1.8, 2.5)
            df.loc[i, "is_anomaly_true"] = True
            df.loc[i, "anomaly_type_true"] = "spike/data-entry"

        # 3) Dispatch-production mismatch (possible pilferage / logging gap)
        n_mismatch_events = RNG.integers(3, 6)
        for _ in range(n_mismatch_events):
            pos = RNG.integers(0, n)
            i = idx[pos]
            df.loc[i, "dispatch_tonnes"] *= RNG.uniform(0.3, 0.5)
            df.loc[i, "is_anomaly_true"] = True
            df.loc[i, "anomaly_type_true"] = "dispatch_mismatch"

        # 4) Silent equipment degradation (gradual downtime creep, 10-day ramps)
        n_creep_events = RNG.integers(1, 3)
        for _ in range(n_creep_events):
            start = RNG.integers(30, n - 40)
            duration = 10
            window = idx[start:start + duration]
            ramp = np.linspace(1.0, 3.0, duration)
            df.loc[window, "equipment_downtime_hours"] *= ramp
            df.loc[window[-3:], "is_anomaly_true"] = True
            df.loc[window[-3:], "anomaly_type_true"] = "downtime_creep"

    return df


def generate() -> pd.DataFrame:
    dates = pd.date_range(START_DATE, END_DATE, freq="D")
    rows = []

    for mine in MINES:
        mult = _seasonal_multiplier(dates, mine["type"])
        noise = RNG.normal(1.0, 0.06, len(dates))
        production = mine["base_tph"] * mult * noise
        production = np.clip(production, 0, None)

        # dispatch tracks production with slight lag/noise (loading + logistics)
        dispatch = production * RNG.normal(0.96, 0.04, len(dates))
        dispatch = np.clip(dispatch, 0, None)

        # equipment downtime hours (baseline maintenance + random)
        base_downtime = 1.5 if mine["type"] == "Opencast" else 2.5
        downtime = np.clip(RNG.normal(base_downtime, 0.8, len(dates)), 0, None)

        active_equipment = RNG.integers(
            18 if mine["type"] == "Opencast" else 10,
            26 if mine["type"] == "Opencast" else 16,
            len(dates),
        )

        mine_df = pd.DataFrame({
            "date": dates,
            "mine_id": mine["mine_id"],
            "mine_name": mine["name"],
            "mine_type": mine["type"],
            "production_tonnes": production.round(1),
            "dispatch_tonnes": dispatch.round(1),
            "equipment_downtime_hours": downtime.round(2),
            "active_equipment_count": active_equipment,
        })
        rows.append(mine_df)

    df = pd.concat(rows, ignore_index=True)
    df = _inject_anomalies(df)
    df["production_tonnes"] = df["production_tonnes"].round(1)
    df["dispatch_tonnes"] = df["dispatch_tonnes"].round(1)
    df["equipment_downtime_hours"] = df["equipment_downtime_hours"].round(2)
    return df


if __name__ == "__main__":
    df = generate()
    out_path = "data/production_data.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df):,} rows across {df['mine_id'].nunique()} mines -> {out_path}")
    print(f"Injected anomalies: {df['is_anomaly_true'].sum()} ({df['is_anomaly_true'].mean()*100:.2f}%)")
