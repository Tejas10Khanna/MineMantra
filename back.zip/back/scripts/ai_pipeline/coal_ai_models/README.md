# Coal Mine Governance — AI Models (consolidated)

Three independent model modules, one per AI component of the platform.
They solve genuinely different problems (tabular risk scoring vs.
time-series anomaly detection vs. text classification), so they're kept
as separate modules rather than forced into one file — what got
consolidated instead was the accidental duplication and inconsistencies
found across them. See "Cleanup notes" below for exactly what changed.

```
coal_ai_models/
  requirements.txt        <- one consolidated install for all 3 modules
  risk_detector/          Compliance/Safety Risk (XGBoost + LLM audit narrative)
  anomaly_detection/      Production Anomaly (Isolation Forest + Prophet)
  grievance_nlp/          Grievance/compliance text triage (TF-IDF baseline,
                           transformer upgrade path documented)
```

Each module keeps its own README/HOW_TO_RUN — those aren't redundant with
this file, they document module-specific usage; this file is just the map.

## Cleanup notes (what was fixed vs. the originally uploaded folder)

1. **Duplicate-upload artifacts removed.** `risk_detector` had two copies
   of two files each — `train_risk_model_v2.py` / `train_risk_model_v2 (1).py`
   and `generate_audit_narrative.py` / `generate_audit_narrative (1).py`.
   The non-`(1)` versions were empty (0 bytes) — a re-upload artifact, not
   intentional versioning. Kept the real content, removed the duplicate.
2. **Stray junk folder removed.** `Grivience nlp/{scripts,configs,common,docs,data,runs}`
   was a literal folder named with unexpanded shell brace syntax (a `mkdir
   {a,b,c}` that ran somewhere without brace expansion) — empty, deleted.
3. **Hardcoded absolute paths fixed.** `train_risk_model_v2.py` and
   `generate_audit_narrative.py` wrote/read `/home/claude/...` paths that
   only existed in whoever's sandbox built them. Now use paths relative to
   the script location, so this runs on any machine.
4. **Broken fallback fixed.** `generate_audit_narrative.py` imported
   `anthropic` unconditionally at the top of the file — meaning the
   whole point of having a no-API-key offline fallback (for demo rooms
   with no internet) was broken if the package wasn't installed. Import
   is now deferred to only when actually calling the LLM.
5. **Inconsistent dependency handling fixed.** `anomaly_model.py` required
   `prophet` with no fallback, unlike the graceful-degradation pattern
   used everywhere else in this project (anthropic, transformers). Now
   degrades to Isolation-Forest-only with a warning if prophet isn't
   installed (verified: still gets F1=0.82 on the synthetic ground truth
   alone).
6. **Inconsistent naming standardized.** Folders renamed from `Grivience
   nlp` / `risk detector` / `anomaly detection` (typo + inconsistent
   spacing) to `grievance_nlp` / `risk_detector` / `anomaly_detection`.
7. **Requirements consolidated.** One `requirements.txt` at the top level
   instead of one buried in `grievance_nlp/` and the rest scattered across
   two different README "pip install" code blocks.

## What was NOT changed (and why)

- **Each module's own synthetic-data generator was kept separate**
  (`risk_detector` generates risk features, `anomaly_detection` generates
  production time series, `grievance_nlp` generates grievance text) —
  these aren't redundant with each other despite the superficial
  similarity; they produce different schemas for different models and
  don't share meaningful logic beyond both using `numpy.random`.
- **`grievance_nlp/common/`'s shared modules were already correctly
  factored** — `04_infer.py` and `07_triage_full_report.py` both call
  the same `triage_one()` in `common/triage.py` rather than duplicating
  that logic; this was already done right in the original upload, no
  change needed.
