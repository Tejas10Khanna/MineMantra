"""
Escalation Worker
===================
The mechanism behind "escalation to the respective head if not actioned."
Run this frequently (every 15-30 min via cron) -- it does NOT generate new
alerts from scratch, it only escalates existing ones that have breached
their SLA without being acknowledged/resolved.

Two things it escalates:
  1. `alerts` with status="open" past their sla_deadline -> escalate_alert()
     bumps them to the next role up the hierarchy (see alert_service.py's
     ROLE_ESCALATION_NEXT), with a tighter SLA each time.
  2. `reminders` with status="pending"/"overdue" past their due_date by
     more than a grace period -> raised as a new alert to the technical
     staff's supervisor (maintenance reminders don't have their own
     escalation chain by default; this routes them into the same alert
     escalation path once they're clearly being ignored).

Run:
    python3 escalation_worker.py
    python3 escalation_worker.py --reminder-grace-hours 48
"""
import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from db import get_db  # noqa: E402
from alert_service import escalate_alert, create_alert  # noqa: E402


def escalate_overdue_alerts(db):
    now = datetime.now(timezone.utc)
    overdue = list(db.alerts.find({"status": "open", "sla_deadline": {"$lt": now}}))
    escalated = 0
    for alert in overdue:
        new_ids = escalate_alert(db, alert)
        if new_ids:
            escalated += 1
        else:
            # already at the top of the internal chain (CMD) -- flag for
            # manual regulator-level escalation instead of looping forever
            db.alerts.update_one(
                {"_id": alert["_id"]},
                {"$set": {"status": "escalation_exhausted",
                          "note": "Reached top of internal escalation chain (CMD) with no action. "
                                  "Manual regulator/CIL escalation required."}}
            )
    print(f"Alert escalation: {len(overdue)} overdue alert(s) found, {escalated} escalated up the chain.")


def escalate_overdue_reminders(db, grace_hours):
    now = datetime.now(timezone.utc)
    grace_cutoff = now - timedelta(hours=grace_hours)
    overdue = list(db.reminders.find({
        "status": {"$in": ["pending", "overdue"]},
        "due_date": {"$lt": grace_cutoff},
        "escalated": {"$ne": True},
    }))

    for reminder in overdue:
        db.reminders.update_one({"_id": reminder["_id"]}, {"$set": {"status": "overdue"}})
        create_alert(
            db,
            alert_type="MAINTENANCE_OVERDUE",
            severity="high",
            mine_id=reminder.get("mine_id"),
            title=f"Maintenance severely overdue: {reminder.get('equipment_id')}",
            message=(f"Reminder for equipment {reminder.get('equipment_id')} has been overdue "
                     f"for more than {grace_hours}h with no completion recorded. "
                     f"Original due date: {reminder['due_date'].date()}."),
            recommended_action="Escalate to maintenance supervisor; confirm equipment safety status.",
            department="engineering",
            responsible_role="manager",  # technical staff's supervisor
            source_collection="reminders",
            source_record_id=reminder["_id"],
        )
        db.reminders.update_one({"_id": reminder["_id"]}, {"$set": {"escalated": True}})

    print(f"Reminder escalation: {len(overdue)} overdue reminder(s) escalated to supervisor.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reminder-grace-hours", type=int, default=48,
                     help="How long past due_date before an unactioned reminder gets escalated")
    args = ap.parse_args()

    db = get_db()
    escalate_overdue_alerts(db)
    escalate_overdue_reminders(db, args.reminder_grace_hours)


if __name__ == "__main__":
    main()
