# AI Pipeline — Integration Layer

Connects the 3 AI models (risk scoring, production anomaly detection,
grievance/incident NLP triage) to the existing MongoDB schema and exposes
their outputs to the frontend dashboard through new Express API endpoints.

**Nothing in the original `back/` structure was renamed, moved, or removed.**
Everything here is new files added inside the folders that were already
scaffolded for exactly this (`scripts/`, `src/controllers/`, `src/routes/`,
`src/services/ai/`, `src/services/analytics/`, `src/middleware/`). The only
edited files are `src/server.js` (route mounting added, nothing removed)
and `scripts/build_risk_features.py` (two `None`-returning TODOs completed
with real logic, see below) — both are additive edits.

## Architecture

```
Python (scripts/ai_pipeline/)          Node (src/)
  reads/writes MongoDB directly   -->    reads MongoDB, serves REST API
  runs on a schedule (cron)               to the frontend dashboard

They never call each other directly. MongoDB is the only integration
point, matching how build_risk_features.py / ingest_prototype_data.py
already work in this project.
```

```
scripts/ai_pipeline/
  db.py                        Mongo connector (mirrors src/config/db.js)
  alert_service.py             creates alerts/reminders, resolves recipients,
                                handles escalation -- THE core integration logic
  run_risk_scoring.py          risk model -> analytics_results + alerts
  run_anomaly_detection.py     anomaly model -> analytics_results + alerts
  run_grievance_triage.py      NLP triage -> grievances update + alerts
  run_maintenance_reminders.py equipment_maintenance -> reminders
  escalation_worker.py         SLA-breach checker, run frequently
  run_all.py                   runs everything in sequence (cron entry point)
  models/                      trained model artifacts (risk_model_v2.json,
                                category_id_classifier.joblib, intent_classifier.joblib)
  grievance_common/, configs/  copied from the grievance_nlp module (taxonomy,
                                routing, language-id, triage logic)
```

## Running it

```bash
cd back/scripts/ai_pipeline
pip install -r requirements.txt
python3 run_all.py                    # one-off run of everything
python3 run_risk_scoring.py           # or run one pipeline at a time
```

Suggested cron schedule:
```
*/15 * * * *  cd .../ai_pipeline && python3 escalation_worker.py
0 * * * *     cd .../ai_pipeline && python3 run_all.py
```

## What each pipeline needs to actually run (current gaps)

None of these are bugs — they're the honest state of what's populated vs.
not yet. Each pipeline prints a clear message and skips gracefully rather
than crashing or fabricating data if its inputs are missing.

| Pipeline | Needs | Status |
|---|---|---|
| Risk scoring | `mines` docs with `mine_id`; violations/CAPAs/accidents/inspections data; **`mines.star_rating`** field (see below); production targets | Will run but skip mines missing `star_rating` (fails closed by design) |
| Anomaly detection | `production_model_inputs` populated (via `scripts/ingest_prototype_data.py` or live ERP feed) | Ready once that collection has data |
| Grievance triage | **`grievances` collection (does not exist yet — see below)** | Blocked until this collection exists |
| Maintenance reminders | `equipment_maintenance` docs with `next_due_date` | Ready once populated |

## Suggested DB additions (please review before deploying)

### 1. New collection: `grievances`
Not created by `initializeDatabase_v2.js` — needed as the mobile app's
write target for worker grievances/incident reports. Recommended shape
(the mobile app should write this, pipeline reads/updates it):
```js
{
  text: String,              // required -- the free-text report
  mine_id: String,
  worker_id: String | null,
  geo: [lat, lon] | null,
  status: "new",              // pipeline sets to "triaged" / "needs_review"
  created_at: Date,
  // fields below are ADDED by run_grievance_triage.py, don't set on write:
  category_id, category_label, category_confidence, domain,
  department, responsible_role, intent, priority, sla_deadline,
  triaged_at, model_version
}
```
Suggested index: `{ mine_id: 1, status: 1 }` and `{ status: 1, created_at: -1 }`.

### 2. `users` — two optional fields needed for correct alert routing
Currently only `employee_id`, `name`, `role` are required. Alert routing
needs to know **which mine/department** a user belongs to, or every alert
for a role goes to everyone with that role company-wide (currently the
fallback behavior in `alert_service.resolve_recipients`, not a crash, but
not real personalization either). Recommended fields to add:
```js
{ ..., department: "safety" | "operations" | "engineering" | ...,
       mine_id: "M001",   // for mine-scoped roles
       area_id: "A01" }   // for area-scoped roles (area_general_manager, project_manager)
```

### 3. `mines` — `star_rating` field
Real, public, per-mine data (Ministry of Coal's Star Rating of Coal Mines,
published since 2018-19). Without it, `run_risk_scoring.py` fails closed
(skips the mine) rather than guessing — same philosophy the original
`build_risk_features.py` already uses for other fields.

### 4. `equipment_maintenance` — confirm field names
`run_maintenance_reminders.py` assumes `mine_id`, `equipment_id`,
`next_due_date`, optionally `responsible_role`. If your actual documents
use different names, edit `FIELD_MAP` at the top of that file (one-line change).

### 5. Optional: `escalation_policies` collection
Escalation chain (`ROLE_ESCALATION_NEXT` in `alert_service.py`) is
currently hardcoded based on the org hierarchy diagram. Fine for the
hackathon, but if departments need different chains, add a collection
and swap that dict for a DB lookup — the function signature already
isolates this so it's a small change later.

## What gets written where (for the frontend/API contract)

- **`analytics_results`** — one doc per risk score / anomaly, `model_type`
  field distinguishes them (`"risk_score"` / `"production_anomaly"`)
- **`alerts`** — one doc PER RECIPIENT (not one doc with a list of
  recipients) so the existing `{recipient_id, acknowledged_at}` index
  works directly for "my alerts" queries. Docs from the same underlying
  event share `alert_group_id`.
- **`reminders`** — maintenance reminders, one per recipient, matches the
  existing `{recipient_id, due_date, status}` index.
- **`escalations`** — audit log of every escalation, matches the existing
  `{source_collection, source_record_id, timestamp}` index.

## New API endpoints (for the frontend team)

All under the existing Express app (`src/server.js`), alongside
`/api/health` and `/api/db-health`.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/dashboard/overview` | `x-employee-id` header | Role-scoped dashboard: risk scores, anomalies, grievances, alert counts, reminder counts |
| GET | `/api/dashboard/mine/:mineId` | none | Full detail for one mine |
| GET | `/api/alerts/mine` | `x-employee-id` header | **Personalized** alerts for the logged-in user |
| GET | `/api/alerts?mine_id=&severity=&status=` | none | Broader alert query |
| POST | `/api/alerts/:id/acknowledge` | `x-employee-id` header | Acknowledge an alert |
| POST | `/api/alerts/:id/resolve` | `x-employee-id` header | Resolve an alert |
| GET | `/api/reminders/mine` | `x-employee-id` header | **Personalized** reminders for the logged-in technical staff user |
| GET | `/api/reminders?mine_id=&status=` | none | Broader reminder query |
| POST | `/api/reminders/:id/complete` | `x-employee-id` header | Mark maintenance done |
| GET | `/api/escalations?mine_id=` | none | Escalation audit trail |

**Important:** `src/middleware/auth.js` is a placeholder — it trusts an
`x-employee-id` header with no verification. This is enough to build the
frontend against today, but must be replaced with real authentication
(JWT/session) before this goes anywhere near production or a public demo
with real data.
