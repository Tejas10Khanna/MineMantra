"""
Shared MongoDB connector for the Python AI pipeline.
Mirrors back/src/config/db.js exactly (same env vars, same DB) so the
Python side and the Node API server are always pointed at one database.

Usage:
    from db import get_db
    db = get_db()
    db.mines.find_one(...)
"""
import os
from pathlib import Path
from pymongo import MongoClient

# Load back/.env regardless of which directory a script is run from.
_ENV_PATH = Path(__file__).resolve().parents[2] / ".env"
try:
    from dotenv import load_dotenv
    load_dotenv(_ENV_PATH)
except ImportError:
    pass  # falls through to os.environ if python-dotenv isn't installed

_client = None
_db = None


def get_db():
    global _client, _db
    if _db is not None:
        return _db

    uri = os.environ.get("MONGODB_URI")
    db_name = os.environ.get("MONGODB_DB")
    if not uri:
        raise RuntimeError(f"MONGODB_URI not set (checked {_ENV_PATH})")
    if not db_name:
        raise RuntimeError(f"MONGODB_DB not set (checked {_ENV_PATH})")

    _client = MongoClient(uri, appName="CCL-Smart-Governance-AI-Pipeline")
    _client.admin.command("ping")
    _db = _client[db_name]
    return _db


def close():
    global _client, _db
    if _client:
        _client.close()
        _client, _db = None, None
