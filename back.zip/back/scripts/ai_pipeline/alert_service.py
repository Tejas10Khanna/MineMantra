"""
Alert / Reminder / Escalation service
======================================
Shared by every AI pipeline script (risk scoring, anomaly detection,
grievance triage) and by the standalone maintenance-reminder and
escalation-worker jobs. This is the ONE place that decides who gets
notified and how escalation works, so behaviour stays consistent across
every model.

Document shapes below were designed to exactly match the indexes already
defined in scripts/initializeDatabase_v2.js (recipient_id+acknowledged_at
for alerts, recipient_id+due_date+status for reminders,
source_collection+source_record_id+timestamp for escalations) -- these
collections exist with no schema validator, so this module IS the schema.
See ai_pipeline/README.md for the exact field list to hand to the frontend
team and to formalize as a validator later if you want one.

Personalization model: one alert DOCUMENT per recipient (not one doc with
a recipient array), because the given index is on a singular
`recipient_id` field. Documents belonging to the same underlying event
share an `alert_group_id` so the dashboard can also show "1 event notified
3 people" if needed, without breaking the per-person index.
"""
import uuid
from datetime import datetime, timedelta, timezone

# --- Escalation chain -------------------------------------------------------
# Mirrors the org hierarchy: Sardar/worker -> Manager/field official ->
# Overman/Safety Officer -> Area GM/Project manager -> CMD & directors ->
# CIL/regulators. Hardcoded here as a sensible default; if you want this
# configurable per-department without a code change, add an
# `escalation_policies` collection (see README "Suggested DB additions")
# and this function becomes a DB lookup instead of a dict.
ROLE_ESCALATION_NEXT = {
    "worker": "sardar",
    "sardar": "manager",
    "overman": "manager",
    "safety_officer": "manager",
    "surveyor": "manager",
    "ventilation_officer": "manager",
    "manager": "area_general_manager",
    "assistant_manager": "manager",
    "area_general_manager": "project_manager",
    "project_manager": "director_technical",
    "director_technical": "cmd",
    "director_personnel": "cmd",
    "director_finance": "cmd",
    "cmd": None,  # top of the internal chain; CIL/regulator escalation is a separate, manual step
}

DEFAULT_SLA_HOURS = {"critical": 4, "high": 24, "medium": 72, "low": 168}


def _new_group_id():
    return str(uuid.uuid4())


def resolve_recipients(db, mine_id=None, department=None, responsible_role=None, area_id=None):
    """
    Finds the actual user(s) an alert should go to.

    Assumes `users` documents have (beyond the required employee_id/name/role):
    an optional `department` field and an optional `mine_id` / `area_id` field
    for scoping. If your `users` collection doesn't have these fields yet,
    see README "Suggested DB additions" -- alerts will fall back to
    role-only matching (no mine scoping) until they're added, which means
    everyone with that role across all mines gets notified. That's a
    correctness gap worth closing before real deployment, not a bug in this
    code.
    """
    query = {}
    if responsible_role:
        query["role"] = responsible_role
    if department:
        query["department"] = department
    if mine_id:
        query["$or"] = [{"mine_id": mine_id}, {"mine_id": {"$exists": False}}]
    if area_id:
        query.setdefault("$or", [])
        query["$or"].append({"area_id": area_id})

    users = list(db.users.find(query))
    if not users and responsible_role:
        # fall back to role-only match if the scoped query found nobody --
        # better to over-notify than to silently drop a safety-critical alert
        users = list(db.users.find({"role": responsible_role}))
    return users


def create_alert(db, *, alert_type, severity, mine_id, title, message,
                  recommended_action=None, department=None, responsible_role=None,
                  source_collection=None, source_record_id=None,
                  sla_hours=None, model_version=None, extra=None):
    """
    Creates one personalized alert document per resolved recipient.
    Returns (inserted_ids, alert_group_id, recipients).
    """
    recipients = resolve_recipients(db, mine_id=mine_id, department=department,
                                     responsible_role=responsible_role)
    sla_hours = sla_hours or DEFAULT_SLA_HOURS.get(severity, 72)
    now = datetime.now(timezone.utc)
    deadline = now + timedelta(hours=sla_hours)
    group_id = _new_group_id()

    docs = []
    if recipients:
        for user in recipients:
            doc = {
                "alert_group_id": group_id,
                "alert_type": alert_type,
                "severity": severity,
                "mine_id": mine_id,
                "department": department,
                "responsible_role": responsible_role,
                "recipient_id": user["employee_id"],
                "recipient_name": user.get("name"),
                "title": title,
                "message": message,
                "recommended_action": recommended_action,
                "source_collection": source_collection,
                "source_record_id": source_record_id,
                "status": "open",
                "escalation_level": 0,
                "sla_hours": sla_hours,
                "sla_deadline": deadline,
                "acknowledged_at": None,
                "acknowledged_by": None,
                "resolved_at": None,
                "created_at": now,
                "model_version": model_version,
            }
            if extra:
                doc.update(extra)
            docs.append(doc)
    else:
        # No matching user found at all -- still record the alert (unassigned)
        # rather than silently dropping it, and flag it loudly so someone
        # notices the routing gap (missing department/role data on `users`).
        doc = {
            "alert_group_id": group_id, "alert_type": alert_type, "severity": severity,
            "mine_id": mine_id, "department": department, "responsible_role": responsible_role,
            "recipient_id": None, "recipient_name": None,
            "title": title, "message": message, "recommended_action": recommended_action,
            "source_collection": source_collection, "source_record_id": source_record_id,
            "status": "unassigned", "escalation_level": 0,
            "sla_hours": sla_hours, "sla_deadline": deadline,
            "acknowledged_at": None, "acknowledged_by": None, "resolved_at": None,
            "created_at": now, "model_version": model_version,
            "routing_warning": f"No user found for role={responsible_role} department={department} mine={mine_id}",
        }
        docs.append(doc)

    if docs:
        result = db.alerts.insert_many(docs)
        return result.inserted_ids, group_id, recipients
    return [], group_id, []


def create_reminder(db, *, reminder_type, mine_id, due_date, title, message,
                     responsible_role=None, equipment_id=None, recipient_id=None,
                     source_collection=None, source_record_id=None):
    """
    Creates a reminder (e.g. equipment maintenance due). If recipient_id is
    not given, resolves technical staff by responsible_role the same way
    alerts do.
    """
    recipients = [{"employee_id": recipient_id}] if recipient_id else \
        resolve_recipients(db, mine_id=mine_id, responsible_role=responsible_role)

    now = datetime.now(timezone.utc)
    docs = []
    for user in (recipients or [{"employee_id": None}]):
        docs.append({
            "reminder_type": reminder_type,
            "mine_id": mine_id,
            "equipment_id": equipment_id,
            "recipient_id": user.get("employee_id"),
            "responsible_role": responsible_role,
            "title": title,
            "message": message,
            "due_date": due_date,
            "status": "pending" if due_date >= now else "overdue",
            "source_collection": source_collection,
            "source_record_id": source_record_id,
            "created_at": now,
            "completed_at": None,
        })
    if docs:
        result = db.reminders.insert_many(docs)
        return result.inserted_ids
    return []


def record_escalation(db, *, source_collection, source_record_id, mine_id,
                       from_role, to_role, reason, level):
    now = datetime.now(timezone.utc)
    doc = {
        "source_collection": source_collection,
        "source_record_id": source_record_id,
        "mine_id": mine_id,
        "from_role": from_role,
        "to_role": to_role,
        "reason": reason,
        "level": level,
        "timestamp": now,
    }
    return db.escalations.insert_one(doc).inserted_id


def escalate_alert(db, alert_doc):
    """
    Bumps one overdue, unacknowledged alert up the chain: marks it escalated,
    creates a new alert for the next role up, and logs the escalation.
    Returns the new alert's id, or None if already at the top of the chain.
    """
    current_role = alert_doc.get("responsible_role")
    next_role = ROLE_ESCALATION_NEXT.get(current_role)
    if not next_role:
        return None  # already at CMD / top of internal chain -- needs manual regulator escalation

    db.alerts.update_one(
        {"_id": alert_doc["_id"]},
        {"$set": {"status": "escalated", "escalated_at": datetime.now(timezone.utc)}}
    )

    new_ids, group_id, _ = create_alert(
        db,
        alert_type=alert_doc["alert_type"],
        severity="critical" if alert_doc["severity"] != "critical" else alert_doc["severity"],
        mine_id=alert_doc["mine_id"],
        title=f"[ESCALATED] {alert_doc['title']}",
        message=(f"Escalated from {current_role} -- no action within SLA "
                 f"({alert_doc['sla_hours']}h). Original message: {alert_doc['message']}"),
        recommended_action=alert_doc.get("recommended_action"),
        department=alert_doc.get("department"),
        responsible_role=next_role,
        source_collection=alert_doc.get("source_collection"),
        source_record_id=alert_doc.get("source_record_id"),
        sla_hours=max(2, (alert_doc.get("sla_hours") or 24) // 2),  # tighter SLA at each escalation
        model_version=alert_doc.get("model_version"),
        extra={"escalation_level": alert_doc.get("escalation_level", 0) + 1,
               "escalated_from_alert_id": alert_doc["_id"]},
    )

    record_escalation(
        db, source_collection="alerts", source_record_id=alert_doc["_id"],
        mine_id=alert_doc["mine_id"], from_role=current_role, to_role=next_role,
        reason="SLA breach: no acknowledgement in time", level=alert_doc.get("escalation_level", 0) + 1,
    )
    return new_ids
