"""
Risk Scoring Pipeline (live)
==============================
Runs for every mine: builds the live feature vector via the existing
scripts/build_risk_features.py (unmodified), scores it with the trained
XGBoost model (risk_model_v2.json, from the risk_detector model folder),
writes the result to `analytics_results`, and raises a RISK_ESCALATION
alert for mines crossing into high/critical risk.

Also generates the LLM (or offline-fallback) audit narrative from the
risk_detector module and stores it alongside the score -- this is the
"personalized, explainable" alert content shown on the dashboard, not
just a bare number.

Run:
    python3 run_risk_scoring.py                 # all mines
    python3 run_risk_scoring.py --mine-id M001   # one mine

Schedule this hourly or on every new inspection/violation/accident write
(via a DB change stream, or cron) -- see README.
"""
import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from xgboost import XGBRegressor

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # for build_risk_features.py

from db import get_db  # noqa: E402
from alert_service import create_alert  # noqa: E402
from build_risk_features import build_features, RISK_FEATURES  # noqa: E402

MODEL_PATH = Path(__file__).resolve().parent / "models" / "risk_model_v2.json"

# Same baselines/labels as risk_detector/train_risk_model_v2.py -- kept in
# sync manually since this is the deployed copy, not a shared import (the
# model file crossed from a separate repo). If you retrain, copy the new
# risk_model_v2.json here and update this dict from the training script.
FEATURE_META = {
    "violation_count_30d": {"label": "Statutory violations (30d)", "cause_rank": None},
    "violation_count_90d": {"label": "Statutory violations (90d)", "cause_rank": None},
    "overdue_capa_count": {"label": "Overdue corrective actions", "cause_rank": None},
    "avg_capa_age_days": {"label": "Average age of open corrective actions", "cause_rank": None},
    "accident_count_365d": {"label": "Accidents (past year)", "cause_rank": None},
    "fatality_count_365d": {"label": "Fatalities (past year)", "cause_rank": None},
    "inspection_count_90d": {"label": "Inspections carried out (90d)", "cause_rank": None},
    "days_since_last_inspection": {"label": "Days since last inspection", "cause_rank": None},
    "production_deviation_pct": {"label": "Production deviation from target", "cause_rank": None},
    "star_rating": {"label": "Ministry of Coal star rating", "cause_rank": None},
    "mine_type_UG": {"label": "Underground mine", "cause_rank": None},
    "strata_alert_count_30d": {"label": "Strata/roof-fall early-warning alerts", "cause_rank": "DGMS cause #1: roof and side falls"},
    "hemm_proximity_alert_count_30d": {"label": "HEMM proximity/collision alerts", "cause_rank": "DGMS cause #2: surface transport/machinery"},
    "gas_dust_breach_count_30d": {"label": "Gas/dust threshold breaches", "cause_rank": "DGMS cause #5: dust/gas/combustible material"},
    "electrical_fault_count_30d": {"label": "Electrical fault/isolation alerts", "cause_rank": "DGMS cause #4: electricity"},
}
BASELINES = {
    "violation_count_30d": 2, "violation_count_90d": 6, "overdue_capa_count": 1,
    "avg_capa_age_days": 15, "accident_count_365d": 1, "fatality_count_365d": 0,
    "inspection_count_90d": 2, "days_since_last_inspection": 35,
    "production_deviation_pct": 0, "star_rating": 5, "mine_type_UG": 0,
    "strata_alert_count_30d": 1, "hemm_proximity_alert_count_30d": 1,
    "gas_dust_breach_count_30d": 1, "electrical_fault_count_30d": 1,
}


def load_model():
    model = XGBRegressor()
    model.load_model(str(MODEL_PATH))
    return model


def score_and_explain(model, feature_dict, top_n=4):
    row = np.array([[feature_dict[c] for c in RISK_FEATURES]])
    score = float(np.clip(model.predict(row)[0], 0, 100))
    band = "low" if score < 25 else "medium" if score < 50 else "high" if score < 75 else "critical"

    importances = model.feature_importances_
    contributions = []
    for feat, imp in zip(RISK_FEATURES, importances):
        val = feature_dict[feat]
        base = BASELINES[feat] or 1
        deviation = (val - base) / (abs(base) + 1)
        contributions.append({
            "feature": feat, "label": FEATURE_META[feat]["label"],
            "cause_rank": FEATURE_META[feat]["cause_rank"], "value": val,
            "contribution_score": round(imp * max(deviation, 0), 4),
        })
    top_factors = sorted(contributions, key=lambda x: -x["contribution_score"])[:top_n]
    top_factors = [f for f in top_factors if f["contribution_score"] > 0]
    return {"score": round(score, 1), "band": band, "top_factors": top_factors}


def narrative_for(mine_name, result):
    """Deterministic fallback narrative (no API key needed). See
    risk_detector/generate_audit_narrative.py for the optional LLM version --
    not called automatically here to avoid a hard dependency on network/API
    keys inside a scheduled job; wire it in there if you want richer prose."""
    if not result["top_factors"]:
        return (f"{mine_name}: risk score {result['score']} ({result['band']}). "
                "No single factor is dominant -- risk is broadly distributed.")
    lines = [f"{mine_name}: risk score {result['score']} ({result['band']})."]
    for f in result["top_factors"][:2]:
        cause = f" This corresponds to {f['cause_rank']}." if f["cause_rank"] else ""
        lines.append(f"Primary driver: {f['label']} (observed value: {f['value']}).{cause}")
    return " ".join(lines)


def run_for_mine(db, model, mine_doc):
    mine_id = mine_doc.get("mine_id") or str(mine_doc["_id"])
    try:
        features = build_features(db, mine_id)
    except ValueError as e:
        print(f"[SKIP] {mine_id}: {e}")
        return None

    result = score_and_explain(model, features)
    now = datetime.now(timezone.utc)

    analytics_doc = {
        "model_type": "risk_score",
        "model_version": "risk_model_v2",
        "mine_id": mine_id,
        "record_id": mine_id,
        "score_or_label": result["score"],
        "risk_band": result["band"],
        "top_factors": result["top_factors"],
        "narrative": narrative_for(mine_doc.get("name", mine_id), result),
        "input_features": features,
        "generated_at": now,
    }
    db.analytics_results.insert_one(analytics_doc)

    if result["band"] in ("high", "critical"):
        create_alert(
            db,
            alert_type="RISK_ESCALATION",
            severity=result["band"],
            mine_id=mine_id,
            title=f"{mine_doc.get('name', mine_id)} flagged {result['band'].upper()} risk",
            message=analytics_doc["narrative"],
            recommended_action="Schedule priority inspection; review open corrective actions.",
            department="safety",
            responsible_role="manager",
            source_collection="analytics_results",
            source_record_id=analytics_doc.get("_id"),
            model_version="risk_model_v2",
        )
    print(f"[{mine_id}] risk={result['score']} band={result['band']}")
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mine-id", default=None)
    args = ap.parse_args()

    db = get_db()
    model = load_model()

    query = {"mine_id": args.mine_id} if args.mine_id else {}
    # mines collection uses `name`/`type`; mine_id may live as a separate
    # field or as _id depending on how master data was seeded -- handle both.
    mines = list(db.mines.find(query)) or list(db.mines.find({"_id": args.mine_id}) if args.mine_id else {})

    if not mines:
        print("No mines found in `mines` collection -- nothing to score. "
              "Seed mine master data first (see README).")
        return

    for mine_doc in mines:
        run_for_mine(db, model, mine_doc)


if __name__ == "__main__":
    main()
