
/**
 * CCL Smart Governance DB — V3 model compatibility patch
 *
 * Run AFTER initializeDatabase_v2.js.
 * This script does not drop collections.
 *
 * Purpose:
 * - Create model-facing collections whose schemas exactly match the synthetic
 *   datasets used by the prototype.
 * - Keep normalized governance/reporting data and ML-facing read models
 *   separate.
 */

require("dotenv").config();
const { MongoClient } = require("mongodb");

const uri = process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB || "ccl_smart_governance";

if (!uri) {
  console.error("Missing MONGODB_URI");
  process.exit(1);
}

const MODEL_COLLECTIONS = {
  production_model_inputs: {
    validator: {
      $jsonSchema: {
        bsonType: "object",
        required: [
          "date","mine_id","mine_name","mine_type",
          "production_tonnes","dispatch_tonnes",
          "equipment_downtime_hours","active_equipment_count"
        ],
        properties: {
          date: { bsonType: "date" },
          mine_id: { bsonType: "string" },
          mine_name: { bsonType: "string" },
          mine_type: { enum: ["Opencast","Underground"] },
          production_tonnes: { bsonType: ["double","int","long","decimal"] },
          dispatch_tonnes: { bsonType: ["double","int","long","decimal"] },
          equipment_downtime_hours: { bsonType: ["double","int","long","decimal"] },
          active_equipment_count: { bsonType: ["int","long","double"] },
          is_anomaly_true: { bsonType: ["bool","null"] },
          anomaly_type_true: { bsonType: ["string","null"] }
        }
      }
    },
    indexes: [
      [{ mine_id: 1, date: 1 }, { unique: true, name: "uq_prod_model_mine_date" }],
      [{ date: -1 }, { name: "ix_prod_model_date" }]
    ]
  },

  risk_training_samples: {
    validator: {
      $jsonSchema: {
        bsonType: "object",
        required: [
          "mine_id","period",
          "violation_count_30d","violation_count_90d",
          "overdue_capa_count","avg_capa_age_days",
          "accident_count_365d","fatality_count_365d",
          "inspection_count_90d","days_since_last_inspection",
          "production_deviation_pct","star_rating","mine_type_UG",
          "risk_score"
        ]
      }
    },
    indexes: [
      [{ mine_id: 1, period: 1 }, { name: "ix_risk_training_mine_period" }]
    ]
  },

  risk_feature_snapshots: {
    validator: {
      $jsonSchema: {
        bsonType: "object",
        required: [
          "mine_id","as_of",
          "violation_count_30d","violation_count_90d",
          "overdue_capa_count","avg_capa_age_days",
          "accident_count_365d","fatality_count_365d",
          "inspection_count_90d","days_since_last_inspection",
          "production_deviation_pct","star_rating","mine_type_UG",
          "strata_alert_count_30d","hemm_proximity_alert_count_30d",
          "gas_dust_breach_count_30d","electrical_fault_count_30d"
        ]
      }
    },
    indexes: [
      [{ mine_id: 1, as_of: -1 }, { name: "ix_risk_features_mine_time" }]
    ]
  }
};

async function ensureCollection(db, name, config) {
  const exists = await db.listCollections({ name }).toArray();
  if (!exists.length) {
    await db.createCollection(name, {
      validator: config.validator,
      validationLevel: "moderate",
      validationAction: "error"
    });
    console.log(`Created ${name}`);
  } else {
    await db.command({
      collMod: name,
      validator: config.validator,
      validationLevel: "moderate",
      validationAction: "error"
    });
    console.log(`Updated validator ${name}`);
  }

  const c = db.collection(name);
  for (const [key, options] of config.indexes) {
    try { await c.createIndex(key, options); }
    catch (e) { console.warn(`Index ${name}/${options.name}: ${e.message}`); }
  }
}

async function main() {
  const client = new MongoClient(uri);
  await client.connect();

  try {
    const db = client.db(dbName);
    for (const [name, config] of Object.entries(MODEL_COLLECTIONS)) {
      await ensureCollection(db, name, config);
    }

    // Add source-data metadata to analytics_results without forcing a schema.
    try {
      await db.command({
        collMod: "analytics_results",
        validator: { $jsonSchema: { bsonType: "object" } },
        validationLevel: "moderate",
        validationAction: "error"
      });
    } catch (_) {}

    console.log("V3 model-compatibility schema ready.");
  } finally {
    await client.close();
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
