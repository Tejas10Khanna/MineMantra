
"""
Prototype-to-MongoDB ingestion adapter.

This keeps the prototype model inputs EXACTLY compatible with the uploaded
synthetic datasets while also populating normalized collections used by the
four report families.

Environment:
  MONGODB_URI=...
  MONGODB_DB=ccl_smart_governance

Usage:
  python ingest_prototype_data.py \
      --production-csv /path/production_data.csv \
      --risk-csv /path/synthetic_training_data.csv
"""

import argparse
import os
from dotenv import load_dotenv
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from pymongo import MongoClient, UpdateOne
load_dotenv()

PRODUCTION_COLUMNS = [
    "date","mine_id","mine_name","mine_type","production_tonnes",
    "dispatch_tonnes","equipment_downtime_hours","active_equipment_count",
    "is_anomaly_true","anomaly_type_true"
]

RISK_COLUMNS = [
    "mine_id","period","violation_count_30d","violation_count_90d",
    "overdue_capa_count","avg_capa_age_days","accident_count_365d",
    "fatality_count_365d","inspection_count_90d",
    "days_since_last_inspection","production_deviation_pct",
    "star_rating","mine_type_UG","risk_score"
]


def to_records(df):
    df = df.copy()
    return df.where(pd.notnull(df), None).to_dict("records")


def ingest_production(db, csv_path):
    df = pd.read_csv(csv_path)
    missing = set(PRODUCTION_COLUMNS) - set(df.columns)
    if missing:
        raise ValueError(f"Production CSV missing columns: {sorted(missing)}")

    # Exact model-facing collection.
    df["date"] = pd.to_datetime(df["date"], utc=True)

    prod_docs = []
    normalized_prod = []
    normalized_dispatch = []
    normalized_downtime = []

    for row in df.to_dict("records"):
        d = row.copy()

        prod_docs.append({
            "date": d["date"].to_pydatetime(),
            "mine_id": str(d["mine_id"]),
            "mine_name": str(d["mine_name"]),
            "mine_type": str(d["mine_type"]),
            "production_tonnes": float(d["production_tonnes"]),
            "dispatch_tonnes": float(d["dispatch_tonnes"]),
            "equipment_downtime_hours": float(d["equipment_downtime_hours"]),
            "active_equipment_count": int(d["active_equipment_count"]),
            "is_anomaly_true": bool(d["is_anomaly_true"]) if d["is_anomaly_true"] is not None else None,
            "anomaly_type_true": d["anomaly_type_true"],
            "source": "production_data.csv",
            "prototype_ground_truth": True,
        })

        normalized_prod.append({
            "production_date": d["date"].to_pydatetime(),
            "mine_id": str(d["mine_id"]),
            "mine_name_source": str(d["mine_name"]),
            "mine_type_code": "OC" if d["mine_type"] == "Opencast" else "UG",
            "mine_type_source": str(d["mine_type"]),
            "coal_tonnes": float(d["production_tonnes"]),
            "source": "production_data.csv",
        })

        normalized_dispatch.append({
            "dispatch_date": d["date"].to_pydatetime(),
            "mine_id": str(d["mine_id"]),
            "mine_name_source": str(d["mine_name"]),
            "product_type": "raw_coal",
            "mode": "unspecified",
            "sector": "unspecified",
            "tonnes": float(d["dispatch_tonnes"]),
            "source": "production_data.csv",
            "prototype_input": True,
        })

        normalized_downtime.append({
            "mine_id": str(d["mine_id"]),
            "date": d["date"].to_pydatetime(),
            "hours": float(d["equipment_downtime_hours"]),
            "source": "production_data.csv",
        })

    db.production_model_inputs.bulk_write([
        UpdateOne({"mine_id": x["mine_id"], "date": x["date"]},
                  {"$set": x}, upsert=True)
        for x in prod_docs
    ], ordered=False)

    db.production_records.bulk_write([
        UpdateOne({"mine_id": x["mine_id"], "production_date": x["production_date"]},
                  {"$set": x}, upsert=True)
        for x in normalized_prod
    ], ordered=False)

    db.dispatch_records.bulk_write([
        UpdateOne({"mine_id": x["mine_id"], "dispatch_date": x["dispatch_date"],
                   "product_type": x["product_type"], "mode": x["mode"]},
                  {"$set": x}, upsert=True)
        for x in normalized_dispatch
    ], ordered=False)

    db.downtime_records.bulk_write([
        UpdateOne({"mine_id": x["mine_id"], "date": x["date"]},
                  {"$set": x}, upsert=True)
        for x in normalized_downtime
    ], ordered=False)

    print(f"Production ingested: {len(df):,} rows across {df.mine_id.nunique()} mines.")


def ingest_risk_training(db, csv_path):
    df = pd.read_csv(csv_path)
    missing = set(RISK_COLUMNS) - set(df.columns)
    if missing:
        raise ValueError(f"Risk training CSV missing columns: {sorted(missing)}")

    # Preserve exact prototype data. Do not coerce mine_id to production mine IDs.
    docs = to_records(df)
    for x in docs:
        x["source"] = "synthetic_training_data.csv"
        x["ingested_at"] = datetime.now(timezone.utc)

    # Replace by (mine_id, period) to make the import idempotent.
    db.risk_training_samples.bulk_write([
        UpdateOne({"mine_id": x["mine_id"], "period": x["period"]},
                  {"$set": x}, upsert=True)
        for x in docs
    ], ordered=False)

    print(f"Risk training samples ingested: {len(df):,} rows.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--production-csv", required=True)
    parser.add_argument("--risk-csv", required=True)
    args = parser.parse_args()

    uri = os.getenv("MONGODB_URI")
    db_name = os.getenv("MONGODB_DB", "ccl_smart_governance")

    if not uri:
        raise SystemExit("Set MONGODB_URI first.")

    client = MongoClient(uri)
    db = client[db_name]

    try:
        ingest_production(db, Path(args.production_csv))
        ingest_risk_training(db, Path(args.risk_csv))
        print("Prototype ingestion complete.")
    finally:
        client.close()


if __name__ == "__main__":
    main()
