/**
 * PLACEHOLDER auth middleware.
 *
 * There's no real authentication in this backend yet (no JWT/session
 * anywhere in the uploaded structure). This middleware exists only so
 * personalized endpoints (alerts/reminders "for me") have a concept of
 * "who is asking" to build against today.
 *
 * It reads an `x-employee-id` header and looks up that user from `users`.
 * Replace this with real auth (JWT verification, session lookup, etc.)
 * before going anywhere near production -- trusting a client-supplied
 * header for identity is NOT secure, it's a development stand-in.
 *
 * Usage in a route:
 *   router.get("/alerts/mine", requireUser, alertsController.getMyAlerts);
 */
const { getDB } = require("../config/db");

async function requireUser(req, res, next) {
  const employeeId = req.header("x-employee-id");
  if (!employeeId) {
    return res.status(401).json({
      status: "error",
      message: "Missing x-employee-id header (placeholder auth -- replace with real auth before production).",
    });
  }

  try {
    const db = getDB();
    const user = await db.collection("users").findOne({ employee_id: employeeId });
    if (!user) {
      return res.status(401).json({ status: "error", message: "Unknown employee_id." });
    }
    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
}

module.exports = { requireUser };
