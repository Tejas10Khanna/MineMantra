const { MongoClient } = require("mongodb");

const uri = process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB;

if (!uri) {
  throw new Error("MONGODB_URI is missing from .env");
}

if (!dbName) {
  throw new Error("MONGODB_DB is missing from .env");
}

const client = new MongoClient(uri, {
  appName: "CCL-Smart-Governance",
});

let db = null;

async function connectDB() {
  if (db) {
    return db;
  }

  await client.connect();

  await client.db("admin").command({ ping: 1 });

  db = client.db(dbName);

  console.log(`MongoDB connected: ${dbName}`);

  return db;
}

function getDB() {
  if (!db) {
    throw new Error("MongoDB is not connected");
  }

  return db;
}

module.exports = {
  connectDB,
  getDB,
};