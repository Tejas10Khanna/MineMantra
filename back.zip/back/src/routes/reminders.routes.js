const express = require("express");
const router = express.Router();
const remindersController = require("../controllers/remindersController");
const { requireUser } = require("../middleware/auth");

router.get("/mine", requireUser, remindersController.getMyReminders);
router.get("/", remindersController.listReminders);
router.post("/:id/complete", requireUser, remindersController.complete);

module.exports = router;
