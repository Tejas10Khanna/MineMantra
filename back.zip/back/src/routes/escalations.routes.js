const express = require("express");
const router = express.Router();
const escalationsController = require("../controllers/escalationsController");

router.get("/", escalationsController.listEscalations);

module.exports = router;
