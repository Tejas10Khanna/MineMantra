const express = require("express");
const router = express.Router();
const dashboardController = require("../controllers/dashboardController");
const { requireUser } = require("../middleware/auth");

router.get("/overview", requireUser, dashboardController.overview);
router.get("/mine/:mineId", dashboardController.mineDetail);

module.exports = router;
