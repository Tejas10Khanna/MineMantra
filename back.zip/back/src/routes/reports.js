const {
    testNemotron
} = require("../services/ai/nemotron");

const express = require("express");
const path = require("path");

const {
  generateReport
} = require("../controllers/reportController");

const router = express.Router();

router.post(
  "/generate",
  generateReport
);

router.get(
  "/download/:filename",
  (req, res) => {
    const filename = path.basename(
      req.params.filename
    );

    const filePath =
      path.join(
        process.cwd(),
        "reports",
        "generated",
        filename
      );

    res.download(filePath);
  }
);
router.get("/test-nemotron", async (req, res) => {
  try {
    const result = await testNemotron();

    res.json({
      status: "success",
      model: process.env.NVIDIA_MODEL,
      response: result
    });

  } catch (error) {
    console.error("Nemotron error:", error);

    res.status(500).json({
      status: "error",
      message: error.message,
      details: error.response?.data || null
    });
  }
});
module.exports = router;