const express = require("express");
const router = express.Router();
const alertsController = require("../controllers/alertsController");
const { requireUser } = require("../middleware/auth");

router.get("/mine", requireUser, alertsController.getMyAlerts);
router.get("/", alertsController.listAlerts);
router.post("/:id/acknowledge", requireUser, alertsController.acknowledge);
router.post("/:id/resolve", requireUser, alertsController.resolve);

module.exports = router;
