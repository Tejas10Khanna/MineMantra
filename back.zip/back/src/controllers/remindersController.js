const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

/** GET /api/reminders/mine -- personalized reminders for the logged-in technical staff user */
async function getMyReminders(req, res, next) {
  try {
    const db = getDB();
    const status = req.query.status || "pending";
    const reminders = await db.collection("reminders")
      .find({ recipient_id: req.user.employee_id, status: status === "all" ? { $exists: true } : status })
      .sort({ due_date: 1 })
      .toArray();
    res.json({ status: "ok", data: reminders });
  } catch (error) {
    next(error);
  }
}

async function listReminders(req, res, next) {
  try {
    const db = getDB();
    const query = {};
    if (req.query.mine_id) query.mine_id = req.query.mine_id;
    if (req.query.status) query.status = req.query.status;

    const reminders = await db.collection("reminders")
      .find(query)
      .sort({ due_date: 1 })
      .limit(parseInt(req.query.limit, 10) || 100)
      .toArray();
    res.json({ status: "ok", data: reminders });
  } catch (error) {
    next(error);
  }
}

async function complete(req, res, next) {
  try {
    const db = getDB();
    const result = await db.collection("reminders").findOneAndUpdate(
      { _id: new ObjectId(req.params.id) },
      { $set: { status: "done", completed_at: new Date(), completion_note: req.body.note || null } },
      { returnDocument: "after" }
    );
    if (!result.value) return res.status(404).json({ status: "error", message: "Reminder not found" });
    res.json({ status: "ok", data: result.value });
  } catch (error) {
    next(error);
  }
}

module.exports = { getMyReminders, listReminders, complete };
