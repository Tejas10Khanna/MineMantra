const { getDB } = require("../config/db");

/** GET /api/escalations?mine_id= -- escalation history, e.g. for a corporate/regulator audit view */
async function listEscalations(req, res, next) {
  try {
    const db = getDB();
    const query = {};
    if (req.query.mine_id) query.mine_id = req.query.mine_id;

    const escalations = await db.collection("escalations")
      .find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(req.query.limit, 10) || 100)
      .toArray();
    res.json({ status: "ok", data: escalations });
  } catch (error) {
    next(error);
  }
}

module.exports = { listEscalations };
