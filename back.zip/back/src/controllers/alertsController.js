const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

/** GET /api/alerts/mine -- personalized alerts for the logged-in user (req.user via requireUser) */
async function getMyAlerts(req, res, next) {
  try {
    const db = getDB();
    const status = req.query.status || "open";
    const alerts = await db.collection("alerts")
      .find({ recipient_id: req.user.employee_id, status })
      .sort({ severity: 1, created_at: -1 })
      .toArray();
    res.json({ status: "ok", data: alerts });
  } catch (error) {
    next(error);
  }
}

/** GET /api/alerts?mine_id=&severity=&status= -- broader query, e.g. for a mine-wide alerts panel */
async function listAlerts(req, res, next) {
  try {
    const db = getDB();
    const query = {};
    if (req.query.mine_id) query.mine_id = req.query.mine_id;
    if (req.query.severity) query.severity = req.query.severity;
    if (req.query.status) query.status = req.query.status;

    const alerts = await db.collection("alerts")
      .find(query)
      .sort({ created_at: -1 })
      .limit(parseInt(req.query.limit, 10) || 100)
      .toArray();
    res.json({ status: "ok", data: alerts });
  } catch (error) {
    next(error);
  }
}

async function acknowledge(req, res, next) {
  try {
    const db = getDB();
    const result = await db.collection("alerts").findOneAndUpdate(
      { _id: new ObjectId(req.params.id) },
      { $set: { status: "acknowledged", acknowledged_at: new Date(), acknowledged_by: req.user?.employee_id || req.body.acknowledged_by } },
      { returnDocument: "after" }
    );
    if (!result.value) return res.status(404).json({ status: "error", message: "Alert not found" });
    res.json({ status: "ok", data: result.value });
  } catch (error) {
    next(error);
  }
}

async function resolve(req, res, next) {
  try {
    const db = getDB();
    const result = await db.collection("alerts").findOneAndUpdate(
      { _id: new ObjectId(req.params.id) },
      { $set: { status: "resolved", resolved_at: new Date(), resolution_note: req.body.note || null } },
      { returnDocument: "after" }
    );
    if (!result.value) return res.status(404).json({ status: "error", message: "Alert not found" });
    res.json({ status: "ok", data: result.value });
  } catch (error) {
    next(error);
  }
}

module.exports = { getMyAlerts, listAlerts, acknowledge, resolve };
