const { getOverview, getMineDetail } = require("../services/analytics/dashboardAggregator");

async function overview(req, res, next) {
  try {
    const data = await getOverview({ user: req.user, mineIdOverride: req.query.mine_id });
    res.json({ status: "ok", data });
  } catch (error) {
    next(error);
  }
}

async function mineDetail(req, res, next) {
  try {
    const data = await getMineDetail(req.params.mineId);
    res.json({ status: "ok", data });
  } catch (error) {
    next(error);
  }
}

module.exports = { overview, mineDetail };
