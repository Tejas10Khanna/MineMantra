const {
  generateReportPdf
} = require("../services/reports/reportGenerator");

async function generateReport(req, res) {
  try {
    const {
      reportCode,
      mineId,
      date,
      periodStart,
      year
    } = req.body;

    if (!reportCode) {
      return res.status(400).json({
        status: "error",
        message: "reportCode is required"
      });
    }

    const result = await generateReportPdf({
      reportCode,
      mineId,
      date,
      periodStart,
      year
    });

    res.json({
      status: "success",
      report: result.report,
      narrative: result.narrative,
      pdf: {
        filename: result.filename,
        download_url:
          `/api/reports/download/${encodeURIComponent(result.filename)}`
      }
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      status: "error",
      message: error.message
    });
  }
}

module.exports = {
  generateReport
};