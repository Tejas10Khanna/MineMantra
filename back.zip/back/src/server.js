require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

const { connectDB } = require("./config/db");

const reportsRouter = require("./routes/reports");
const dashboardRouter = require("./routes/dashboard.routes");
const alertsRouter = require("./routes/alerts.routes");
const remindersRouter = require("./routes/reminders.routes");
const escalationsRouter = require("./routes/escalations.routes");

app.use("/api/dashboard", dashboardRouter);
app.use("/api/alerts", alertsRouter);
app.use("/api/reminders", remindersRouter);
app.use("/api/escalations", escalationsRouter);
const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(morgan("dev"));

app.use("/api/reports", reportsRouter);

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    message: "CCL Smart Governance Backend is running"
  });
});

app.get("/api/db-health", async (req, res) => {
  try {
    const db = await connectDB();

    await db.command({
      ping: 1
    });

    res.json({
      status: "ok",
      database: process.env.MONGODB_DB,
      mongodb: "connected"
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      status: "error",
      mongodb: "connection failed",
      message: error.message
    });
  }
});

const PORT =
  process.env.PORT || 5000;

async function startServer() {
  try {
    await connectDB();

    app.listen(PORT, () => {
      console.log(
        `Backend running on http://localhost:${PORT}`
      );
    });

  } catch (error) {
    console.error(
      "Server startup failed:"
    );

    console.error(error);

    process.exit(1);
  }
}

startServer();