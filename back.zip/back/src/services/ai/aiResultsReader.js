/**
 * Reads AI model outputs from `analytics_results` (written by the Python
 * pipelines in scripts/ai_pipeline/). This file does NOT run any models --
 * Node never calls Python directly; the two sides only communicate through
 * MongoDB, matching how build_risk_features.py / ingest_prototype_data.py
 * already do things in this project (Python owns the ML, Node owns the API).
 */
const { getDB } = require("../../config/db");

async function getLatestRiskScores({ mineId } = {}) {
  const db = getDB();
  const match = { model_type: "risk_score" };
  if (mineId) match.mine_id = mineId;

  // one latest doc per mine
  return db.collection("analytics_results").aggregate([
    { $match: match },
    { $sort: { generated_at: -1 } },
    { $group: { _id: "$mine_id", latest: { $first: "$$ROOT" } } },
    { $replaceRoot: { newRoot: "$latest" } },
    { $sort: { score_or_label: -1 } },
  ]).toArray();
}

async function getRecentAnomalies({ mineId, days = 7, limit = 50 } = {}) {
  const db = getDB();
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const match = { model_type: "production_anomaly", generated_at: { $gte: since } };
  if (mineId) match.mine_id = mineId;

  return db.collection("analytics_results")
    .find(match)
    .sort({ generated_at: -1 })
    .limit(limit)
    .toArray();
}

async function getRecentGrievances({ mineId, limit = 50, status } = {}) {
  const db = getDB();
  const match = {};
  if (mineId) match.mine_id = mineId;
  if (status) match.status = status;

  return db.collection("grievances")
    .find(match)
    .sort({ triaged_at: -1, created_at: -1 })
    .limit(limit)
    .toArray();
}

module.exports = { getLatestRiskScores, getRecentAnomalies, getRecentGrievances };
