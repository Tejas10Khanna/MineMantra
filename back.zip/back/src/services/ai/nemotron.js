async function callNemotron(messages, maxTokens = 2000) {
  const response = await fetch(
    "https://integrate.api.nvidia.com/v1/chat/completions",
    {
      method: "POST",

      headers: {
        "Authorization": `Bearer ${process.env.NVIDIA_API_KEY}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },

      body: JSON.stringify({
        model: "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",
        messages,
        max_tokens: maxTokens,
        temperature: 0.2
      })
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      `NVIDIA API ${response.status}: ${
        data?.error?.message ||
        JSON.stringify(data)
      }`
    );
  }

  return data;
}


async function testNemotron() {
  const data = await callNemotron([
    {
      role: "user",
      content:
        "Reply with exactly: Nemotron connection successful."
    }
  ], 100);

  return data.choices?.[0]?.message?.content || "";
}


async function generateNarrative(reportData) {

  const systemPrompt = `
You are the narrative generation layer of an Indian coal-mine
governance reporting system.

Your ONLY job is to convert validated report metrics into
professional management-report narrative.

STRICT RULES:

1. Never invent numbers.
2. Never modify supplied numbers.
3. Never calculate alternative numbers.
4. Never invent causes for production changes or anomalies.
5. Never invent regulatory requirements.
6. Never claim compliance unless the supplied data establishes it.
7. Never invent recommendations.
8. If information is unavailable, explicitly state that it is unavailable.
9. Use only the supplied report data.
10. Keep the language concise and suitable for an official coal-mine report.

Return JSON with exactly:

{
  "executive_summary": "string",
  "key_observations": ["string"],
  "data_limitations": ["string"]
}
`;

  const userPrompt = `
Generate the narrative for the following validated report.

VALIDATED REPORT DATA:

${JSON.stringify(reportData, null, 2)}
`;

  const data = await callNemotron([
    {
      role: "system",
      content: systemPrompt
    },
    {
      role: "user",
      content: userPrompt
    }
  ], 2000);

  return {
    enabled: true,
    narrative:
      data.choices?.[0]?.message?.content || ""
  };
}


module.exports = {
  testNemotron,
  generateNarrative
};