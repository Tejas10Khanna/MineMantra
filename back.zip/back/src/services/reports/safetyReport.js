const { getDB } = require("../../config/db");

const {
  startOfMonth,
  endOfMonth,
  countDocuments,
  groupedCount,
  sumField,
  percentage
} = require("./reportUtils");

async function generateSafetyMonthly({
  mineId,
  periodStart
}) {
  const db = getDB();

  const start = startOfMonth(periodStart);
  const end = endOfMonth(periodStart);

  const mine = mineId ? { mine_id: mineId } : {};

  const accidentFilter = {
    ...mine,
    event_datetime: {
      $gte: start,
      $lte: end
    }
  };

  const fatalAccidents = await countDocuments(
    db,
    "accidents",
    {
      ...accidentFilter,
      event_class: "fatal_accident"
    }
  );

  const fatalities = await sumField(
    db,
    "accidents",
    "fatalities",
    accidentFilter
  );

  const seriousAccidents = await countDocuments(
    db,
    "accidents",
    {
      ...accidentFilter,
      event_class: "serious_accident"
    }
  );

  const nearMisses = await countDocuments(
    db,
    "near_misses",
    {
      ...mine,
      event_datetime: {
        $gte: start,
        $lte: end
      }
    }
  );

  const inspections = await countDocuments(
    db,
    "inspections",
    {
      ...mine,
      inspection_date: {
        $gte: start,
        $lte: end
      }
    }
  );

  const trainedWorkers = await countDocuments(
    db,
    "worker_training",
    {
      ...mine,
      completion_status: "completed",
      completion_date: {
        $gte: start,
        $lte: end
      }
    }
  );

  const toolboxTalks = await countDocuments(
    db,
    "safety_program_activities",
    {
      ...mine,
      activity_type: "toolbox_talk",
      activity_date: {
        $gte: start,
        $lte: end
      }
    }
  );

  const mockDrills = await countDocuments(
    db,
    "safety_program_activities",
    {
      ...mine,
      activity_type: "mock_drill",
      activity_date: {
        $gte: start,
        $lte: end
      }
    }
  );

  const ppeViolations = await countDocuments(
    db,
    "analytics_results",
    {
      ...mine,
      model_type: "ppe",
      generated_at: {
        $gte: start,
        $lte: end
      }
    }
  );

  const cctvEvents = await countDocuments(
    db,
    "cctv_events",
    {
      ...mine,
      detected_at: {
        $gte: start,
        $lte: end
      }
    }
  );

  const sensorAlerts = await countDocuments(
    db,
    "alerts",
    {
      ...mine,
      created_at: {
        $gte: start,
        $lte: end
      },
      category: "safety"
    }
  );

  return {
    report_code: "SAFETY_MONTHLY",

    status:
      fatalAccidents ||
      seriousAccidents ||
      nearMisses ||
      inspections ||
      trainedWorkers
        ? "READY"
        : "NO_DATA",

    reporting_period: {
      start,
      end
    },

    scope: {
      mine_id: mineId || "all_mines"
    },

    metrics: {
      fatal_accidents: fatalAccidents,
      fatalities,
      serious_accidents: seriousAccidents,
      near_misses: nearMisses,

      mine_inspections: inspections,

      workers_trained: trainedWorkers,

      toolbox_talks: toolboxTalks,
      mock_drills: mockDrills,

      ppe_violations: ppeViolations,
      cctv_safety_events: cctvEvents,
      critical_sensor_alerts: sensorAlerts,

      training_coverage_pct: null
    }
  };
}

module.exports = { generateSafetyMonthly };