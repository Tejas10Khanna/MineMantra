const { getDB } = require("../../config/db");

const {
  startOfMonth,
  endOfMonth,
  percentage,
  countDocuments,
  groupedCount
} = require("./reportUtils");

async function generateComplianceReport({
  mineId,
  periodStart
}) {
  const db = getDB();

  const start = startOfMonth(periodStart);
  const end = endOfMonth(periodStart);

  const mine = mineId ? { mine_id: mineId } : {};

  const occurrenceFilter = {
    ...mine,
    $or: [
      {
        reporting_period_start: { $gte: start, $lte: end }
      },
      {
        due_date: { $gte: start, $lte: end }
      }
    ]
  };

  const dueRequirements =
    await countDocuments(
      db,
      "compliance_occurrences",
      occurrenceFilter
    );

  const compliant =
    await countDocuments(
      db,
      "compliance_occurrences",
      {
        ...occurrenceFilter,
        status: { $in: ["compliant", "verified"] }
      }
    );

  const completed =
    await countDocuments(
      db,
      "compliance_occurrences",
      {
        ...occurrenceFilter,
        status: {
          $in: [
            "compliant",
            "verified",
            "partially_compliant"
          ]
        }
      }
    );

  const partial =
    await countDocuments(
      db,
      "compliance_occurrences",
      {
        ...occurrenceFilter,
        status: "partially_compliant"
      }
    );

  const nonCompliant =
    await countDocuments(
      db,
      "compliance_occurrences",
      {
        ...occurrenceFilter,
        status: "non_compliant"
      }
    );

  const overdue =
    await countDocuments(
      db,
      "compliance_occurrences",
      {
        ...occurrenceFilter,
        status: "overdue"
      }
    );

  const applicableRequirements =
    await countDocuments(
      db,
      "mine_compliance_conditions",
      {
        ...mine,
        status: { $nin: ["closed", "inactive"] }
      }
    );

  const violations =
    await groupedCount(
      db,
      "compliance_violations",
      "category",
      {
        ...mine,
        detected_at: { $gte: start, $lte: end }
      }
    );

  const openActions =
    await countDocuments(
      db,
      "corrective_actions",
      {
        ...mine,
        status: { $nin: ["closed", "verified"] }
      }
    );

  const overdueActions =
    await countDocuments(
      db,
      "corrective_actions",
      {
        ...mine,
        due_date: { $lt: end },
        status: { $nin: ["closed", "verified"] }
      }
    );

  return {
    report_code: "COMPLIANCE",
    status: dueRequirements || applicableRequirements
      ? "READY"
      : "NO_DATA",

    reporting_period: {
      start,
      end
    },

    scope: {
      mine_id: mineId || "all_mines"
    },

    metrics: {
      applicable_requirements: applicableRequirements,
      due_requirements: dueRequirements,
      completed_requirements: completed,
      compliant_requirements: compliant,
      partially_compliant_requirements: partial,
      non_compliant_requirements: nonCompliant,
      overdue_requirements: overdue,

      compliance_score_pct:
        percentage(compliant, dueRequirements),

      violations_by_category: violations,

      open_corrective_actions: openActions,
      overdue_corrective_actions: overdueActions
    }
  };
}

module.exports = { generateComplianceReport };