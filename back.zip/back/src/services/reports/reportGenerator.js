const fs = require("fs");
const path = require("path");
const PDFDocument = require("pdfkit");
const crypto = require("crypto");

const {
  generateProductionDaily
} = require("./productionReport");

const {
  generateComplianceReport
} = require("./complianceReport");

const {
  generateSafetyMonthly
} = require("./safetyReport");

const {
  generateSustainabilityAnnual
} = require("./sustainabilityReport");

const {
  generateNarrative
} = require("../ai/nemotron");

function formatValue(value) {
  if (value === null || value === undefined) return "N/A";

  if (typeof value === "number") {
    return value.toLocaleString("en-IN");
  }

  if (typeof value === "object") {
    return JSON.stringify(value);
  }

  return String(value);
}

function writeMetricSection(doc, metrics) {
  doc.fontSize(12).text("Validated Metrics", {
    underline: true
  });

  doc.moveDown(0.5);

  for (const [key, value] of Object.entries(metrics)) {
    doc
      .fontSize(10)
      .text(`${key}: ${formatValue(value)}`);

    doc.moveDown(0.15);
  }
}

function writeNarrative(doc, narrative) {
  doc.moveDown();

  doc.fontSize(12).text("Executive Summary", {
    underline: true
  });

  doc.moveDown(0.5);

  doc.fontSize(10).text(
    narrative?.narrative || narrative?.executive_summary || ""
  );

  doc.moveDown();
}

async function calculateReport(params) {
  switch (params.reportCode) {
    case "PRODUCTION_DAILY":
      return generateProductionDaily(params);

    case "COMPLIANCE":
      return generateComplianceReport(params);

    case "SAFETY_MONTHLY":
      return generateSafetyMonthly(params);

    case "SUSTAINABILITY_ANNUAL":
      return generateSustainabilityAnnual(params);

    default:
      throw new Error(`Unknown report code: ${params.reportCode}`);
  }
}

async function generateReportPdf(params) {
  const report = await calculateReport(params);

  const narrative = await generateNarrative(report);

  const outputDir = path.join(process.cwd(), "reports", "generated");

  fs.mkdirSync(outputDir, {
    recursive: true
  });

  const id = crypto.randomUUID();

  const filename =
    `${report.report_code}_${id}.pdf`;

  const outputPath =
    path.join(outputDir, filename);

  const doc = new PDFDocument({
    margin: 50
  });

  const stream = fs.createWriteStream(outputPath);

  doc.pipe(stream);

  doc.fontSize(20).text(
    "CCL Smart Governance Platform",
    { align: "center" }
  );

  doc.moveDown(0.5);

  doc.fontSize(16).text(
    report.report_code,
    { align: "center" }
  );

  doc.moveDown();

  doc.fontSize(10).text(
    `Status: ${report.status}`
  );

  doc.text(
    `Scope: ${report.scope?.mine_id || "all_mines"}`
  );

  doc.text(
    `Generated: ${new Date().toISOString()}`
  );

  doc.moveDown();

  writeNarrative(doc, narrative);

  writeMetricSection(
    doc,
    report.metrics
  );

  doc.moveDown();

  doc.fontSize(9).text(
    "Generated from validated database metrics. AI is used only for narrative generation."
  );

  doc.end();

  await new Promise((resolve, reject) => {
    stream.on("finish", resolve);
    stream.on("error", reject);
  });

  return {
    report,
    narrative,
    filename,
    path: outputPath
  };
}

module.exports = {
  generateReportPdf
};