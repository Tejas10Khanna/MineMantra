const { getDB } = require("../../config/db");

const {
  startOfYear,
  endOfYear,
  percentage,
  sumField,
  countDocuments,
  groupedSum
} = require("./reportUtils");

async function generateSustainabilityAnnual({
  mineId,
  year
}) {
  const db = getDB();

  const start = startOfYear(`${year}-01-01`);
  const end = endOfYear(`${year}-01-01`);

  const mine = mineId ? { mine_id: mineId } : {};

  const dateFilter = {
    ...mine,
    period_start: { $gte: start, $lte: end }
  };

  const electricity = await sumField(
    db,
    "energy_records",
    "quantity",
    {
      ...dateFilter,
      energy_type: "electricity_purchased"
    }
  );

  const renewableGeneration = await sumField(
    db,
    "energy_records",
    "quantity",
    {
      ...dateFilter,
      energy_type: "renewable_generation"
    }
  );

  const fuel = await sumField(
    db,
    "fuel_consumption_records",
    "quantity",
    dateFilter
  );

  const emissions = await sumField(
    db,
    "emissions_records",
    "quantity",
    dateFilter
  );

  const waterWithdrawal = await sumField(
    db,
    "water_resource_records",
    "withdrawal_kl",
    dateFilter
  );

  const waterConsumption = await sumField(
    db,
    "water_resource_records",
    "consumption_kl",
    dateFilter
  );

  const waterDischarge = await sumField(
    db,
    "water_resource_records",
    "discharge_kl",
    dateFilter
  );

  const surplusMineWater = await sumField(
    db,
    "water_resource_records",
    "surplus_mine_water_supplied_kl",
    dateFilter
  );

  const beneficiaries = await sumField(
    db,
    "water_resource_records",
    "community_beneficiaries",
    dateFilter
  );

  const plantationTarget = await sumField(
    db,
    "plantation_records",
    "target_area_ha",
    dateFilter
  );

  const plantationAchieved = await sumField(
    db,
    "plantation_records",
    "achieved_area_ha",
    dateFilter
  );

  const saplings = await sumField(
    db,
    "plantation_records",
    "saplings_planted",
    dateFilter
  );

  const technicalReclamation = await sumField(
    db,
    "reclamation_records",
    "technically_reclaimed_area_ha",
    dateFilter
  );

  const biologicalReclamation = await sumField(
    db,
    "reclamation_records",
    "biologically_reclaimed_area_ha",
    dateFilter
  );

  const disturbedLand = await sumField(
    db,
    "reclamation_records",
    "disturbed_area_ha",
    dateFilter
  );

  const biodiversityActions = await countDocuments(
    db,
    "biodiversity_records",
    dateFilter
  );

  const renewableProjects = await countDocuments(
    db,
    "renewable_energy_projects",
    mine
  );

  const csrSpend = await sumField(
    db,
    "csr_expenditure",
    "amount_crore",
    dateFilter
  );

  const csrBeneficiaries = await sumField(
    db,
    "csr_expenditure",
    "beneficiaries_count",
    dateFilter
  );

  const csrBySector = await groupedSum(
    db,
    "csr_expenditure",
    "amount_crore",
    "sector",
    dateFilter
  );

  const ecoParks = await countDocuments(
    db,
    "eco_parks",
    mine
  );

  const ecoParkArea = await sumField(
    db,
    "eco_parks",
    "area_ha",
    mine
  );

  const sustainabilityProjects = await countDocuments(
    db,
    "sustainability_projects",
    mine
  );

  return {
    report_code: "SUSTAINABILITY_ANNUAL",

    status:
      electricity ||
      renewableGeneration ||
      waterWithdrawal ||
      plantationAchieved ||
      csrSpend
        ? "READY"
        : "NO_DATA",

    reporting_period: {
      start,
      end
    },

    scope: {
      mine_id: mineId || "all_mines"
    },

    metrics: {
      electricity_consumption: electricity,
      renewable_generation: renewableGeneration,
      fuel_consumption: fuel,
      ghg_emissions: emissions,

      water_withdrawal_kl: waterWithdrawal,
      water_consumption_kl: waterConsumption,
      water_discharge_kl: waterDischarge,
      surplus_mine_water_supplied_kl: surplusMineWater,
      community_water_beneficiaries: beneficiaries,

      disturbed_land_ha: disturbedLand,
      technical_reclamation_ha: technicalReclamation,
      biological_reclamation_ha: biologicalReclamation,

      plantation_target_ha: plantationTarget,
      plantation_achieved_ha: plantationAchieved,
      plantation_achievement_pct:
        percentage(plantationAchieved, plantationTarget),

      saplings_planted: saplings,

      biodiversity_actions: biodiversityActions,

      renewable_projects: renewableProjects,

      eco_parks_count: ecoParks,
      eco_parks_area_ha: ecoParkArea,

      sustainability_projects_count: sustainabilityProjects,

      csr_spend_crore: csrSpend,
      csr_beneficiaries: csrBeneficiaries,
      csr_spend_by_sector: csrBySector
    }
  };
}

module.exports = { generateSustainabilityAnnual };
