const { ObjectId } = require("mongodb");

function startOfDay(dateString) {
  return new Date(`${dateString}T00:00:00.000Z`);
}

function endOfDay(dateString) {
  return new Date(`${dateString}T23:59:59.999Z`);
}

function startOfMonth(dateString) {
  const d = new Date(`${dateString}T00:00:00.000Z`);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
}

function endOfMonth(dateString) {
  const d = new Date(`${dateString}T00:00:00.000Z`);
  return new Date(
    Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0, 23, 59, 59, 999)
  );
}

function startOfYear(dateString) {
  const d = new Date(`${dateString}T00:00:00.000Z`);
  return new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
}

function endOfYear(dateString) {
  const d = new Date(`${dateString}T00:00:00.000Z`);
  return new Date(Date.UTC(d.getUTCFullYear(), 11, 31, 23, 59, 59, 999));
}

function numberOrZero(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function percentage(numerator, denominator) {
  if (!denominator) return null;
  return Number(((numerator / denominator) * 100).toFixed(2));
}

function growthPercent(current, previous) {
  if (!previous) return null;
  return Number((((current - previous) / previous) * 100).toFixed(2));
}

function mineFilter(mineId) {
  return mineId ? { mine_id: mineId } : {};
}

async function collectionHasData(db, collectionName, filter = {}) {
  return (await db.collection(collectionName).countDocuments(filter, { limit: 1 })) > 0;
}

async function sumField(db, collectionName, field, filter = {}) {
  const result = await db.collection(collectionName).aggregate([
    { $match: filter },
    {
      $group: {
        _id: null,
        total: { $sum: { $ifNull: [`$${field}`, 0] } }
      }
    }
  ]).toArray();

  return result[0]?.total ?? 0;
}

async function countDocuments(db, collectionName, filter = {}) {
  return db.collection(collectionName).countDocuments(filter);
}

async function groupedSum(db, collectionName, valueField, groupField, filter = {}) {
  const result = await db.collection(collectionName).aggregate([
    { $match: filter },
    {
      $group: {
        _id: `$${groupField}`,
        total: { $sum: { $ifNull: [`$${valueField}`, 0] } }
      }
    },
    { $sort: { total: -1 } }
  ]).toArray();

  return result.map((x) => ({
    group: x._id ?? "unknown",
    total: x.total
  }));
}

async function groupedCount(db, collectionName, groupField, filter = {}) {
  const result = await db.collection(collectionName).aggregate([
    { $match: filter },
    {
      $group: {
        _id: `$${groupField}`,
        count: { $sum: 1 }
      }
    },
    { $sort: { count: -1 } }
  ]).toArray();

  return result.map((x) => ({
    group: x._id ?? "unknown",
    count: x.count
  }));
}

module.exports = {
  startOfDay,
  endOfDay,
  startOfMonth,
  endOfMonth,
  startOfYear,
  endOfYear,
  numberOrZero,
  percentage,
  growthPercent,
  mineFilter,
  collectionHasData,
  sumField,
  countDocuments,
  groupedSum,
  groupedCount
};