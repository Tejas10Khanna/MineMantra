const { getDB } = require("../../config/db");

const {
  startOfDay,
  endOfDay,
  numberOrZero,
  percentage,
  growthPercent,
  sumField,
  groupedSum
} = require("./reportUtils");

async function generateProductionDaily({ mineId, date }) {
  const db = getDB();

  const start = startOfDay(date);
  const end = endOfDay(date);

  const baseFilter = {
    date: { $gte: start, $lte: end }
  };

  if (mineId) baseFilter.mine_id = mineId;

  const production = db.collection("production_model_inputs");

  const records = await production.find(baseFilter).sort({ date: 1 }).toArray();

  const ocProduction = records
    .filter((r) => r.mine_type === "Opencast")
    .reduce((sum, r) => sum + numberOrZero(r.production_tonnes), 0);

  const ugProduction = records
    .filter((r) => r.mine_type === "Underground")
    .reduce((sum, r) => sum + numberOrZero(r.production_tonnes), 0);

  const totalProduction = ocProduction + ugProduction;

  const dispatchTotal = records.reduce(
    (sum, r) => sum + numberOrZero(r.dispatch_tonnes),
    0
  );

  const downtime = records.reduce(
    (sum, r) => sum + numberOrZero(r.equipment_downtime_hours),
    0
  );

  const equipmentCounts = records.reduce(
    (sum, r) => sum + numberOrZero(r.active_equipment_count),
    0
  );

  const anomalies = records.filter((r) => r.is_anomaly_true === true);

  const anomalyTypes = {};
  for (const record of anomalies) {
    const type = record.anomaly_type_true || "unknown";
    anomalyTypes[type] = (anomalyTypes[type] || 0) + 1;
  }

  const previousDate = new Date(start);
  previousDate.setUTCDate(previousDate.getUTCDate() - 1);

  const previousEnd = new Date(end);
  previousEnd.setUTCDate(previousEnd.getUTCDate() - 1);

  const previousRecords = await production.find({
    ...(
      mineId
        ? { mine_id: mineId }
        : {}
    ),
    date: { $gte: previousDate, $lte: previousEnd }
  }).toArray();

  const previousProduction = previousRecords.reduce(
    (sum, r) => sum + numberOrZero(r.production_tonnes),
    0
  );

  return {
    report_code: "PRODUCTION_DAILY",
    status: records.length ? "READY" : "NO_DATA",
    reporting_period: {
      start: start,
      end: end
    },
    scope: {
      mine_id: mineId || "all_mines"
    },
    metrics: {
      production_oc_tonnes: Number(ocProduction.toFixed(2)),
      production_ug_tonnes: Number(ugProduction.toFixed(2)),
      production_total_tonnes: Number(totalProduction.toFixed(2)),

      target_total_tonnes: null,
      achievement_pct: null,

      growth_vs_previous_period_pct: growthPercent(
        totalProduction,
        previousProduction
      ),

      dispatch_total_tonnes: Number(dispatchTotal.toFixed(2)),

      downtime_hours: Number(downtime.toFixed(2)),
      active_equipment_count: equipmentCounts,

      production_anomalies: anomalies.length,

      anomaly_types: anomalyTypes
    },

    source: {
      collection: "production_model_inputs",
      records_used: records.length
    }
  };
}

module.exports = { generateProductionDaily };