"""
CCL Smart Governance Platform — FULL synthetic database generator

Purpose
-------
Populate the complete application database with internally-consistent DEMO data.
This version is deliberately broader than the previous report-only generator:
- populates every collection declared by initializeDatabase_v2.js
- preserves the existing production_model_inputs and risk_training_samples datasets
- creates linked master, operational, compliance, safety, environment, IoT,
  governance, reporting, audit and AI records
- fills report-source collections used by all four report generators
- is safe to re-run: only documents marked synthetic_demo=True are replaced

IMPORTANT
---------
All generated regulatory/legal values are DEMO placeholders, not legal truth.
Do not present synthetic thresholds, permits, clauses or compliance results as
real statutory requirements.

Usage (Windows CMD)
-------------------
python generate_synthetic_data_full.py --days 180
python generate_synthetic_data_full.py --days 365
python generate_synthetic_data_full.py --days 365 --clear-synthetic
python generate_synthetic_data_full.py --csv-dir synthetic_export --days 30
"""

import argparse, csv, hashlib, os, random, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

random.seed(42)

MINES = [
    {"mine_id":"TAL-OC-01","name":"Talcher Opencast","type":"OC","area_id":"AREA-TAL","coalfield_id":"CF-MCL","state":"Odisha","district":"Angul","latitude":20.94,"longitude":85.10},
    {"mine_id":"KOR-UG-02","name":"Korba Underground","type":"UG","area_id":"AREA-KOR","coalfield_id":"CF-SECL","state":"Chhattisgarh","district":"Korba","latitude":22.36,"longitude":82.68},
    {"mine_id":"JHR-OC-03","name":"Jharia Opencast","type":"OC","area_id":"AREA-JHR","coalfield_id":"CF-BCCL","state":"Jharkhand","district":"Dhanbad","latitude":23.80,"longitude":86.43},
    {"mine_id":"SEC-OC-04","name":"Sohagpur Opencast","type":"OC","area_id":"AREA-SEC","coalfield_id":"CF-SECL","state":"Madhya Pradesh","district":"Shahdol","latitude":23.30,"longitude":81.36},
    {"mine_id":"SIN-UG-05","name":"Singrauli Underground","type":"UG","area_id":"AREA-SIN","coalfield_id":"CF-SING","state":"Madhya Pradesh","district":"Singrauli","latitude":24.20,"longitude":82.68},
]

ROLES=["Director (Technical)","Area GM","AGM","Project Manager","Manager","Assistant Manager","Overman","Safety Officer","Surveyor","Ventilation Officer","E&M Engineer","Mine Sardar","Environmental Officer","Medical Officer","HR Officer"]
DEPTS=["operations","safety","survey","ventilation","electrical_mechanical","environment","medical","hr"]
EQUIPMENT=["HEMM-Dumper","HEMM-Excavator","Shovel","Dozer","Drill","Loader","Continuous Miner","LHD","SDL","Pump"]
STATUSES=["open","in_progress","closed","verified"]

COLLECTIONS=[
"users","roles","departments","contractors","coalfields","areas","mines","mine_zones","mine_boundaries",
"regulatory_authorities","regulations","regulation_versions","compliance_requirements","mine_compliance_conditions","compliance_occurrences","compliance_measurements","compliance_violations","audit_findings","regulatory_deadlines","regulatory_notices","legal_cases","regulatory_reports","report_submissions",
"mining_leases","mining_plans","mine_closure_plans","mine_closure_progress","mine_closure_escrow","environmental_clearances","forest_clearances","wildlife_clearances","water_permissions","pollution_consents","explosives_licences","electrical_approvals",
"workers","worker_training","worker_certifications","medical_fitness","ppe_records","attendance","shifts","statutory_manpower_snapshots","statutory_manpower_requirements",
"compliance_records","inspections","inspection_templates","inspection_checklists","reports","safety_observations","near_misses","incidents","accidents","hazards","corrective_actions","safety_exposure_records","safety_program_activities","rescue_readiness_records","safety_alerts",
"production_target_records","production_records","dispatch_records","washeries","washery_operations","stockpile_records","equipment","equipment_maintenance","equipment_inspections","equipment_faults","equipment_telemetry","equipment_daily_performance","mine_capacity_records","downtime_records","blasting_records","drilling_records","wagon_loading_records","eauction_records","coal_quality_records",
"air_quality","water_quality","groundwater","noise_monitoring","soil_monitoring","weather","environmental_samples","water_resource_records","energy_records","fuel_consumption_records","emissions_records","waste_records","land_use","forest_monitoring","vegetation_monitoring","plantation_records","reclamation_records","biodiversity_records","satellite_observations","renewable_energy_projects","sustainability_projects","eco_parks",
"csr_projects","csr_expenditure","social_metrics","sensors","sensor_readings","cameras","cctv_events","documents","evidence","audit_log","blockchain_records",
"report_definitions","report_metric_contracts","report_instances","report_artifacts","metric_snapshots","data_quality_checks","data_quality_issues","grievances","alerts","reminders","escalations","ai_models","analytics_results"
]


def now(): return datetime.now(timezone.utc)
def dt(days_ago=0, hour=None):
    d=now()-timedelta(days=days_ago)
    return d.replace(hour=(hour if hour is not None else d.hour),minute=0,second=0,microsecond=0)
def pick(xs): return random.choice(xs)
def uid(prefix): return f"{prefix}-{uuid.uuid4().hex[:10].upper()}"
def n(a,b): return random.randint(a,b)
def f(a,b): return round(random.uniform(a,b),3)
def mine_ids(): return [m["mine_id"] for m in MINES]
def common(mine=None):
    d={"synthetic_demo":True,"source":"synthetic_full_generator","generated_at":now()}
    if mine: d.update({"mine_id":mine["mine_id"],"area_id":mine["area_id"],"coalfield_id":mine["coalfield_id"]})
    return d

def gen_master(days):
    D={}
    D["coalfields"]=[{"coalfield_id":m["coalfield_id"],"name":m["coalfield_id"].replace("CF-","")+" Coalfield","state":m["state"],"status":"active",**common()} for m in MINES]
    D["areas"]=[{"area_id":m["area_id"],"name":m["name"].split()[0]+" Area","coalfield_id":m["coalfield_id"],"general_manager":"AGM-AREA-01","status":"active",**common(m)} for m in MINES]
    D["mines"]=[{**m,"status":"operational","opening_year":random.choice([1988,1997,2004,2011,2018]),"geo":{"type":"Point","coordinates":[m["longitude"],m["latitude"]]},"lease_area_ha":f(450,3200),"rated_capacity_mtpA":f(0.8,6.5),**common(m)} for m in MINES]
    D["mine_zones"]=[{"zone_id":f"{m['mine_id']}-Z-{z}","mine_id":m["mine_id"],"name":f"Zone-{z}","zone_type":pick(["production","dump","workshop","stockyard","sensitive"]),"status":"active",**common(m)} for m in MINES for z in range(1,4)]
    D["mine_boundaries"]=[{"mine_id":m["mine_id"],"boundary_id":f"BND-{m['mine_id']}","geometry":{"type":"Polygon","coordinates":[[[m["longitude"],m["latitude"]],[m["longitude"]+0.02,m["latitude"]],[m["longitude"]+0.02,m["latitude"]+0.02],[m["longitude"],m["latitude"]+0.02],[m["longitude"],m["latitude"]]]]},"area_ha":f(500,3000),"survey_date":dt(20),**common(m)} for m in MINES]
    D["departments"]=[{"department_id":f"DEPT-{x.upper()}","name":x.replace("_"," ").title(),"head_role":pick(ROLES),"status":"active",**common()} for x in DEPTS]
    D["roles"]=[{"role_id":f"ROLE-{i:02d}","name":r,"department":pick(DEPTS),"access_level":i+1,"status":"active",**common()} for i,r in enumerate(ROLES)]
    D["contractors"]=[{"contractor_id":f"CONT-{i:03d}","name":f"Demo Mining Services {i:03d}","category":pick(["HEMM","drilling","civil","transport","electrical"]),"mine_ids":mine_ids(),"contract_start":dt(180),"contract_end":dt(-180),"safety_rating":f(70,98),"status":"active",**common()} for i in range(1,11)]
    D["users"]=[]
    for m in MINES:
        for i,r in enumerate(ROLES): D["users"].append({"employee_id":f"{m['mine_id']}-EMP-{i:03d}","name":f"{r} - {m['name']}","role":r,"department":pick(DEPTS),"mine_id":m["mine_id"],"area_id":m["area_id"],"coalfield_id":m["coalfield_id"],"phone_masked":"+91-XXXXXX","status":"active",**common(m)})
    return D

def gen_regulatory(days):
    D={}
    auth=[{"authority_id":"AUTH-DGMS","name":"DGMS","authority_type":"safety_regulator","jurisdiction":"coal mines","status":"active"},{"authority_id":"AUTH-CPCB","name":"CPCB","authority_type":"environment","jurisdiction":"pollution control","status":"active"},{"authority_id":"AUTH-SPCB","name":"State Pollution Control Board","authority_type":"environment","jurisdiction":"state","status":"active"},{"authority_id":"AUTH-MOEF","name":"MoEFCC","authority_type":"environment","jurisdiction":"environment and forest","status":"active"}]
    D["regulatory_authorities"]=[{**x,**common()} for x in auth]
    D["regulations"]=[]; D["regulation_versions"]=[]; D["compliance_requirements"]=[]
    cats=["safety","environment","production","labour"]
    for i,cat in enumerate(cats):
        for j in range(4):
            rid=f"REG-DEMO-{cat.upper()}-{j:02d}"; qid=f"REQ-DEMO-{cat.upper()}-{j:02d}"
            D["regulations"].append({"regulation_id":rid,"name":f"DEMO {cat.title()} Control {j+1}","authority_id":pick([a["authority_id"] for a in auth]),"status":"demo_reference","source_note":"Synthetic placeholder — replace with verified source text",**common()})
            D["regulation_versions"].append({"regulation_id":rid,"version":"DEMO-1.0","effective_from":dt(365),"effective_to":None,"source_document":"synthetic_placeholder","citation":"DEMO ONLY",**common()})
            D["compliance_requirements"].append({"requirement_code":qid,"category":cat,"requirement_text":f"DEMO {cat} requirement {j+1}; verify against official source","severity":pick(["low","medium","high"]),"frequency":pick(["daily","monthly","quarterly","annual"]),"responsible_role":pick(ROLES),"evidence_types":["inspection","measurement","document"],"regulation_id":rid,**common()})
    D["mine_compliance_conditions"]=[]; D["compliance_occurrences"]=[]; D["compliance_measurements"]=[]; D["compliance_violations"]=[]; D["audit_findings"]=[]; D["regulatory_deadlines"]=[]; D["regulatory_notices"]=[]; D["legal_cases"]=[]; D["regulatory_reports"]=[]; D["report_submissions"]=[]
    req=D["compliance_requirements"]
    for m in MINES:
        for q in req:
            status=pick(["compliant","verified","partially_compliant","non_compliant","overdue"])
            D["mine_compliance_conditions"].append({"condition_id":uid("COND"),"mine_id":m["mine_id"],"compliance_requirement_id":q["requirement_code"],"status":status,"effective_from":dt(300),"last_verified_at":dt(n(1,30)),"evidence_required":True,**common(m)})
            for k in range(3):
                end=dt(k*30); start=end-timedelta(days=30); due=end+timedelta(days=7)
                D["compliance_occurrences"].append({"occurrence_id":uid("OCC"),"requirement_id":q["requirement_code"],"mine_id":m["mine_id"],"reporting_period_start":start,"reporting_period_end":end,"due_date":due,"status":status,"completion_date":end-timedelta(days=n(0,5)) if status in ("compliant","verified") else None,"verified_by":pick(ROLES),**common(m)})
            D["compliance_measurements"].append({"measurement_id":uid("MEAS"),"mine_id":m["mine_id"],"measurement_date":dt(n(0,days)),"requirement_id":q["requirement_code"],"observed_value":f(60,100),"unit":"percent","pass_fail":pick(["pass","pass","fail","unknown"]),"method":"synthetic measurement",**common(m)})
        for i in range(n(4,9)):
            vid=f"{m['mine_id']}-VIO-{i:03d}"; status=pick(["open","open","closed"]); detected=dt(n(1,days))
            D["compliance_violations"].append({"violation_id":vid,"mine_id":m["mine_id"],"detected_at":detected,"category":pick(cats),"severity":pick(["low","medium","high"]),"status":status,"description":"Synthetic governance finding for demo","source":"inspection","closed_at":detected+timedelta(days=n(2,20)) if status=="closed" else None,**common(m)})
            D["audit_findings"].append({"finding_id":uid("FIND"),"mine_id":m["mine_id"],"audit_date":detected,"severity":pick(["low","medium","high"]),"status":status,"description":"Synthetic audit finding","finding_category":pick(cats),**common(m)})
        D["regulatory_deadlines"] += [{"deadline_id":uid("DL"),"mine_id":m["mine_id"],"authority_id":pick([a["authority_id"] for a in auth]),"due_date":dt(-n(5,120)),"item_type":pick(["return","renewal","submission"]),"status":pick(["completed","pending","overdue"]),**common(m)}]
        D["regulatory_notices"] += [{"notice_id":uid("NOTICE"),"mine_id":m["mine_id"],"authority_id":"AUTH-DGMS","issued_at":dt(n(5,days)),"subject":"Synthetic compliance notice","severity":pick(["medium","high"]),"status":pick(["open","responded","closed"]),**common(m)}]
        D["legal_cases"] += [{"case_id":uid("CASE"),"mine_id":m["mine_id"],"authority":"Demo authority","opened_at":dt(n(30,days)),"case_type":"administrative","status":pick(["open","closed"]),"reference":"DEMO-CASE",**common(m)}]
        D["regulatory_reports"] += [{"regulatory_report_id":uid("REGREP"),"mine_id":m["mine_id"],"report_type":pick(["monthly_return","safety_return","environment_return"]),"period_start":dt(60),"period_end":dt(30),"status":"draft","prepared_by":"synthetic_engine",**common(m)}]
        D["report_submissions"] += [{"submission_id":uid("SUB"),"mine_id":m["mine_id"],"report_type":"synthetic_regulatory_return","submitted_at":dt(15),"authority_id":"AUTH-DGMS","acknowledgement":"DEMO-ACK","status":pick(["accepted","pending","rejected"]),**common(m)}]
    return D

def gen_approvals(days):
    D={k:[] for k in ["mining_leases","mining_plans","mine_closure_plans","mine_closure_progress","mine_closure_escrow","environmental_clearances","forest_clearances","wildlife_clearances","water_permissions","pollution_consents","explosives_licences","electrical_approvals"]}
    for m in MINES:
        D["mining_leases"].append({"lease_id":uid("LEASE"),"mine_id":m["mine_id"],"lease_number":f"DEMO-L-{m['mine_id']}","grant_date":dt(2000),"valid_to":dt(-3650),"area_ha":f(500,3000),"status":"active",**common(m)})
        D["mining_plans"].append({"plan_id":uid("PLAN"),"mine_id":m["mine_id"],"plan_version":"DEMO-2026","approval_date":dt(200),"valid_to":dt(-500),"status":"approved_demo","production_capacity_mtpA":f(1,6),"source_note":"Synthetic planning record",**common(m)})
        D["mine_closure_plans"].append({"closure_plan_id":uid("MCP"),"mine_id":m["mine_id"],"plan_version":"DEMO-1.0","planned_closure_year":2045,"closure_cost_crore":f(50,300),"status":"active_demo",**common(m)})
        D["mine_closure_progress"].append({"progress_id":uid("MCPROG"),"mine_id":m["mine_id"],"assessment_date":dt(30),"physical_progress_pct":f(15,70),"financial_progress_pct":f(10,65),"land_reclaimed_ha":f(10,100),"remarks":"Synthetic closure-progress record",**common(m)})
        D["mine_closure_escrow"].append({"escrow_id":uid("ESCROW"),"mine_id":m["mine_id"],"as_of_date":dt(15),"required_amount_crore":f(80,400),"deposited_amount_crore":f(70,380),"balance_crore":f(5,40),"status":"active_demo",**common(m)})
        for coll,typ in [("environmental_clearances","EC"),("forest_clearances","FC"),("wildlife_clearances","WL"),("water_permissions","WATER"),("pollution_consents","POLLUTION"),("explosives_licences","EXPLOSIVES"),("electrical_approvals","ELECTRICAL")]:
            D[coll].append({"approval_id":uid(typ),"mine_id":m["mine_id"],"approval_type":typ,"reference_number":f"DEMO-{typ}-{m['mine_id']}","issue_date":dt(500),"expiry_date":dt(-n(30,500)),"status":pick(["valid","valid","renewal_due","pending"]),"issuing_authority":pick(["Demo Authority","DGMS","SPCB","MoEFCC"]),**common(m)})
    return D

def gen_workforce(days):
    D={k:[] for k in ["workers","worker_training","worker_certifications","medical_fitness","ppe_records","attendance","shifts","statutory_manpower_snapshots","statutory_manpower_requirements"]}
    for m in MINES:
        workers=[]
        for i in range(35):
            wid=f"{m['mine_id']}-WORKER-{i:03d}"; worker={"worker_id":wid,"employee_id":wid,"mine_id":m["mine_id"],"name":f"Demo Worker {m['mine_id']}-{i:03d}","worker_type":pick(["employee","contractor"]),"designation":pick(["Operator","Fitter","Electrician","Miner","Helper","Driver"]),"contractor_id":f"CONT-{n(1,10):03d}","joining_date":dt(n(100,1800)),"employment_status":"active","department":pick(DEPTS),**common(m)}; workers.append(worker); D["workers"].append(worker)
        for w in workers:
            for typ in ["safety_induction","refresher","first_aid","emergency_response"]:
                status=pick(["completed","completed","completed","scheduled"])
                D["worker_training"].append({"training_id":uid("TRAIN"),"worker_id":w["worker_id"],"mine_id":m["mine_id"],"training_type":typ,"completion_status":status,"completion_date":dt(n(1,180)) if status=="completed" else None,"trainer":"Safety Training Cell","score_pct":f(65,100),"certificate_no":uid("CERT") if status=="completed" else None,**common(m)})
            D["worker_certifications"].append({"certification_id":uid("WCERT"),"worker_id":w["worker_id"],"mine_id":m["mine_id"],"certification_type":pick(["operator","electrical","blasting_assistant","first_aid"]),"issue_date":dt(n(30,700)),"expiry_date":dt(-n(20,400)),"status":pick(["valid","valid","expiring"]),**common(m)})
            D["medical_fitness"].append({"fitness_id":uid("MED"),"worker_id":w["worker_id"],"mine_id":m["mine_id"],"exam_date":dt(n(1,365)),"fitness_status":pick(["fit","fit","fit","restricted"]),"next_due_date":dt(-n(30,365)),"exam_type":"periodic medical examination",**common(m)})
            D["ppe_records"].append({"ppe_record_id":uid("PPE"),"worker_id":w["worker_id"],"mine_id":m["mine_id"],"as_of_date":dt(n(0,30)),"helmet_issued":True,"safety_shoes_issued":True,"hi_vis_vest_issued":True,"respirator_issued":m["type"]=="UG","compliance_status":pick(["compliant","compliant","exception"]),**common(m)})
        for i in range(min(days,60)):
            d=dt(i)
            D["attendance"].append({"attendance_id":uid("ATT"),"mine_id":m["mine_id"],"attendance_date":d,"present_count":n(22,34),"absent_count":n(0,8),"contractor_present":n(5,18),"employee_present":n(15,25),"attendance_pct":f(80,99),**common(m)})
            D["shifts"].append({"shift_id":f"{m['mine_id']}-{d.date()}-A","mine_id":m["mine_id"],"shift_date":d,"shift_code":"A","start_time":"06:00","end_time":"14:00","supervisor":f"{m['mine_id']}-EMP-004","status":"completed",**common(m)})
        for i in range(6):
            D["statutory_manpower_snapshots"].append({"snapshot_id":uid("MPS"),"mine_id":m["mine_id"],"as_of_date":dt(i*30),"sanctioned_strength":n(90,180),"actual_strength":n(75,170),"shortage_count":n(2,18),"employee_count":n(50,120),"contractor_count":n(20,60),"coverage_pct":f(80,99),**common(m)})
            D["statutory_manpower_requirements"].append({"requirement_id":uid("MPREQ"),"mine_id":m["mine_id"],"role":pick(ROLES),"required_count":n(2,15),"effective_from":dt(365),"basis":"synthetic planning reference",**common(m)})
    return D

def gen_safety(days):
    D={k:[] for k in ["compliance_records","inspections","inspection_templates","inspection_checklists","reports","safety_observations","near_misses","incidents","accidents","hazards","corrective_actions","safety_exposure_records","safety_program_activities","rescue_readiness_records","safety_alerts"]}
    for m in MINES:
        for typ in ["daily_workplace","statutory","electrical","ventilation","monsoon"]:
            tid=uid("IT"); D["inspection_templates"].append({"template_id":tid,"name":f"{typ.title()} Inspection Template","inspection_type":typ,"checklist_version":"DEMO-1","active":True,**common(m)})
        for i in range(min(days,90)):
            d=dt(i)
            if i%3==0:
                ins=uid("INSP"); findings=n(0,5); D["inspections"].append({"inspection_id":ins,"mine_id":m["mine_id"],"inspection_date":d,"inspector_role":pick(["Overman","Safety Officer","Manager"]),"inspection_type":pick(["workplace","electrical","ventilation","HEMM"]),"findings_count":findings,"status":"completed","risk_level":pick(["low","medium","high"]),**common(m)})
                for j in range(max(1,findings)):
                    D["inspection_checklists"].append({"checklist_id":uid("CHK"),"inspection_id":ins,"mine_id":m["mine_id"],"item_code":f"CHK-{j+1:02d}","item_text":"Synthetic inspection checkpoint","result":pick(["pass","pass","fail"]),"observation":"Synthetic checklist observation",**common(m)})
            if i%2==0:
                D["safety_observations"].append({"observation_id":uid("OBS"),"mine_id":m["mine_id"],"observed_at":d,"observer_role":pick(ROLES),"category":pick(["PPE","housekeeping","ground_control","electrical","traffic"]),"severity":pick(["low","medium","high"]),"status":pick(STATUSES),"description":"Synthetic safety observation","location":"Mine operational area",**common(m)})
            if i%4==0:
                D["near_misses"].append({"near_miss_id":uid("NM"),"mine_id":m["mine_id"],"event_datetime":d,"description":"Synthetic near-miss during shift","category":pick(["vehicle","fall_of_ground","PPE","electrical","blasting"]),"severity":pick(["low","medium","high"]),"reported_by":f"{m['mine_id']}-WORKER-001",**common(m)})
            if i%7==0:
                D["safety_program_activities"].append({"activity_id":uid("SPA"),"mine_id":m["mine_id"],"activity_date":d,"activity_type":pick(["toolbox_talk","mock_drill","safety_campaign","training"]),"participants_count":n(15,80),"findings_count":n(0,4),"actions_raised":n(0,4),"actions_closed":n(0,4),**common(m)})
        for i in range(n(1,3)):
            cls=pick(["fatal_accident","serious_accident","reportable_accident","minor_accident"]); ed=dt(n(5,days)); fatal=1 if cls=="fatal_accident" else 0
            D["accidents"].append({"accident_id":uid("ACC"),"mine_id":m["mine_id"],"event_datetime":ed,"event_class":cls,"fatalities":fatal,"serious_injuries":1 if cls=="serious_accident" else 0,"lost_days":n(0,60),"injured_count":0 if fatal else n(1,2),"root_cause_method":"5-Why","root_cause_category":pick(["unsafe_act","unsafe_condition","equipment","process"]),"location":"Synthetic mine area",**common(m)})
        for i in range(n(3,7)):
            ed=dt(n(5,days)); D["incidents"].append({"incident_id":uid("INC"),"mine_id":m["mine_id"],"event_datetime":ed,"incident_type":pick(["equipment_damage","traffic","electrical","ground_control"]),"severity":pick(["low","medium","high"]),"lost_time":False,"description":"Synthetic incident record",**common(m)})
        for i in range(n(5,10)):
            hd=dt(n(1,days)); status=pick(STATUSES); D["hazards"].append({"hazard_id":uid("HAZ"),"mine_id":m["mine_id"],"identified_at":hd,"category":pick(["ground","traffic","dust","electrical","fire"]),"risk_score":n(20,90),"severity":pick(["medium","high"]),"status":status,"control_measure":"Synthetic control action",**common(m)})
            D["corrective_actions"].append({"action_id":uid("CAPA"),"mine_id":m["mine_id"],"violation_id":f"{m['mine_id']}-VIO-{n(1,8):03d}","created_at":hd,"due_date":hd+timedelta(days=14),"closed_at":hd+timedelta(days=n(2,20)) if status in ("closed","verified") else None,"assigned_to":f"{m['mine_id']}-EMP-004","status":status,"priority":pick(["low","medium","high"]),"action_text":"Synthetic corrective and preventive action",**common(m)})
        for i in range(6):
            ps=dt(i*30); pe=ps+timedelta(days=30); shifts=f(1800,5000)
            D["safety_exposure_records"].append({"exposure_id":uid("EXP"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"man_shifts":shifts,"man_hours":shifts*8,"employee_man_shifts":shifts*0.7,"contractor_man_shifts":shifts*0.3,"coal_ob_volume_basis":f(1e5,8e5),**common(m)})
        D["rescue_readiness_records"].append({"readiness_id":uid("RES"),"site_id":m["mine_id"],"mine_id":m["mine_id"],"as_of_date":dt(7),"readiness_status":pick(["ready","ready","partially_ready"]),"trained_personnel_count":n(12,30),"apparatus_ready_count":n(3,6),"apparatus_total_count":n(5,7),"last_drill_date":dt(30),**common(m)})
        for i in range(8):
            ts=dt(n(1,days)); typ=pick(["strata_alert","hemm_proximity_alert","gas_dust_breach","electrical_fault","safety_general"])
            D["safety_alerts"].append({"alert_id":uid("SA"),"mine_id":m["mine_id"],"created_at":ts,"alert_type":typ,"severity":pick(["medium","high","critical"]),"status":pick(["new","acknowledged","resolved"]),"message":"Synthetic safety alert","acknowledged_at":ts+timedelta(hours=n(1,12)),**common(m)})
        D["compliance_records"] += [{"record_id":uid("SCR"),"mine_id":m["mine_id"],"record_date":dt(5),"category":"safety","status":pick(["compliant","partial","non_compliant"]),"score_pct":f(65,99),"evidence_reference":uid("EVID"),**common(m)}]
        D["reports"] += [{"report_id":uid("SAFREP"),"mine_id":m["mine_id"],"report_type":"safety_monthly","period_start":dt(60),"period_end":dt(30),"status":"draft","prepared_by":f"{m['mine_id']}-EMP-005",**common(m)}]
    return D

def gen_production(days):
    D={k:[] for k in ["production_target_records","production_records","dispatch_records","washeries","washery_operations","stockpile_records","equipment","equipment_maintenance","equipment_inspections","equipment_faults","equipment_telemetry","equipment_daily_performance","mine_capacity_records","downtime_records","blasting_records","drilling_records","wagon_loading_records","eauction_records","coal_quality_records"]}
    for m in MINES:
        base={"OC":4200,"UG":1500}[m["type"]]
        for d_i in range(min(days,180)):
            d=dt(d_i)
            seasonal=1+0.08*random.sin(d_i/18) if False else 1
            coal=max(0,base*8*random.uniform(.82,1.05))
            target=base*8*random.uniform(.92,1.02)
            ob=coal*random.uniform(0.9,1.8) if m["type"]=="OC" else 0
            D["production_records"].append({"production_id":uid("PROD"),"mine_id":m["mine_id"],"production_date":d,"mine_type":m["type"],"coal_tonnes":round(coal,2),"coal_target_tonnes":round(target,2),"ob_removed_m3":round(ob,2),"man_shifts":round(random.uniform(70,160),2),"area_id":m["area_id"],"coalfield_id":m["coalfield_id"],"shift_id":f"{m['mine_id']}-{d.date()}-A",**common(m)})
            dispatch=coal*random.uniform(.92,1.02)
            for mode,share in [("rail",.58),("road",.30),("feed_to_washery",.10),("conveyor",.02)]:
                D["dispatch_records"].append({"dispatch_id":uid("DISP"),"dispatch_date":d,"mine_id":m["mine_id"],"mode":mode,"sector":pick(["power","non_power","captive"]),"product_type":pick(["raw_coal","washed_coal","mixed"]),"tonnes":round(dispatch*share*random.uniform(.85,1.1),2),**common(m)})
            D["stockpile_records"].append({"stockpile_id":uid("STOCK"),"mine_id":m["mine_id"],"stock_date":d,"opening_stock_tonnes":f(5000,60000),"closing_stock_tonnes":f(5000,60000),"stock_change_tonnes":f(-5000,5000),"grade":"G10",**common(m)})
            D["downtime_records"].append({"downtime_id":uid("DOWN"),"mine_id":m["mine_id"],"downtime_date":d,"equipment_type":pick(EQUIPMENT),"duration_hours":f(0,18),"reason":pick(["breakdown","planned_maintenance","power","weather","no_operator"]),"production_loss_tonnes":f(0,1000),**common(m)})
            if m["type"]=="OC":
                D["blasting_records"].append({"blast_id":uid("BLAST"),"mine_id":m["mine_id"],"blast_date":d,"holes":n(20,80),"explosive_kg":f(100,800),"fragmentation_score":f(70,98),"flyrock_incident":False,**common(m)})
                D["drilling_records"].append({"drill_id":uid("DRILL"),"mine_id":m["mine_id"],"drilling_date":d,"holes_drilled":n(10,60),"meters_drilled":f(100,900),"machine_id":f"{m['mine_id']}-DRILL-01","status":"completed",**common(m)})
            D["wagon_loading_records"].append({"wagon_loading_id":uid("WAGON"),"mine_id":m["mine_id"],"railway_field":f"{m['mine_id']}-RF-01","loading_date":d,"wagons_loaded":n(20,80),"tonnes_loaded":f(1200,5000),"average_loading_time_min":f(20,60),**common(m)})
            if d_i%7==0: D["eauction_records"].append({"auction_id":uid("EAUC"),"mine_id":m["mine_id"],"auction_date":d,"coal_grade":"G10","quantity_tonnes":f(500,5000),"bid_value_crore":f(1,15),"winning_status":"awarded","buyer_category":"industrial",**common(m)})
            D["coal_quality_records"].append({"sample_id":uid("QUAL"),"mine_id":m["mine_id"],"sample_date":d,"grade":"G10","gcv_kcal_kg":n(3600,5200),"ash_pct":f(15,35),"moisture_pct":f(3,10),"sulphur_pct":f(.3,1.2),"conformity_status":pick(["conforming","conforming","non_conforming"]),**common(m)})
        for typ in ["raw_coal","washed_coal"]: D["washeries"].append({"washery_id":uid("WASH"),"mine_id":m["mine_id"],"name":f"{m['name']} {typ.title()} Washery","capacity_tpa":n(1000000,4000000),"washery_type":typ,"status":"operational",**common(m)})
        for i in range(min(30,days)):
            d=dt(i); D["washery_operations"].append({"washery_id":D["washeries"][-1]["washery_id"],"operation_date":d,"mine_id":m["mine_id"],"raw_coal_received_tonnes":f(1000,5000),"raw_coal_consumed_tonnes":f(900,4800),"washed_coal_produced_tonnes":f(700,4000),"washed_coal_dispatched_tonnes":f(600,3900),"yield_pct":f(65,90),**common(m)})
        for typ in ["monthly","annual"]:
            D["production_target_records"].append({"target_id":uid("TARGET"),"scope_type":"mine","scope_id":m["mine_id"],"period_start":dt(30 if typ=="monthly" else 365),"period_end":dt(0),"target_type":"production_tonnes","target_value":f(80000,500000) if typ=="monthly" else f(1000000,5000000),"unit":"tonnes","target_basis":"synthetic planning target",**common(m)})
        for eq in EQUIPMENT:
            D["equipment"].append({"equipment_id":uid("EQ"),"mine_id":m["mine_id"],"equipment_type":eq,"manufacturer":"DEMO","model":"SYN-01","commissioned_date":dt(n(100,2000)),"status":"active","capacity_tph":f(100,5000),**common(m)})
            D["equipment_daily_performance"].append({"mine_id":m["mine_id"],"as_of_date":dt(1),"equipment_type":eq,"population_total":n(2,20),"not_surveyed_off_count":n(0,2),"provisionally_surveyed_off_count":n(0,2),"availability_norm_pct":85.0,"availability_pct":f(70,98),"utilization_norm_pct":70.0,"utilization_pct":f(45,90),**common(m)})
        D["mine_capacity_records"].append({"capacity_id":uid("CAP"),"mine_id":m["mine_id"],"period_start":dt(365),"period_end":dt(0),"rated_capacity_tonnes":f(1000000,6000000),"system_capacity_utilization_pct":f(60,95),"active_capacity_tonnes":f(800000,5000000),**common(m)})
    # Equipment event collections need their own rows.
    for m in MINES:
        eqs=[x for x in D["equipment"] if x["mine_id"]==m["mine_id"]]
        for e in eqs:
            D["equipment_maintenance"].append({"maintenance_id":uid("MAINT"),"equipment_id":e["equipment_id"],"mine_id":m["mine_id"],"maintenance_date":dt(n(1,days)),"maintenance_type":pick(["preventive","corrective"]),"downtime_hours":f(1,24),"cost_lakh":f(.2,8),"status":"completed",**common(m)})
            D["equipment_inspections"].append({"inspection_id":uid("EQINSP"),"equipment_id":e["equipment_id"],"mine_id":m["mine_id"],"inspection_date":dt(n(1,30)),"condition_score":n(65,100),"odometer_hours":n(1000,20000),"status":pick(["fit","fit","attention"]),**common(m)})
            D["equipment_faults"].append({"fault_id":uid("FAULT"),"equipment_id":e["equipment_id"],"mine_id":m["mine_id"],"fault_at":dt(n(1,days)),"fault_type":pick(["engine","hydraulic","electrical","tyre","sensor"]),"severity":pick(["medium","high"]),"duration_hours":f(.5,18),"resolved":True,**common(m)})
            for j in range(4):
                ts=dt(j); D["equipment_telemetry"].append({"telemetry_id":uid("TEL"),"equipment_id":e["equipment_id"],"mine_id":m["mine_id"],"recorded_at":ts,"engine_hours":f(1000,12000),"fuel_rate_lph":f(15,80),"speed_kmph":f(0,35),"payload_tonnes":f(0,200),"temperature_c":f(65,105),"health_score":f(60,99),**common(m)})
    return D

def gen_environment(days):
    D={k:[] for k in ["air_quality","water_quality","groundwater","noise_monitoring","soil_monitoring","weather","environmental_samples","water_resource_records","energy_records","fuel_consumption_records","emissions_records","waste_records","land_use","forest_monitoring","vegetation_monitoring","plantation_records","reclamation_records","biodiversity_records","satellite_observations","renewable_energy_projects","sustainability_projects","eco_parks","csr_projects","csr_expenditure","social_metrics"]}
    for m in MINES:
        for i in range(min(days,60)):
            d=dt(i)
            D["air_quality"].append({"measurement_id":uid("AQ"),"mine_id":m["mine_id"],"measured_at":d,"pm10_ug_m3":f(40,180),"pm25_ug_m3":f(15,90),"so2_ug_m3":f(4,45),"no2_ug_m3":f(8,55),"location":"mine boundary","compliance_status":pick(["within_range","within_range","review"]),**common(m)})
            D["water_quality"].append({"measurement_id":uid("WQ"),"mine_id":m["mine_id"],"measured_at":d,"ph":f(6.2,8.5),"tss_mg_l":f(20,180),"tds_mg_l":f(100,900),"cod_mg_l":f(5,60),"bod_mg_l":f(2,25),"compliance_status":pick(["within_range","within_range","review"]),**common(m)})
            D["groundwater"].append({"measurement_id":uid("GW"),"mine_id":m["mine_id"],"measured_at":d,"water_level_m":f(4,35),"ph":f(6.5,8.2),"tds_mg_l":f(100,700),"quality_status":"monitored",**common(m)})
            D["noise_monitoring"].append({"measurement_id":uid("NOISE"),"mine_id":m["mine_id"],"measured_at":d,"day_db":f(55,78),"night_db":f(45,65),"location":"boundary station","compliance_status":"monitored",**common(m)})
            D["soil_monitoring"].append({"sample_id":uid("SOIL"),"mine_id":m["mine_id"],"sampled_at":d,"ph":f(5.8,8),"organic_carbon_pct":f(.3,1.8),"moisture_pct":f(10,35),"sample_location":"reclaimed area",**common(m)})
            D["weather"].append({"weather_id":uid("WEATHER"),"mine_id":m["mine_id"],"observed_at":d,"temperature_c":f(15,42),"rainfall_mm":f(0,30),"humidity_pct":f(30,95),"wind_speed_kmph":f(1,25),"visibility_km":f(1,12),**common(m)})
            D["environmental_samples"].append({"sample_id":uid("ENV"),"mine_id":m["mine_id"],"sampled_at":d,"sample_type":pick(["air","water","soil"]),"laboratory":"Demo Environmental Lab","analysis_status":"completed","result_status":pick(["acceptable","acceptable","review"]),**common(m)})
        for i in range(6):
            ps=dt(i*30); pe=ps+timedelta(days=30)
            D["water_resource_records"].append({"record_id":uid("WRES"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"withdrawal_kl":f(1000,8000),"consumption_kl":f(500,4000),"discharge_kl":f(200,2000),"surplus_mine_water_supplied_kl":f(0,1200),"community_beneficiaries":n(100,2000),**common(m)})
            D["energy_records"] += [{"record_id":uid("ENERGY"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"energy_type":"electricity_purchased","quantity":f(50000,150000),"unit":"kWh","source":"grid",**common(m)},{"record_id":uid("ENERGY"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"energy_type":"renewable_generation","quantity":f(2000,20000),"unit":"kWh","source":"solar",**common(m)}]
            D["fuel_consumption_records"].append({"record_id":uid("FUEL"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"fuel_type":"HSD","quantity":f(10000,50000),"unit":"litres","source":"fuel_station",**common(m)})
            D["emissions_records"].append({"record_id":uid("EMIS"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"emission_type":"CO2e","quantity":f(500,5000),"unit":"tonnes","method":"synthetic emission factor",**common(m)})
            for wt in ["overburden","hazardous","non_hazardous","scrap"]: D["waste_records"].append({"waste_id":uid("WASTE"),"mine_id":m["mine_id"],"period_start":ps,"period_end":pe,"waste_type":wt,"quantity_tonnes":f(20,5000),"disposed_tonnes":f(10,4000),"recycled_tonnes":f(0,500),"disposal_method":pick(["authorized","reused","recycled"]),**common(m)})
        D["land_use"].append({"land_record_id":uid("LAND"),"mine_id":m["mine_id"],"assessment_date":dt(30),"forest_land_ha":f(20,500),"agricultural_land_ha":f(10,100),"mining_area_ha":f(300,2500),"reclaimed_area_ha":f(20,500),"green_belt_area_ha":f(10,200),**common(m)})
        D["forest_monitoring"].append({"forest_record_id":uid("FOREST"),"project_id":f"{m['mine_id']}-FOREST-01","mine_id":m["mine_id"],"event_date":dt(30),"forest_area_monitored_ha":f(20,400),"encroachment_detected":False,"survival_rate_pct":f(70,96),"status":"monitored",**common(m)})
        D["vegetation_monitoring"].append({"vegetation_id":uid("VEG"),"mine_id":m["mine_id"],"assessment_date":dt(45),"vegetation_index":f(.25,.85),"green_cover_pct":f(15,70),"status":"improving",**common(m)})
        D["plantation_records"] += [{"plantation_id":uid("PLANT"),"mine_id":m["mine_id"],"activity_date":dt(i*60),"target_area_ha":10.0,"achieved_area_ha":f(4,10),"saplings_planted":n(500,3000),"survival_rate_pct":f(60,95),"species_count":n(3,12),**common(m)} for i in range(4)]
        D["reclamation_records"] += [{"reclamation_id":uid("RECL"),"mine_id":m["mine_id"],"assessment_date":dt(i*60),"disturbed_area_ha":f(50,200),"technically_reclaimed_area_ha":f(10,100),"biologically_reclaimed_area_ha":f(5,80),"reclamation_status":pick(["in_progress","progressing","completed"]),"reclaimed_percentage":f(10,80),**common(m)} for i in range(4)]
        D["biodiversity_records"].append({"biodiversity_id":uid("BIO"),"mine_id":m["mine_id"],"assessment_date":dt(90),"species_observed":n(20,120),"protected_species_observed":n(0,8),"habitat_area_ha":f(50,500),"conservation_actions":n(1,8),"status":"monitored",**common(m)})
        D["satellite_observations"] += [{"observation_id":uid("SAT"),"mine_id":m["mine_id"],"observation_date":dt(i*30),"source":"synthetic satellite observation","ndvi":f(.2,.8),"disturbed_area_change_ha":f(-5,12),"waterbody_change_ha":f(-2,5),"anomaly_flag":random.random()<.12,**common(m)} for i in range(4)]
        D["renewable_energy_projects"].append({"project_id":uid("RENEW"),"project_name":f"{m['name']} Solar Project","mine_id":m["mine_id"],"technology":"solar","capacity_mw":f(0.5,10),"commissioning_date":dt(500),"annual_generation_mwh":f(1000,12000),"status":"operational",**common(m)})
        for typ in ["afforestation","water_conservation","renewable","mine_closure"]: D["sustainability_projects"].append({"project_id":uid("SUS"),"mine_id":m["mine_id"],"project_type":typ,"project_name":f"{m['name']} {typ.title()} Initiative","project_status":pick(["ongoing","completed","planned"]),"budget_crore":f(.5,20),"progress_pct":f(20,100),**common(m)})
        D["eco_parks"].append({"eco_park_id":uid("ECO"),"mine_id":m["mine_id"],"name":f"{m['name']} Eco Park","area_ha":f(10,100),"visitors_count":n(500,10000),"status":"operational",**common(m)})
        D["csr_projects"] += [{"csr_project_id":uid("CSRPROJ"),"mine_id":m["mine_id"],"project_name":f"Community {typ.title()} Programme","sector":typ,"start_date":dt(180),"end_date":dt(-180),"budget_crore":f(.5,8),"status":pick(["ongoing","completed"]),"beneficiaries_count":n(200,5000),**common(m)} for typ in ["education","healthcare","infrastructure","livelihood"]]
    for i in range(12):
        ps=dt(i*30); pe=ps+timedelta(days=30)
        for sector in ["education","healthcare","infrastructure","livelihood"]:
            D["csr_expenditure"].append({"period_start":ps,"period_end":pe,"sector":sector,"amount_crore":f(.1,2),"beneficiaries_count":n(100,5000),**common()})
    for i in range(24): D["social_metrics"].append({"metric_id":uid("SOC"),"metric_date":dt(i*15),"metric_type":pick(["employment","health","education","water","grievance_resolution"]),"value":f(20,10000),"unit":pick(["count","percent","beneficiaries"]),**common()})
    return D

def gen_iot(days):
    D={k:[] for k in ["sensors","sensor_readings","cameras","cctv_events"]}
    for m in MINES:
        for typ in ["gas","dust","temperature","water_level","vibration","weather"]:
            sid=uid("SENSOR"); D["sensors"].append({"sensor_id":sid,"mine_id":m["mine_id"],"sensor_type":typ,"location":"synthetic monitoring station","unit":pick(["ppm","ug/m3","C","m","mm/s"]),"installed_at":dt(500),"status":"active","calibration_due":dt(-180),**common(m)})
            for i in range(min(days,20)):
                D["sensor_readings"].append({"reading_id":uid("READ"),"sensor_id":sid,"mine_id":m["mine_id"],"recorded_at":dt(i),"value":f(10,100),"quality":"good","threshold_state":pick(["normal","normal","warning"]),**common(m)})
        for i in range(4):
            cid=uid("CAM"); D["cameras"].append({"camera_id":cid,"mine_id":m["mine_id"],"camera_name":f"CAM-{i+1:02d}","location":pick(["gate","workshop","haul_road","stockyard","face"]),"stream_status":"online","resolution":"1080p","installed_at":dt(400),**common(m)})
            for j in range(5): D["cctv_events"].append({"event_id":uid("CCTV"),"camera_id":cid,"mine_id":m["mine_id"],"detected_at":dt(j),"event_type":pick(["no_helmet","no_vest","person_vehicle_proximity","restricted_area","smoke"]),"confidence":f(.75,.99),"severity":pick(["low","medium","high"]),"action_status":pick(["new","acknowledged","resolved"]),**common(m)})
    return D

def gen_governance(days):
    D={k:[] for k in ["documents","evidence","audit_log","blockchain_records","alerts","reminders","escalations","grievances"]}
    for m in MINES:
        for i in range(8):
            coll=pick(["compliance_violations","inspections","accidents","corrective_actions"]); rid=uid("DOCREC"); h=hashlib.sha256(rid.encode()).hexdigest()
            D["documents"].append({"document_id":uid("DOC"),"linked_collection":coll,"linked_record_id":rid,"document_type":pick(["inspection_report","permit","evidence_photo","approval"]),"file_name":f"DEMO-{rid}.pdf","document_hash":h,"uploaded_by":f"{m['mine_id']}-EMP-005","uploaded_at":dt(n(1,days)),**common(m)})
            D["evidence"].append({"evidence_id":uid("EVID"),"linked_collection":coll,"linked_record_id":rid,"evidence_type":pick(["document","photo","measurement"]),"description":"Synthetic evidence artifact","uploaded_by":f"{m['mine_id']}-EMP-005","uploaded_at":dt(n(1,days)),"hash":hashlib.sha256((rid+"evidence").encode()).hexdigest(),**common(m)})
        for i in range(12):
            rid=uid("AUD"); ts=dt(n(1,days)); D["audit_log"].append({"audit_id":uid("AUDIT"),"record_type":pick(["report","inspection","compliance","safety"]),"record_id":rid,"actor_id":f"{m['mine_id']}-EMP-004","action":pick(["create","update","approve","verify"]),"timestamp":ts,"before_hash":hashlib.sha256((rid+"before").encode()).hexdigest(),"after_hash":hashlib.sha256((rid+"after").encode()).hexdigest(),**common(m)})
            D["blockchain_records"].append({"event_id":uid("BC"),"record_type":"audit_log","record_id":rid,"transaction_id":uid("TX"),"block_hash":hashlib.sha256((rid+"block").encode()).hexdigest(),"previous_hash":hashlib.sha256((rid+"prev").encode()).hexdigest(),"timestamp":ts,"network":"demo-hash-chain","status":"anchored_demo",**common(m)})
        for i in range(6):
            ts=dt(n(1,days)); D["alerts"].append({"alert_id":uid("ALERT"),"mine_id":m["mine_id"],"type":pick(["compliance_overdue","safety","production_anomaly","permit_expiry"]),"category":pick(["safety","compliance","production"]),"sent_at":ts,"created_at":ts,"recipient_role":pick(ROLES),"recipient_id":f"{m['mine_id']}-EMP-001","severity":pick(["medium","high","critical"]),"acknowledged_at":ts+timedelta(hours=n(1,48)),"status":pick(["new","acknowledged","resolved"]),**common(m)})
            D["reminders"].append({"reminder_id":uid("REM"),"mine_id":m["mine_id"],"type":pick(["inspection_overdue","permit_expiry","report_due"]),"due_date":dt(-n(1,60)),"recipient_id":f"{m['mine_id']}-EMP-004","status":pick(["pending","sent","acknowledged"]),**common(m)})
            D["escalations"].append({"escalation_id":uid("ESC"),"mine_id":m["mine_id"],"source_collection":"corrective_actions","source_record_id":uid("CAPAREF"),"escalated_to":"Area GM","reason":pick(["SLA breach","high severity","repeat finding"]),"timestamp":ts,**common(m)})
        for i in range(8):
            cat=pick(["wages","working_conditions","harassment","safety_concern","welfare_facility"]); st=pick(["submitted","triaged","assigned","in_progress","resolved","closed"])
            D["grievances"].append({"grievance_id":uid("GRV"),"mine_id":m["mine_id"],"raised_by":f"{m['mine_id']}-WORKER-{i:03d}","description":f"Synthetic grievance regarding {cat}","category":cat,"priority":pick(["low","medium","high"]),"intent":pick(["complaint","request","query"]),"confidential":random.random()<.3,"submitted_at":dt(n(1,days)),"status":st,"assigned_to":f"{m['mine_id']}-EMP-012" if st not in ("submitted","triaged") else None,**common(m)})
    return D

def gen_reporting_ai(days):
    D={k:[] for k in ["report_definitions","report_metric_contracts","report_instances","report_artifacts","metric_snapshots","data_quality_checks","data_quality_issues","ai_models","analytics_results"]}
    reports=[("COMPLIANCE","monthly"),("PRODUCTION_DAILY","daily"),("SAFETY_MONTHLY","monthly"),("SUSTAINABILITY_ANNUAL","annual")]
    sections={"COMPLIANCE":["compliance_overview","violations_actions","regulatory_status","clearance_permissions"],"PRODUCTION_DAILY":["summary","overburden_productivity","offtake_dispatch","washery","stock_quality","equipment_capacity","anomaly_and_reason"],"SAFETY_MONTHLY":["accidents","rates","inspections_actions","training_and_preparedness","statutory_manpower_rescue","ai_iot_safety"],"SUSTAINABILITY_ANNUAL":["environmental_monitoring","energy_and_emissions","water","land_forest_biodiversity","waste_and_closure","renewable_sustainable_projects","social_csr"]}
    for code,freq in reports:
        D["report_definitions"].append({"report_code":code,"name":code.replace("_"," ").title(),"frequencies":[freq],"authority_scope":"mine_area_company","deterministic_metrics_required":True,"human_approval_required":True,**common()})
        for sec in sections[code]:
            for j in range(4): D["report_metric_contracts"].append({"report_code":code,"section_code":sec,"metric_code":f"{sec.upper()}_{j+1:02d}","data_type":"number","aggregation":"deterministic","source_collections":["synthetic source data"],"narrative_allowed":True,**common()})
    for m in MINES:
        for code,freq in reports:
            if freq=="daily": ps=dt(1); pe=dt(0)
            elif freq=="monthly": ps=dt(60); pe=dt(30)
            else: ps=dt(365); pe=dt(0)
            rid=uid("REPORT"); D["report_instances"].append({"report_instance_id":rid,"report_code":code,"mine_id":m["mine_id"],"reporting_period_start":ps,"reporting_period_end":pe,"status":pick(["draft","validated","review"]),"generated_at":now(),"input_snapshot_hash":hashlib.sha256((rid+"input").encode()).hexdigest(),"model_version":"deterministic-engine-v1",**common(m)})
            for j in range(6): D["metric_snapshots"].append({"snapshot_id":uid("SNAP"),"report_instance_id":rid,"metric_code":f"METRIC_{j+1:02d}","value":f(0,100000),"unit":pick(["count","percent","tonnes","kWh","litres"]),"calculation_version":"v1","source_trace":["synthetic_demo"],**common(m)})
            D["report_artifacts"].append({"artifact_id":uid("ART"),"report_instance_id":rid,"artifact_type":"pdf","file_name":f"{code}-{m['mine_id']}.pdf","storage_key":f"demo/reports/{rid}.pdf","content_hash":hashlib.sha256(rid.encode()).hexdigest(),"created_at":now(),**common(m)})
            D["data_quality_checks"].append({"check_id":uid("DQ"),"report_code":code,"mine_id":m["mine_id"],"run_at":now(),"records_checked":n(100,10000),"checks_passed":n(90,100),"checks_failed":n(0,8),"status":"completed",**common(m)})
            for sev in ["info","warning"]: D["data_quality_issues"].append({"issue_id":uid("DQI"),"report_code":code,"mine_id":m["mine_id"],"severity":sev,"status":pick(["open","resolved"]),"field":"synthetic_field","description":"Synthetic data-quality issue for dashboard demonstration","detected_at":now(),**common(m)})
    models=[("production_anomaly","xgboost"),("risk","xgboost"),("safety_cv","yolov8"),("grievance_nlp","nemotron"),("report_narrative","nemotron")]
    for name,framework in models: D["ai_models"].append({"model_id":uid("MODEL"),"name":name,"version":"1.0-demo","framework":framework,"status":"prototype","purpose":f"Synthetic {name} model metadata","created_at":now(),**common()})
    for m in MINES:
        for typ in ["risk","production_anomaly","safety_cv","grievance_nlp"]:
            for i in range(5):
                score=f(0,100); D["analytics_results"].append({"analytics_id":uid("ANALYTICS"),"record_id":uid("REC"),"mine_id":m["mine_id"],"model_type":typ,"score_or_label":round(score,2),"generated_at":dt(i),"model_version":"1.0-demo","top_factors":["synthetic_feature_1","synthetic_feature_2"],"narrative":"Synthetic model output. Replace with actual model inference.",**common(m)})
    return D

def generate(days):
    D={}
    for part in [gen_master,gen_regulatory,gen_approvals,gen_workforce,gen_safety,gen_production,gen_environment,gen_iot,gen_governance,gen_reporting_ai]:
        x=part(days); 
        for k,v in x.items(): D.setdefault(k,[]).extend(v)
    # Collections that exist in v2 but are intentionally not source datasets get at least a useful demo row.
    # The generic fallback is explicit, so the script can never silently leave a declared collection empty.
    for name in COLLECTIONS:
        D.setdefault(name,[])
        if not D[name] and name not in {"production_model_inputs","risk_training_samples"}:
            D[name]=[{"demo_record_id":uid("DEMO"),"collection":name,"status":"synthetic_demo","created_at":now(),"description":f"Synthetic placeholder for {name}; extend schema-specific fields as needed","synthetic_demo":True,"source":"synthetic_full_generator"}]
    # Existing source datasets are intentionally untouched.
    D.pop("production_model_inputs",None); D.pop("risk_training_samples",None)
    return D

def clean_value(v):
    if isinstance(v,datetime): return v.isoformat()
    return v

def write_csv(path,docs):
    path.parent.mkdir(parents=True,exist_ok=True)
    keys=sorted({k for d in docs for k in d})
    with path.open("w",newline="",encoding="utf-8") as fh:
        w=csv.DictWriter(fh,fieldnames=keys); w.writeheader()
        for d in docs: w.writerow({k:(str(v) if isinstance(v,(list,dict)) else clean_value(v)) for k,v in d.items()})

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--days",type=int,default=180); ap.add_argument("--csv-dir",default=None); ap.add_argument("--clear-synthetic",action="store_true")
    args=ap.parse_args(); data=generate(args.days)
    print(f"Generated {len(data)} collections")
    if args.csv_dir:
        p=Path(args.csv_dir); p.mkdir(parents=True,exist_ok=True)
        for name,docs in data.items(): write_csv(p/f"{name}.csv",docs)
        print(f"CSV export complete: {p.resolve()}"); return
    uri=os.getenv("MONGODB_URI"); db_name=os.getenv("MONGODB_DB","ccl_smart_governance")
    if not uri: raise SystemExit("MONGODB_URI is missing. Put it in .env or use --csv-dir.")
    from pymongo import MongoClient
    client=MongoClient(uri); db=client[db_name]
    try:
        if args.clear_synthetic:
            for name in data: db[name].delete_many({"synthetic_demo":True})
        for name,docs in data.items():
            if not docs:
                continue
            if name == "report_definitions":
                for doc in docs:
                    db[name].update_one({"report_code": doc["report_code"]}, {"$set": doc}, upsert=True)
                print(f"{name}: upserted {len(docs)}")
            elif name == "report_metric_contracts":
                for doc in docs:
                    db[name].update_one({"report_code": doc["report_code"], "metric_code": doc["metric_code"]}, {"$set": doc}, upsert=True)
                print(f"{name}: upserted {len(docs)}")
            else:
                db[name].insert_many(docs,ordered=False)
                print(f"{name}: inserted {len(docs)}")
        print("\nFULL synthetic database generation complete.")
        print("production_model_inputs and risk_training_samples were NOT modified.")
    finally: client.close()

if __name__=="__main__": main()
