"""
Synthetic data generator — ccl_smart_governance

Covers every collection actually READ by:
  - productionReport.js / complianceReport.js / safetyReport.js / sustainabilityReport.js
  - build_risk_features.py

Deliberately does NOT touch production_model_inputs / risk_training_samples —
those already exist from your real CSVs; this script only ADDS the rest.

Field names here match the DB validators in initializeDatabase_v2.js exactly
(including the event_datetime fix and the new grievances collection).

Usage:
  pip install pymongo python-dotenv --break-system-packages
  python3 generate_synthetic_data.py --days 180
"""

import argparse
import os
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

load_dotenv = None
try:
    from dotenv import load_dotenv as _load_dotenv
    load_dotenv = _load_dotenv
except ImportError:
    pass

if load_dotenv:
    load_dotenv()
random.seed(42)

# Reuse the exact mine_ids already in your real production_data.csv so every
# collection here joins cleanly against data you already ingested.
MINES = [
    {"mine_id": "TAL-OC-01", "name": "Talcher Opencast", "type": "OC", "area_id": "AREA-TAL"},
    {"mine_id": "KOR-UG-02", "name": "Korba Underground", "type": "UG", "area_id": "AREA-KOR"},
    {"mine_id": "JHR-OC-03", "name": "Jharia Opencast", "type": "OC", "area_id": "AREA-JHR"},
    {"mine_id": "SEC-OC-04", "name": "Sohagpur Opencast", "type": "OC", "area_id": "AREA-SEC"},
    {"mine_id": "SIN-UG-05", "name": "Singrauli Underground", "type": "UG", "area_id": "AREA-SIN"},
]

ROLES = [
    ("AGM", "operations"), ("Project Manager", "operations"),
    ("Manager", "operations"), ("Assistant Manager", "operations"),
    ("Overman", "operations"), ("Safety Officer", "safety"),
    ("Surveyor", "survey"), ("Ventilation Officer", "ventilation"),
    ("E&M Engineer", "electrical_mechanical"), ("Mine Sardar", "operations"),
]


def now():
    return datetime.now(timezone.utc)


def daterange(days):
    end = now()
    return [end - timedelta(days=i) for i in range(days)]


def rand_choice_weighted(choices, weights):
    return random.choices(choices, weights=weights, k=1)[0]


# ---------- org scaffolding ----------

def gen_users():
    docs = []
    for mine in MINES:
        for i, (role, dept) in enumerate(ROLES):
            docs.append({
                "employee_id": f"{mine['mine_id']}-{role.replace(' ', '').replace('&','')[:4].upper()}-{i:02d}",
                "name": f"{role} - {mine['name']}",
                "role": role,
                "department": dept,
                "mine_id": mine["mine_id"],
                "area_id": mine["area_id"],
            })
    return docs


def gen_mines():
    return [{"name": m["name"], "type": m["type"], "mine_id": m["mine_id"], "area_id": m["area_id"]}
            for m in MINES]


# ---------- compliance ----------

REQUIREMENT_CATEGORIES = ["safety", "environment", "production", "labour"]

def gen_compliance_requirements():
    docs = []
    for i, cat in enumerate(REQUIREMENT_CATEGORIES):
        for j in range(3):
            docs.append({
                "requirement_code": f"REQ-{cat.upper()}-{j:02d}",
                "category": cat,
                "requirement_text": f"Statutory {cat} requirement #{j}",
                "frequency": random.choice(["monthly", "quarterly", "annual"]),
                "responsible_role": random.choice(["Manager", "Safety Officer", "Surveyor"]),
                "evidence_types": ["document", "inspection_record"],
            })
    return docs


def gen_compliance_occurrences(requirements, days):
    docs = []
    for mine in MINES:
        for req in requirements:
            for d in daterange(days)[::30]:  # monthly occurrences
                start = d - timedelta(days=30)
                status = rand_choice_weighted(
                    ["compliant", "verified", "partially_compliant", "non_compliant", "overdue"],
                    [40, 20, 15, 10, 15]
                )
                docs.append({
                    "requirement_id": req["requirement_code"],
                    "mine_id": mine["mine_id"],
                    "reporting_period_start": start,
                    "reporting_period_end": d,
                    "due_date": d + timedelta(days=7),
                    "status": status,
                })
    return docs


def gen_compliance_violations(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(3, 8)):
            docs.append({
                "mine_id": mine["mine_id"],
                "detected_at": random.choice(daterange(days)),
                "category": random.choice(REQUIREMENT_CATEGORIES),
                "severity": random.choice(["low", "medium", "high"]),
                "status": random.choice(["open", "closed"]),
            })
    return docs


def gen_corrective_actions(days):
    docs = []
    for mine in MINES:
        for i in range(random.randint(4, 10)):
            created = random.choice(daterange(days))
            status = random.choice(["open", "in_progress", "closed", "verified"])
            docs.append({
                "mine_id": mine["mine_id"],
                "violation_id": f"{mine['mine_id']}-VIO-{i:03d}",
                "created_at": created,
                "due_date": created + timedelta(days=14),
                "closed_at": created + timedelta(days=random.randint(1, 20)) if status in ("closed", "verified") else None,
                "assigned_to": "Manager",
                "status": status,
            })
    return docs


# ---------- safety ----------

def gen_accidents(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(0, 3)):
            event_class = rand_choice_weighted(
                ["fatal_accident", "serious_accident", "reportable_accident", "minor_accident"],
                [5, 15, 30, 50]
            )
            docs.append({
                "mine_id": mine["mine_id"],
                "event_datetime": random.choice(daterange(days)),
                "event_class": event_class,
                "fatalities": 1 if event_class == "fatal_accident" else 0,
                "serious_injuries": 1 if event_class == "serious_accident" else 0,
                "lost_days": random.randint(0, 30),
            })
    return docs


def gen_near_misses(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(5, 15)):
            docs.append({
                "mine_id": mine["mine_id"],
                "event_datetime": random.choice(daterange(days)),
                "description": "Near-miss reported during shift inspection",
            })
    return docs


def gen_inspections(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::3]:  # every 3 days
            docs.append({
                "mine_id": mine["mine_id"],
                "inspection_date": d,
                "inspector_role": random.choice(["Overman", "Safety Officer", "Manager"]),
                "findings_count": random.randint(0, 5),
            })
    return docs


def gen_worker_training(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(10, 30)):
            docs.append({
                "mine_id": mine["mine_id"],
                "completion_status": "completed",
                "completion_date": random.choice(daterange(days)),
                "training_type": random.choice(["safety_induction", "refresher", "first_aid"]),
            })
    return docs


def gen_safety_program_activities(days):
    docs = []
    for mine in MINES:
        for activity_type in ["toolbox_talk", "mock_drill"]:
            count = random.randint(4, 12) if activity_type == "toolbox_talk" else random.randint(1, 3)
            for _ in range(count):
                docs.append({
                    "mine_id": mine["mine_id"],
                    "activity_date": random.choice(daterange(days)),
                    "activity_type": activity_type,
                    "participants_count": random.randint(10, 60),
                    "findings_count": random.randint(0, 4),
                    "actions_raised": random.randint(0, 4),
                    "actions_closed": random.randint(0, 4),
                })
    return docs


# ---------- alerts / grievances ----------
# NOTE: alerts is queried two different ways by two different scripts:
#   safetyReport.js        -> category + created_at
#   build_risk_features.py -> type       + sent_at
# Rather than pick one (neither script has a schema-enforced "correct" name),
# every alert document below carries BOTH field pairs with matching values,
# so both consumers work without a code change. Flag this to your team as a
# TODO to standardize on one pair later.

ALERT_TYPES = ["strata_alert", "hemm_proximity_alert", "gas_dust_breach", "electrical_fault", "safety_general"]

def gen_alerts(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(5, 20)):
            t = random.choice(ALERT_TYPES)
            ts = random.choice(daterange(days))
            docs.append({
                "mine_id": mine["mine_id"],
                "type": t,
                "category": "safety",
                "sent_at": ts,
                "created_at": ts,
                "recipient_role": random.choice(["Safety Officer", "Manager", "Overman"]),
                "acknowledged_at": ts + timedelta(hours=random.randint(1, 48)) if random.random() > 0.2 else None,
            })
    return docs


def gen_reminders(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(3, 8)):
            docs.append({
                "mine_id": mine["mine_id"],
                "type": "inspection_overdue",
                "due_date": random.choice(daterange(days)),
                "recipient_id": f"{mine['mine_id']}-OVER-04",
                "status": random.choice(["pending", "sent", "acknowledged"]),
            })
    return docs


def gen_escalations(days):
    docs = []
    for mine in MINES:
        for _ in range(random.randint(1, 5)):
            docs.append({
                "mine_id": mine["mine_id"],
                "source_collection": "corrective_actions",
                "source_record_id": f"{mine['mine_id']}-VIO-001",
                "escalated_to": "Area GM",
                "reason": "SLA breach",
                "timestamp": random.choice(daterange(days)),
            })
    return docs


GRIEVANCE_CATEGORIES = ["wages", "working_conditions", "harassment", "safety_concern", "welfare_facility"]

def gen_grievances(days):
    docs = []
    for mine in MINES:
        for i in range(random.randint(5, 12)):
            docs.append({
                "mine_id": mine["mine_id"],
                "raised_by": f"{mine['mine_id']}-WORKER-{i:03d}",
                "description": f"Grievance regarding {random.choice(GRIEVANCE_CATEGORIES)}",
                "category": random.choice(GRIEVANCE_CATEGORIES),
                "priority": random.choice(["low", "medium", "high"]),
                "intent": random.choice(["complaint", "request", "query"]),
                "confidential": random.random() < 0.3,
                "submitted_at": random.choice(daterange(days)),
                "status": random.choice(["submitted", "triaged", "assigned", "resolved", "closed"]),
                "assigned_to": None,
            })
    return docs


# ---------- sustainability ----------

def gen_energy_records(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::30]:
            start = d - timedelta(days=30)
            for energy_type, qty_range in [("electricity_purchased", (50000, 150000)),
                                            ("renewable_generation", (2000, 20000))]:
                docs.append({
                    "mine_id": mine["mine_id"], "period_start": start, "period_end": d,
                    "energy_type": energy_type, "quantity": random.uniform(*qty_range), "unit": "kWh",
                })
    return docs


def gen_fuel_consumption_records(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::30]:
            docs.append({
                "mine_id": mine["mine_id"], "period_start": d - timedelta(days=30), "period_end": d,
                "fuel_type": "HSD", "quantity": random.uniform(10000, 50000), "unit": "litres",
            })
    return docs


def gen_emissions_records(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::30]:
            docs.append({
                "mine_id": mine["mine_id"], "period_start": d - timedelta(days=30), "period_end": d,
                "emission_type": "CO2e", "quantity": random.uniform(500, 5000), "unit": "tonnes",
            })
    return docs


def gen_water_resource_records(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::30]:
            docs.append({
                "mine_id": mine["mine_id"], "period_start": d - timedelta(days=30), "period_end": d,
                "withdrawal_kl": random.uniform(1000, 8000),
                "consumption_kl": random.uniform(500, 4000),
                "discharge_kl": random.uniform(200, 2000),
                "surplus_mine_water_supplied_kl": random.uniform(0, 1000),
                "community_beneficiaries": random.randint(100, 2000),
            })
    return docs


def gen_plantation_records(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::60]:
            docs.append({
                "mine_id": mine["mine_id"], "activity_date": d,
                "target_area_ha": 10.0, "achieved_area_ha": random.uniform(4, 10),
                "saplings_planted": random.randint(500, 3000),
                "survival_rate_pct": random.uniform(60, 95),
            })
    return docs


def gen_reclamation_records(days):
    docs = []
    for mine in MINES:
        for d in daterange(days)[::60]:
            docs.append({
                "mine_id": mine["mine_id"], "assessment_date": d,
                "disturbed_area_ha": random.uniform(50, 200),
                "technically_reclaimed_area_ha": random.uniform(10, 100),
                "biologically_reclaimed_area_ha": random.uniform(5, 80),
            })
    return docs


def gen_csr_expenditure(days):
    docs = []
    sectors = ["education", "healthcare", "infrastructure", "livelihood"]
    for d in daterange(days)[::30]:
        for sector in sectors:
            docs.append({
                "period_start": d - timedelta(days=30), "period_end": d,
                "sector": sector, "amount_crore": random.uniform(0.1, 2.0),
                "beneficiaries_count": random.randint(100, 5000),
            })
    return docs


def gen_analytics_results_placeholder(days):
    # Placeholder rows so dashboard dev isn't blocked before real models write here.
    docs = []
    for mine in MINES:
        docs.append({
            "record_id": mine["mine_id"], "mine_id": mine["mine_id"], "model_type": "risk",
            "score_or_label": random.randint(20, 80), "generated_at": now(),
        })
    return docs


def bulk_insert(db, name, docs):
    if not docs:
        return
    from pymongo import InsertOne
    db[name].bulk_write([InsertOne(d) for d in docs], ordered=False)
    print(f"{name}: inserted {len(docs)}")


def write_csv(csv_dir, name, docs):
    if not docs:
        return
    import csv as csv_module
    path = Path(csv_dir) / f"{name}.csv"
    fieldnames = sorted({k for d in docs for k in d.keys()})
    with open(path, "w", newline="") as f:
        writer = csv_module.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in docs:
            # Flatten anything non-scalar (lists/dicts) to a string so the CSV stays readable.
            row = {k: (v if not isinstance(v, (list, dict)) else str(v)) for k, v in d.items()}
            writer.writerow(row)
    print(f"{name}: wrote {len(docs)} rows -> {path}")


def build_all_collections(days):
    """One dict per collection, generated once, used by either the Mongo path or the CSV path."""
    requirements = gen_compliance_requirements()
    return {
        "mines": gen_mines(),
        "users": gen_users(),
        "compliance_requirements": requirements,
        "compliance_occurrences": gen_compliance_occurrences(requirements, days),
        "compliance_violations": gen_compliance_violations(days),
        "corrective_actions": gen_corrective_actions(days),
        "accidents": gen_accidents(days),
        "near_misses": gen_near_misses(days),
        "inspections": gen_inspections(days),
        "worker_training": gen_worker_training(days),
        "safety_program_activities": gen_safety_program_activities(days),
        "alerts": gen_alerts(days),
        "reminders": gen_reminders(days),
        "escalations": gen_escalations(days),
        "grievances": gen_grievances(days),
        "energy_records": gen_energy_records(days),
        "fuel_consumption_records": gen_fuel_consumption_records(days),
        "emissions_records": gen_emissions_records(days),
        "water_resource_records": gen_water_resource_records(days),
        "plantation_records": gen_plantation_records(days),
        "reclamation_records": gen_reclamation_records(days),
        "csr_expenditure": gen_csr_expenditure(days),
        "analytics_results": gen_analytics_results_placeholder(days),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=180)
    ap.add_argument("--csv-dir", type=str, default=None,
                     help="Write one CSV per collection here instead of inserting to MongoDB. "
                          "No MONGODB_URI needed in this mode.")
    args = ap.parse_args()

    collections = build_all_collections(args.days)

    if args.csv_dir:
        Path(args.csv_dir).mkdir(parents=True, exist_ok=True)
        for name, docs in collections.items():
            write_csv(args.csv_dir, name, docs)
        print(f"\nCSV export complete: {len(collections)} files in {args.csv_dir}")
        return

    uri = os.getenv("MONGODB_URI")
    db_name = os.getenv("MONGODB_DB", "ccl_smart_governance")
    if not uri:
        raise SystemExit("Set MONGODB_URI first, or use --csv-dir to skip Mongo entirely.")

    from pymongo import MongoClient
    client = MongoClient(uri)
    db = client[db_name]
    try:
        for name, docs in collections.items():
            bulk_insert(db, name, docs)
        print("Synthetic data generation complete (inserted to MongoDB).")
    finally:
        client.close()


if __name__ == "__main__":
    main()